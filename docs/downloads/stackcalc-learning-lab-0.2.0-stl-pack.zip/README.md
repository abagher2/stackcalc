# StackCalc Open Source Math Manipulatives & Enclosures
All models are designed for 3D printing on standard FDM printers (0.4mm nozzle, 0.2mm layer height).
Enclosures feature primary squircle keycap button badges with micro-hatching:
- Place Value: [123]
- Fractions: [FDISP]
- Algebra: [EQN]
- Ten Frames: Ten-frame grid
- Classroom Clock: 9:00 Dial
- Dice & Spinner: 3-pip die face
- Math Dominoes: [Σ+]
- Unifix Cubes: [NUM]

Part of the StackCalc Open Source Hardware Ecosystem.
https://stackcalc.io

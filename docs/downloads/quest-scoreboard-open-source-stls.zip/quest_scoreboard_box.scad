// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/gridfinity.scad>
include <lib/swiftui_button_icons.scad>
include <lib/part_metadata.scad>

// ============================================================================
// Component Metadata Contract (Single Source of Truth)
// ============================================================================
PART_SKU = "QUEST-01";
PART_REV = "2.0.0";
PART_NAME = "SC-6 Quiz & Mastery Scoreboard 3x1x7U Enclosure";
PART_AMORTIZED_COST = 8.00;
PART_REPLACEMENT_PRICE = 12.00;

// StackCalc Learning Lab / quest_scoreboard_box (QUEST-01)
// Simplified 2-Piece 3x1x7U Gridfinity SC-6 Scoreboard & Token Bank (125.5 x 42.0 x 49.0 mm / 7U)
// Uses one universal "+10" block token and the Snapfinity Lid as the desktop scoreboard:
//   - 1 Block (+10 pts)         = Solved 1 Way (Blocks or SC-6 Calculator / Normal Correct)
//   - 2 Stacked Blocks (+20 pts)= Solved 2 Ways ("Twin-Way Proof" / Fast <4s in [?/C] Quiz Mode)
//   - 10 Blocks (100 pts)       = 100% Mastery! (5 problems x 2 ways, or 10 problems x 1 way)
//
// Complete 2-Piece Support-Free Assembly (No separate inner tray required):
//   1. 3x1x7U Storage Enclosure Body with 6x2 interior miniblock floor & Left-Shift C ([?] / C) rear button badge.
//      Holds 60 universal "+10" tokens in 5 neat layers of 12 (6x2).
//   2. 3x1 Snapfinity Stackable Desktop Scoreboard Lid:
//      - Left 5x2 Grid (Cols 0-4): Numbered "1"-"5" (top row) and "6"-"10" (bottom row) for Daily Problems 1-10 or Chapters 1-10.
//      - Rightmost Goal Column (Col 5): Top socket labeled "100" (100-Point Mastery Tower) + Bottom Left-Shift C ([?] / C) Quiz Keycap Badge.

$fn = 16;
tray_w = 125.5;
tray_h = 42.0;
bin_h = 49.0; // Standard 7U height (matches Place Value & Algebra boxes)
lip_h = 4.4;
floor_h = 3.5;

// Simplified 6x2 Lid socket labels:
// Cols 0-4: Sockets 1-5 (top row) and 6-10 (bottom row)
// Col 5:    "100" Mastery Goal socket (top-right) and Left-Shift C ([?] / C) Quiz badge (bottom-right)
lid_row1_labels = ["1", "2", "3", "4", "5",  "100"];
lid_row0_labels = ["6", "7", "8", "9", "10", ""];

module quest_box_body() {
    difference() {
        // Main solid 3x1x7U bin body with Gridfinity base and upper stacking lip
        gridfinity_box_solid(tray_w=tray_w, tray_h=tray_h, bin_h=bin_h, lip_h=lip_h, nx=3, ny=1);

        // Main inner cavity centered symmetrically at y = tray_h/2: 118.0 x 39.2 mm
        translate([tray_w/2, tray_h/2, floor_h])
            rounded_square([118.0, 39.2], r=1.0, h=bin_h - floor_h + 0.1);

        // Standardized Snapfinity 1.20mm reinforced upper lip rebate with end-wall retention grooves
        gridfinity_box_lip_rebate(tray_w=tray_w, tray_h=tray_h, bin_h=bin_h, lip_h=lip_h, lip_wall_t=1.20, nx=3, detent_sides="ends");

        // 12 Recessed miniblock sockets in 6x2 grid inside the bottom floor (19.60mm universal pitch)
        for (col = [0:5]) {
            cx = 13.75 + col * 19.60;
            translate([cx, 11.20, floor_h - 1.85])
                miniblock_tray_socket();
            translate([cx, 30.80, floor_h - 1.85])
                miniblock_tray_socket();
        }

        // Front face recessed instrument plaque
        translate([tray_w/2, 0.00, bin_h / 2])
            rotate([90, 0, 0])
                box_instrument_plaque(title="QUEST BOARD", w=76.0, h=12.0, depth=0.35);

        // Architectural horizontal reveal parting lines for zoned fuzzy skin
        box_architectural_reveals(tray_w, tray_h, bin_h);

        // 360-degree architectural fluted grip louvers across all 4 walls
        box_fluted_louvers(tray_w, tray_h, bin_h, include_back=true, include_front=true, include_ends=true, seam_trap=false, flute_w=0.58);

        // Rear wall lower-right calculator button badge: Left-Shift C ([?] / C) Tutorial & Quiz button
        box_back_button_badge(tray_w, tray_h, bin_h, type="quiz", label="?", sublabel="C", depth=0.30);
    }
}

module quest_scoreboard_lid() {
    // Bottom-right socket (col=5, row=0) renders the canonical Left-Shift C ([?] / C) Tutorial/Quiz button badge
    gridfinity_stackable_lid(
        nx = 3,
        ny = 1,
        miniblock_grid = true,
        detents = true,
        detent_sides = "ends",
        row0_labels = lid_row0_labels,
        row1_labels = lid_row1_labels,
        button_face = "?",
        button_sublabel = "C",
        button_type = "quiz",
        drop_front = false
    );
}

// Backward-compatible alias
module box_plate() {
    quest_box_body();
}

// ----------------------------------------------------------------------------
// Manufacturing Plate Layout (Both pieces on 250x210 bed, zero supports)
// ----------------------------------------------------------------------------
show_box = true;
show_lid = true;

if (show_box)
    translate([0, 0, 3.0])
        quest_box_body();

if (show_lid)
    translate([0, 48.0, 0])
        quest_scoreboard_lid();

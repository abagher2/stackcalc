// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/gridfinity.scad>
include <lib/block_numerals.scad>

// StackCalc Learning Lab / quest_scoreboard_parts (QUEST-01)
// Simplified Universal "+10" Quarter-Block Token Set (19.0 x 19.0 x 8.85 mm, 7.0mm visible height = 1U Gridfinity).
// Every token in the box is identical ("+10") so students never have to sort or hunt for different denominations!
//   - 1 Block  (+10 pts) = Solved 1st Way (Physical Blocks OR SC-6 Calculator / Normal Correct in [?/C] Quiz)
//   - 2 Blocks (+20 pts) = Stack a 2nd block on top! Solved 2nd Way ("Twin-Way Proof" / Fast <4s in [?/C] Quiz)
//   - 10 Blocks (100 pts)= 100% Section Mastery! (e.g., 5 problems x 2 ways, or 10 problems x 1 way)
//
// Packs cleanly in 5 layers of 12 (6x2 = 60 tokens total) inside the 3x1x7U SC-6 Scoreboard Box.
// Tip: Print 1 plate of 60 in one color, or set token_rows=2, token_cols=6 (12 tokens per layer) in 5 colors!

$fn = 16;
tile_h_vis = 7.0;
tile_h = 1.85 + tile_h_vis; // 8.85mm total height
token_label = "+10";
token_cols = 10;
token_rows = 6;

module quest_token(cx, cy, label="+10") {
    translate([cx, cy, 0]) {
        difference() {
            union() {
                // Bottom 18mm Gridfinity Base Plug (z = 0 to 1.85mm)
                miniblock_base();

                // Main solid quarter-block body (z = 1.85 to 8.85mm, 7.0mm visible height)
                translate([0, 0, 1.85 - 0.01])
                    rounded_square([19.0, 19.0], r=1.8, h=tile_h - 1.85 + 0.01);
            }

            // Top Recessed 18mm Gridfinity Stacking Socket (z = 7.0 to 8.85mm)
            translate([0, 0, tile_h - 1.85]) {
                miniblock_stacking_socket();
                // High-contrast debossed "+10" label on socket floor
                translate([0, 0, -0.05])
                    block_top_numeral(label=label, depth=0.55);
            }

            // 4-sided vertical perimeter debossed markings for instant side visibility when stacked in towers
            block_side_markings(label=label, h_vis=tile_h_vis, depth=0.55, block_w=19.0);
        }
    }
}

// PRINT BED LAYOUT: Default 60 Universal "+10" Tokens in a 10x6 Grid (22.0mm pitch = 220 x 132 mm footprint)
pitch = 22.0;
for (row = [0:token_rows-1]) {
    for (col = [0:token_cols-1]) {
        quest_token(11.0 + col * pitch, 11.0 + row * pitch, label=token_label);
    }
}

// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/part_metadata.scad>

// ============================================================================
// Component Metadata Contract (Single Source of Truth)
// ============================================================================
PART_SKU = "PRIME-01";
PART_REV = "a793ddd";
PART_NAME = "Prime Factor 3x1 Storage Enclosure";
PART_AMORTIZED_COST = 10.00;
PART_REPLACEMENT_PRICE = 15.00;

// StackCalc Learning Lab / prime_studio_box
// 3x1 Gridfinity Prime Holding Bin (125.5 x 42.0 x 91.0 mm / 13U).
// Standard 100% Gridfinity Architecture:
//   - 3x1 standard Gridfinity base profile on underside (42.0mm pitch).
//   - Standard 4.4mm upper stacking lip for stacking additional bins.
//   - Interior base features 12 quarter-size Gridfinity miniblock sockets (6x2 grid)
//     holding prime factor towers (powers of 2, 3, 5, 7, and semi-primes) with universal 18.0 mm socket standard.
//   - Back Wall Bilateral Comparator Stage with Precision Logarithmic Stacking Comparator Scale (1 to 100).
//   - Underside of Stackable Lid features DEBOSSED Precision Logarithmic Stacking Comparator Scale (1 to 100)
//     with 4 hierarchical line levels (10s, 5s, Evens, Odds) and dual-rail staggered labels (5s and 10s)
//     calibrated to zero running together, mirroring correctly for direct bottom viewing!
//   - Calculator Button: Exact hardware replica of HP-32 key primary "PRIME" + secondary "FACT".
// 100% support-free FDM printing directly at Z=0.

$fn = 16;
tray_w = 125.5;
tray_h = 42.0;
bin_h = 91.0;
lip_h = 4.4;
floor_h = 3.5;

module rounded_square(dim, r=2, h=1) {
    linear_extrude(h) offset(r=r) offset(delta=-r) square([dim[0], dim[1]], center=true);
}

// 0.5U Gridfinity female tray socket (quarter-size standard)
module miniblock_tray_socket() {
    hull() {
        translate([0, 0, -0.05]) rounded_square([17.4, 17.4], r=1.1, h=0.02);
        translate([0, 0, 0.70]) rounded_square([18.8, 18.8], r=1.5, h=0.02);
    }
    translate([0, 0, 0.70])
        rounded_square([18.8, 18.8], r=1.5, h=0.25);
    hull() {
        translate([0, 0, 0.95]) rounded_square([18.8, 18.8], r=1.5, h=0.02);
        translate([0, 0, 1.85 + 0.05]) rounded_square([19.2, 19.2], r=1.8, h=0.02);
    }
}

// Underside standard Gridfinity unit base plug
module gridfinity_unit_base() {
    rounded_square([35.6, 35.6], r=1.6, h=0.8);
    translate([0, 0, 0.8])
        hull() {
            rounded_square([35.6, 35.6], r=1.6, h=0.02);
            translate([0, 0, 1.6]) rounded_square([40.4, 40.4], r=3.2, h=0.02);
        }
    translate([0, 0, 2.4])
        hull() {
            rounded_square([40.4, 40.4], r=3.2, h=0.02);
            translate([0, 0, 0.6]) rounded_square([41.5, 41.5], r=3.75, h=0.02);
        }
}


module box_plate() {
    difference() {
        union() {
            // Main solid bin body
            translate([tray_w/2, tray_h/2, 0])
                rounded_square([tray_w - 0.5, tray_h - 0.5], r=3.75, h=bin_h - 1.6);

            // Transition to upper stacking lip
            translate([tray_w/2, tray_h/2, bin_h - 1.6])
                hull() {
                    rounded_square([tray_w - 0.5, tray_h - 0.5], r=3.75, h=0.2);
                    translate([0, 0, 1.4]) rounded_square([tray_w, tray_h], r=3.75, h=0.2);
                }

            // Upper stacking lip
            translate([tray_w/2, tray_h/2, bin_h])
                rounded_square([tray_w, tray_h], r=3.75, h=lip_h);

            // Underside Gridfinity plugs (3 units at 42.0mm pitch)
            translate([20.75, 21.00, -3.0]) gridfinity_unit_base();
            translate([62.75, 21.00, -3.0]) gridfinity_unit_base();
            translate([104.75, 21.00, -3.0]) gridfinity_unit_base();

            // Underside stacking clearance ribs
            for (div_x = [42.0, 84.0]) {
                translate([div_x, tray_h / 2, -0.6])
                    hull() {
                        cube([0.02, 41.5, 0.02], center=true);
                        translate([0, 0, 0.6]) cube([1.2, 41.5, 0.02], center=true);
                    }
            }
        }

        // Main inner cavity: centered symmetrically at y = tray_h/2: 118.0 x 39.2 mm
        translate([tray_w/2, tray_h/2, floor_h])
            rounded_square([118.0, 39.2], r=1.0, h=bin_h - floor_h + 0.1);

        // Standardized Snapfinity 1.20mm reinforced upper lip rebate with 0.35mm retention detent grooves
        gridfinity_box_lip_rebate(tray_w=tray_w, tray_h=tray_h, bin_h=bin_h, lip_h=lip_h, lip_wall_t=1.20, nx=3);

        // 12 Female miniblock sockets in 6x2 grid inside the bottom of the tray
        // Universal 19.60mm pitch aligned with blocks and trays across all kits
        for (col = [0:5]) {
            cx = 13.75 + col * 19.60;

            // Front row (row 0, y = 11.20)
            translate([cx, 11.20, floor_h - 1.85])
                miniblock_tray_socket();

            // Back row (row 1, y = 30.80)
            translate([cx, 30.80, floor_h - 1.85])
                miniblock_tray_socket();
        }

        // Front face recessed instrument plaque: "PRIME"
        translate([tray_w/2, 0.25, bin_h / 2])
            rotate([90, 0, 0])
                box_instrument_plaque(title="PRIME", w=76.0, h=12.0);

        // Architectural horizontal reveal parting lines for zoned fuzzy skin
        box_architectural_reveals(tray_w, tray_h, bin_h);

        // End wall architectural fluted grip louvers (back omitted for comparator scale)
        box_fluted_louvers(tray_w, tray_h, bin_h, include_back=false);

        // ====================================================================
        // Back Wall Slide Rule Comparator Stage (1 to 100)
        // ====================================================================
        // Authentic logarithmic slide rule scale with simple, elegant lines.
        // Calibrated to desk level where blocks stand on the table next to the box:
        // Table surface is at Z = -3.0mm in box_plate(); block male foot = 1.85mm.
        // Exact physical top of stack: Z(N) = 42.0 * log10(N) - 1.15mm.
        // N=1 is below the box body (Z = -1.15mm, not visible).
        // N=2 lines up exactly with a single 2 block standing on the desk (Z = 11.49mm).
        // 27 clean tick marks with 4 levels of lines, 10 primary numbers (2, 3, 4, 5, 10, 20, 30, 40, 50, 100).
        // Zero intersections: numbers sit outside the rails with a clean margin.
        back_wall_y = tray_h / 2 + (tray_h - 0.5) / 2; // 41.75mm
        deboss_d    = 0.40;

        // In rear view (+Y facing -Y):
        // Higher X is viewer's LEFT (rail_l_x)
        // Lower X is viewer's RIGHT (rail_r_x)
        rail_l_x   = 102.0;
        rail_r_x   = 23.5;
        rail_z_min = 42.0 * log(2) - 1.15; // 11.49mm (starts at 2)
        rail_z_max = 42.0 * log(100) - 1.15; // 82.85mm (ends at 100)
        rail_w     = 0.45;

        // 1. Continuous Vertical Slide Rule Rails (start at 2, end at 100)
        translate([rail_l_x - rail_w/2, back_wall_y - deboss_d, rail_z_min])
            cube([rail_w, deboss_d + 0.05, rail_z_max - rail_z_min]);

        translate([rail_r_x - rail_w/2, back_wall_y - deboss_d, rail_z_min])
            cube([rail_w, deboss_d + 0.05, rail_z_max - rail_z_min]);

        // 2. Slide Rule Marks Table
        // [N, tick_level, label_str]
        // 4 Levels of Lines:
        // Level 1: Major decades (10, 100) - 7.0mm
        // Level 2: Sub-major integers / 5s (2, 3, 4, 5, 20, 30, 40, 50) - 5.0mm
        // Level 3: Medium intermediate 5s (15, 25, 35, 45, 60, 70, 80, 90) - 3.5mm
        // Level 4: Minor units (6, 7, 8, 9, 55, 65, 75, 85, 95) - 2.2mm
        slide_rule_marks = [
            // Decade 1 (2 to 10): 1 is below table baseline (Z = -1.15mm)
            [  2, 2, "2"],
            [  3, 2, "3"],
            [  4, 2, "4"],
            [  5, 2, "5"],
            [  6, 4, ""],
            [  7, 4, ""],
            [  8, 4, ""],
            [  9, 4, ""],
            [ 10, 1, "10"],
            // Decade 2 (10 to 100): Multiples of 5
            [ 15, 3, ""],
            [ 20, 2, "20"],
            [ 25, 3, ""],
            [ 30, 2, "30"],
            [ 35, 3, ""],
            [ 40, 2, "40"],
            [ 45, 3, ""],
            [ 50, 2, "50"],
            [ 55, 4, ""],
            [ 60, 3, ""],
            [ 65, 4, ""],
            [ 70, 3, ""],
            [ 75, 4, ""],
            [ 80, 3, ""],
            [ 85, 4, ""],
            [ 90, 3, ""],
            [ 95, 4, ""],
            [100, 1, "100"]
        ];

        for (m = slide_rule_marks) {
            n     = m[0];
            lvl   = m[1];
            lbl   = m[2];

            // Exact physical height of the top of the stack on the desk
            z_pos = 42.0 * log(n) - 1.15;

            // 4 levels of tick lengths and line weights
            t_len = (lvl == 1) ? 7.0 : ((lvl == 2) ? 5.0 : ((lvl == 3) ? 3.5 : 2.2));
            t_h   = (lvl == 1) ? 0.50 : ((lvl == 2) ? 0.42 : ((lvl == 3) ? 0.35 : 0.28));

            // Left scale (viewer's left, high X): ticks extend INWARD (decreasing X towards center)
            translate([rail_l_x - t_len, back_wall_y - deboss_d, z_pos - t_h/2])
                cube([t_len, deboss_d + 0.05, t_h]);

            // Right scale (viewer's right, low X): ticks extend INWARD (increasing X towards center)
            translate([rail_r_x, back_wall_y - deboss_d, z_pos - t_h/2])
                cube([t_len, deboss_d + 0.05, t_h]);

            // Clean direct debossed typography strictly OUTSIDE the rails
            if (len(lbl) > 0) {
                // Left scale: number on the left side of left rail (increasing X, away from center)
                translate([rail_l_x + 1.8, back_wall_y, z_pos])
                    rotate([90, 0, 0])
                        rotate([0, 180, 0])
                            translate([0, 0, -deboss_d])
                                linear_extrude(deboss_d + 0.05)
                                    text(lbl, size=2.8, font="Space Mono:style=Bold", halign="right", valign="center");

                // Right scale: number on the right side of right rail (decreasing X, away from center)
                translate([rail_r_x - 1.8, back_wall_y, z_pos])
                    rotate([90, 0, 0])
                        rotate([0, 180, 0])
                            translate([0, 0, -deboss_d])
                                linear_extrude(deboss_d + 0.05)
                                    text(lbl, size=2.8, font="Space Mono:style=Bold", halign="left", valign="center");
            }
        }

        // Rear wall lower-left calculator button badge: factor tree icon from Swift code
        box_back_button_badge(tray_w, tray_h, bin_h, type="prime", label="FACT", margin_x=10.0, margin_z=5.5);
    }
}

module prime_lid_grid() {
    gridfinity_stackable_lid(
        nx = 3,
        ny = 1,
        miniblock_grid = true,
        detents = true,
        row0_labels = ["11", "13", "17", "19", "23", "GCD"],
        row1_labels = ["2^6", "2^6", "3^4", "3^4", "5^2", "7^2"],
        button_face = "FACT",
        button_sublabel = "",
        button_type = "prime"
    );
}

show_box = true;
show_lid = true;

if (show_box) translate([0, 0, 3.0]) box_plate();
if (show_lid) translate([0, 48.0, 0]) prime_lid_grid();



// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/part_metadata.scad>
include <lib/stepped_box_7u.scad>

// ============================================================================
// Component Metadata Contract (Single Source of Truth)
// ============================================================================
PART_SKU = "PRIME-01";
PART_REV = "a793ddd";
PART_NAME = "Prime Factor 3x1x7U Stepped-Floor Storage Enclosure";
PART_AMORTIZED_COST = 6.00;
PART_REPLACEMENT_PRICE = 12.00;

// StackCalc Learning Lab / prime_studio_box (7U Stepped-Floor Architecture)
// 3x1x7U Gridfinity Prime Holding Bin (125.5 x 42.0 x 56.4 mm / 7U).
// Complete 2-Piece Support-Free Assembly (No Separate Caddy Required):
//   1. 3x1x7U Storage Enclosure Body with integrated solid stepped floor risers
//      bringing every prime column summit to the uniform 42.0mm (2^6 = 64) waterline.
//   2. Snapfinity Stackable Prime Stage Lid with debossed prime socket markings.

$fn = 16;
// Weighted 4-3-3-2 Eratosthenes 7U layout (4 cols of [2], 3 cols of [3], 3 cols of [5], 2 cols of [7]):
// Maximizes block density (43 pure prime blocks, 88.1% column fill) and covers 100% of {2,3,5,7} pairs <= 100.
row0_labels = ["2", "2", "3", "3", "3", "7"];
row0_riser  = [0.00, 0.00, 8.71, 8.71, 8.71, 2.70];

row1_labels = ["2", "2", "5", "5", "5", "7"];
row1_riser  = [0.00, 0.00, 9.49, 9.49, 9.49, 2.70];

module prime_box_body() {
    gridfinity_stepped_box_7u(
        title = "PRIME",
        badge_label = "FACT",
        badge_type = "prime",
        row0_labels = row0_labels,
        row0_riser  = row0_riser,
        row1_labels = row1_labels,
        row1_riser  = row1_riser
    );
}

module prime_lid_grid() {
    gridfinity_stackable_lid(
        nx = 3,
        ny = 1,
        miniblock_grid = true,
        detents = true,
        detent_sides = "ends",
        row0_labels = row0_labels,
        row1_labels = row1_labels,
        button_face = "FACT",
        button_sublabel = "",
        button_type = "prime",
        drop_front = false
    );
}

// ----------------------------------------------------------------------------
// Manufacturing Plate Layout (Box Body + Matching Lid on 250x210 bed, zero supports)
// ----------------------------------------------------------------------------
show_box = true;
show_lid = true;

if (show_box)
    translate([0, 0, 3.0])
        prime_box_body();

if (show_lid)
    translate([0, 48.0, 0])
        prime_lid_grid();


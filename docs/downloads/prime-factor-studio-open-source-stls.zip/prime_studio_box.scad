// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/part_metadata.scad>

// ============================================================================
// Component Metadata Contract (Single Source of Truth)
// ============================================================================
PART_SKU = "PRIME-01";
PART_REV = "a793ddd";
PART_NAME = "Prime Factor 3x1 Storage Enclosure";
PART_AMORTIZED_COST = 10.00;
PART_REPLACEMENT_PRICE = 15.00;

// StackCalc Learning Lab / prime_studio_box
// 3x1 Gridfinity Prime Holding Bin with Drop-Front Sliding Door (125.5 x 42.0 x 91.0 mm / 13U).
// Ergonomic Sliding Front Wall Architecture:
//   - Front panel slides vertically UP and out, giving 100% unobstructed horizontal hand access
//     to both rows so adults and children can place towers effortlessly without dropping blocks.
//   - Solid permanent back wall and end walls keep towers supported throughout loading.
//   - Stepped floor pedestals in Row 1 elevate larger primes ([11], [13], [17], [19], [23], [29]),
//     bringing every column summit to the uniform 84.00mm waterline flush against the lid.
//   - Interior features large high-contrast debossed prime numerals on all socket floors
//     and on the vertical front faces of all elevated pedestals.
//   - Snapfinity stackable lid caps the top of the sliding front door, locking it securely shut.

$fn = 16;
tray_w = 125.5;
tray_h = 42.0;
bin_h = 91.0;
lip_h = 4.4;
floor_h = 3.5;
door_h = bin_h - floor_h; // 87.5mm


row0_labels = ["2", "2", "3", "3", "5", "7"];
row0_riser  = [0.00, 0.00, 6.34, 6.34, 2.73, 5.39];

row1_labels = ["11", "13", "17", "19", "23", "29"];
row1_riser  = [11.35, 6.29, 26.78, 24.53, 20.67, 15.99];

module prime_box_body() {
    gridfinity_caddy_box_body(
        tray_w = tray_w,
        tray_h = tray_h,
        bin_h = bin_h,
        lip_h = lip_h,
        title = "PRIME",
        badge_label = "FACT",
        badge_type = "prime"
    );
}

module prime_caddy() {
    column_caddy_chassis(
        tray_w = tray_w,
        tray_h = tray_h,
        bin_h = bin_h,
        caddy_h = 84.0,
        nx = 6,
        pitch_x = 19.60,
        pitch_y = 19.60,
        row0_y = 11.20,
        row1_y = 30.80,
        row0_labels = row0_labels,
        row1_labels = row1_labels,
        row0_riser = row0_riser,
        row1_riser = row1_riser,
        title = "PRIME"
    );
}

// Backward-compatible alias for manufacturing scripts
module prime_front_door() {
    prime_caddy();
}

module prime_lid_grid() {
    gridfinity_stackable_lid(
        nx = 3,
        ny = 1,
        miniblock_grid = true,
        detents = true,
        detent_sides = "ends",
        row0_labels = row0_labels,
        row1_labels = row1_labels,
        button_face = "FACT",
        button_sublabel = "",
        button_type = "prime",
        drop_front = false
    );
}

// ----------------------------------------------------------------------------
// Manufacturing Plate Layout (All 3 pieces on 250x210 bed, zero supports)
// ----------------------------------------------------------------------------
show_box   = true;
show_caddy = true;
show_lid   = true;

if (show_box)
    translate([0, 0, 3.0])
        prime_box_body();

if (show_caddy)
    // Sits flat on bed at Z=0 for high-speed, warp-free, support-free printing
    translate([0, 46.0, 0])
        prime_caddy();

if (show_lid)
    translate([0, 144.0, 0])
        prime_lid_grid();


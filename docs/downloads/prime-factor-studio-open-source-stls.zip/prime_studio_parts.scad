// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/part_metadata.scad>

// ============================================================================
// Component Metadata Contract (Single Source of Truth)
// ============================================================================
PART_SKU = "PRIME-01";
PART_REV = "a793ddd";
PART_NAME = "Prime Factor Studio Proportional Blocks";
PART_AMORTIZED_COST = 2.50;
PART_REPLACEMENT_PRICE = 3.99;

// StackCalc Learning Lab / prime_studio_parts
// 61 Stackable Prime Factor Blocks printed directly on the bed (Z=0).
// 0.5U Gridfinity miniblock footprint (19.0 x 19.0 mm).
// Harmonized 1U / 1/12th manipulative standard:
//   - Smallest tile [2] visible height h_vis = 7.00 mm (h_total = 8.85 mm with bottom base plug).
//   - Logarithmic constant: k_log = 7.0 / log10(2) = 23.25349666 mm per decade.
// Sorted by height from lowest ([2]s, front) to tallest ([29]s, back) for optimal FDM travel.
// 100% support-free with authentic 0.5U Gridfinity bottom base plug and recessed stacking socket.
// Exact Additive Mathematical Pitch: Total block height h = d_socket + h_vis.
// Subtractive socket nesting depth (1.85 mm) cancels on every joint:
// Every block p contributes EXACTLY h_vis = (7.0 / log10(2)) * log10(p) mm to the visible height.
// Stacking any combination physically sums the logarithms, landing on the product (1 to 1,000)!
// Pure Tactile Number System:
//   - All 4 vertical faces display the pure Prime Numeral (4-way rotational symmetry)
//   - Top Socket Floor: Debossed Numeral for top-down visual inventory audit

$fn = 16;
d_socket = 1.85;
k_log = 7.0 / log(2); // 23.25349666 mm per decade


module prime_block(p, prime_str, power=1) {
    h_unit = k_log * log(p);
    h_vis = power * h_unit;
    h = d_socket + h_vis;

    // Determine top socket marking (superscript exponents for powers)
    top_label = (power == 1) ? prime_str :
                (p == 2 && power == 2) ? "2²" :
                (p == 2 && power == 3) ? "2³" :
                (p == 3 && power == 2) ? "3²" :
                (p == 5 && power == 2) ? "5²" :
                str(prime_str, "^", power);

    difference() {
        union() {
            miniblock_base();
            translate([0, 0, 1.85 - 0.01])
                rounded_square([19.0, 19.0], r=1.8, h=h - 1.85 + 0.01);
        }

        // Each individual segment has centered numerals on all 4 faces (centered in [1.85, h - 1.85] solid wall)
        for (k = [0 : power - 1]) {
            z_c = 0.925 + (k + 0.5) * h_unit;
            block_side_markings(label=prime_str, h_vis=h_unit, z_center=z_c, depth=0.60);
        }

        // Seam reveal grooves between fused units: 45-degree V-groove (0.80mm tall, 0.40mm deep)
        // Authentic visual joints matching real stacked blocks while preserving a solid 18.2mm structural core
        if (power > 1) {
            for (k = [1 : power - 1]) {
                z_seam = d_socket + k * h_unit;
                translate([0, 0, z_seam])
                    difference() {
                        cube([24.0, 24.0, 0.80], center=true);
                        hull() {
                            translate([0, 0, 0.40])  rounded_square([21.0, 21.0], r=2.0, h=0.01);
                            translate([0, 0, 0.00])  rounded_square([19.0 - 0.80, 19.0 - 0.80], r=1.4, h=0.01);
                            translate([0, 0, -0.40]) rounded_square([21.0, 21.0], r=2.0, h=0.01);
                        }
                    }
            }
        }

        // Top recessed stacking socket (Gridfinity profile)
        translate([0, 0, h - 1.85])
            miniblock_stacking_socket();

        // Top socket floor: Deep 45-degree shadow-chamfered debossed numeral/exponent
        block_top_socket_marking(label=top_label, h=h, depth=0.60);
    }
}

// 43 Pure Prime Factor Blocks for the 4-3-3-2 Eratosthenes 7U Prime Factor Studio (42.0mm = 2^6 = 64 waterline):
// Every column in the 6x2 box holds the maximum number of blocks of a single Eratosthenes prime {2, 3, 5, 7} that fits in 7U:
//   - Prime 2 (4 cols x 6): 24x [2] (6 * 7.00mm = 42.00mm, 0.00mm riser)
//   - Prime 3 (3 cols x 3):  9x [3] (3 * 11.10mm = 33.29mm, 8.71mm riser)
//   - Prime 5 (3 cols x 2):  6x [5] (2 * 16.25mm = 32.51mm, 9.49mm riser)
//   - Prime 7 (2 cols x 2):  4x [7] (2 * 19.65mm = 39.30mm, 2.70mm riser)
// Arranged in a compact 6x8 grid on the print bed, sorted from shortest ([2]) to tallest ([7]):
xs = [30.5, 51.5, 72.5, 93.5, 114.5, 135.5];
ys = [21.0, 42.0, 63.0, 84.0, 105.0, 126.0, 147.0, 168.0];

// Row 0 (Y = 21.0): 6x [2] (Column 0 supply)
translate([xs[0], ys[0], 0]) prime_block(2, "2", 1);
translate([xs[1], ys[0], 0]) prime_block(2, "2", 1);
translate([xs[2], ys[0], 0]) prime_block(2, "2", 1);
translate([xs[3], ys[0], 0]) prime_block(2, "2", 1);
translate([xs[4], ys[0], 0]) prime_block(2, "2", 1);
translate([xs[5], ys[0], 0]) prime_block(2, "2", 1);

// Row 1 (Y = 42.0): 6x [2] (Column 1 supply)
translate([xs[0], ys[1], 0]) prime_block(2, "2", 1);
translate([xs[1], ys[1], 0]) prime_block(2, "2", 1);
translate([xs[2], ys[1], 0]) prime_block(2, "2", 1);
translate([xs[3], ys[1], 0]) prime_block(2, "2", 1);
translate([xs[4], ys[1], 0]) prime_block(2, "2", 1);
translate([xs[5], ys[1], 0]) prime_block(2, "2", 1);

// Row 2 (Y = 63.0): 6x [2] (Column 2 supply)
translate([xs[0], ys[2], 0]) prime_block(2, "2", 1);
translate([xs[1], ys[2], 0]) prime_block(2, "2", 1);
translate([xs[2], ys[2], 0]) prime_block(2, "2", 1);
translate([xs[3], ys[2], 0]) prime_block(2, "2", 1);
translate([xs[4], ys[2], 0]) prime_block(2, "2", 1);
translate([xs[5], ys[2], 0]) prime_block(2, "2", 1);

// Row 3 (Y = 84.0): 6x [2] (Column 3 supply — 24x [2] total)
translate([xs[0], ys[3], 0]) prime_block(2, "2", 1);
translate([xs[1], ys[3], 0]) prime_block(2, "2", 1);
translate([xs[2], ys[3], 0]) prime_block(2, "2", 1);
translate([xs[3], ys[3], 0]) prime_block(2, "2", 1);
translate([xs[4], ys[3], 0]) prime_block(2, "2", 1);
translate([xs[5], ys[3], 0]) prime_block(2, "2", 1);

// Row 4 (Y = 105.0): 6x [3] (Columns 0 & 1 of [3])
translate([xs[0], ys[4], 0]) prime_block(3, "3", 1);
translate([xs[1], ys[4], 0]) prime_block(3, "3", 1);
translate([xs[2], ys[4], 0]) prime_block(3, "3", 1);
translate([xs[3], ys[4], 0]) prime_block(3, "3", 1);
translate([xs[4], ys[4], 0]) prime_block(3, "3", 1);
translate([xs[5], ys[4], 0]) prime_block(3, "3", 1);

// Row 5 (Y = 126.0): 3x [3] (Column 2 of [3] — 9x [3] total) + 3x [5]
translate([xs[0], ys[5], 0]) prime_block(3, "3", 1);
translate([xs[1], ys[5], 0]) prime_block(3, "3", 1);
translate([xs[2], ys[5], 0]) prime_block(3, "3", 1);
translate([xs[3], ys[5], 0]) prime_block(5, "5", 1);
translate([xs[4], ys[5], 0]) prime_block(5, "5", 1);
translate([xs[5], ys[5], 0]) prime_block(5, "5", 1);

// Row 6 (Y = 147.0): 3x [5] (6x [5] total) + 3x [7]
translate([xs[0], ys[6], 0]) prime_block(5, "5", 1);
translate([xs[1], ys[6], 0]) prime_block(5, "5", 1);
translate([xs[2], ys[6], 0]) prime_block(5, "5", 1);
translate([xs[3], ys[6], 0]) prime_block(7, "7", 1);
translate([xs[4], ys[6], 0]) prime_block(7, "7", 1);
translate([xs[5], ys[6], 0]) prime_block(7, "7", 1);

// Row 7 (Y = 168.0): 1x [7] (4x [7] total)
translate([xs[0], ys[7], 0]) prime_block(7, "7", 1);


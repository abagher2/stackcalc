// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/part_metadata.scad>

// ============================================================================
// Component Metadata Contract (Single Source of Truth)
// ============================================================================
PART_SKU = "PRIME-01";
PART_REV = "a793ddd";
PART_NAME = "Prime Factor Studio Proportional Blocks";
PART_AMORTIZED_COST = 2.30;
PART_REPLACEMENT_PRICE = 3.49;

// StackCalc Learning Lab / prime_studio_parts
// 29 Stackable Prime Factor Blocks printed directly on the bed (Z=0).
// 0.5U Gridfinity miniblock footprint (19.0 x 19.0 mm).
// Sorted by height from lowest ([2]s, front) to tallest ([23], back) for optimal FDM travel.
// 100% support-free with authentic 0.5U Gridfinity male base and female stacking socket.
// Exact Additive Mathematical Pitch: Total block height h = d_socket + h_vis.
// Subtractive socket nesting depth (1.85 mm) cancels on every joint:
// Every block p contributes EXACTLY h_vis = 42.0 * log10(p) mm to the visible height.
// Stacking any combination physically sums the logarithms, landing on the product (1 to 100)!
// Pure Tactile Number System:
//   - All 4 vertical faces display the pure Prime Numeral (4-way rotational symmetry)
//   - Top Socket Floor: Debossed Numeral for top-down visual inventory audit

$fn = 16;
d_socket = 1.85;
H_unit = 84.0; // Benchmark for 100 (42.0 * log10(100) = 84.0mm)

module rounded_square(dim, r=1.8, h=1) {
    linear_extrude(h) offset(r=r) offset(delta=-r) square([dim[0], dim[1]], center=true);
}

// 100% Self-Supporting 0.5-Unit Gridfinity Male Base (19.0 x 19.0 mm footprint)
module miniblock_base() {
    hull() {
        rounded_square([17.0, 17.0], r=1.0, h=0.02);
        translate([0, 0, 0.70]) rounded_square([18.4, 18.4], r=1.4, h=0.02);
    }
    translate([0, 0, 0.70])
        rounded_square([18.4, 18.4], r=1.4, h=0.25);
    hull() {
        translate([0, 0, 0.95]) rounded_square([18.4, 18.4], r=1.4, h=0.02);
        translate([0, 0, 1.85]) rounded_square([19.0, 19.0], r=1.8, h=0.02);
    }
}

// Sturdy 2-Perimeter Stacking Socket (Slant 3D DFM: 0.40mm slip-fit clearance, concentric 0.10mm rim)
module miniblock_stacking_socket() {
    hull() {
        translate([0, 0, -0.05]) rounded_square([17.5, 17.5], r=1.1, h=0.02);
        translate([0, 0, 0.70]) rounded_square([18.8, 18.8], r=1.7, h=0.02);
    }
    translate([0, 0, 0.70])
        rounded_square([18.8, 18.8], r=1.7, h=0.25);
    hull() {
        translate([0, 0, 0.95]) rounded_square([18.8, 18.8], r=1.7, h=0.02);
        translate([0, 0, 1.85 + 0.05]) rounded_square([18.8, 18.8], r=1.7, h=0.02);
    }
}

function calc_prime_side_font_size(str, bh) =
    let(l = len(str),
        scale = min(1.6, max(1.0, bh / 4.0)))
    min(
        (bh - 0.7) * 0.65,
        scale * (l >= 5 ? 2.1 : (l >= 4 ? 2.3 : (l >= 3 ? 2.6 : (l >= 2 ? 2.8 : 3.4))))
    );

module prime_block(p, prime_str) {
    h_vis = 42.0 * log(p);
    h = d_socket + h_vis;

    z_ctr = h / 2;
    badge_h = min(12.0, max(3.6, min(h_vis - 2.8, h_vis * 0.50)));
    badge_w = 14.0;
    f_size = calc_prime_side_font_size(prime_str, badge_h);

    difference() {
        union() {
            miniblock_base();
            translate([0, 0, 1.85 - 0.01])
                rounded_square([19.0, 19.0], r=1.8, h=h - 1.85 + 0.01);
        }

        // All 4 vertical faces: Pure Prime Numeral with tactile macro-louvers
        for (a = [0, 90, 180, 270]) {
            rotate([0, 0, a])
                translate([0, -19.0/2, z_ctr])
                    rotate([90, 0, 0])
                        tactile_block_badge(
                            w=badge_w,
                            h=badge_h,
                            label=prime_str,
                            font_size=f_size,
                            r=0.8,
                            depth=0.40,
                            vertical=true
                        );
        }

        // Top female stacking socket (Gridfinity profile)
        translate([0, 0, h - 1.85])
            miniblock_stacking_socket();

        // Top socket floor tactile badge (top-down, vertical=false, flat datum)
        top_font_size = (len(prime_str) >= 4 ? 2.8 : (len(prime_str) >= 2 ? 3.4 : 4.4));
        translate([0, 0, h - 1.85])
            tactile_block_badge(
                w=13.0,
                h=13.0,
                label=prime_str,
                font_size=top_font_size,
                r=1.0,
                depth=0.45,
                vertical=false
            );
    }
}

// 29 Stackable Prime Factor Blocks on 200x200mm print bed:
// Spacing: pitch = 22.0mm.
xs = [20.0, 42.0, 64.0, 86.0, 108.0, 130.0];

// Row 0 (Y = 160.0): 6x [2]s (Blue, h_vis = 12.64mm)
translate([xs[0], 160.0, 0]) prime_block(2, "2");
translate([xs[1], 160.0, 0]) prime_block(2, "2");
translate([xs[2], 160.0, 0]) prime_block(2, "2");
translate([xs[3], 160.0, 0]) prime_block(2, "2");
translate([xs[4], 160.0, 0]) prime_block(2, "2");
translate([xs[5], 160.0, 0]) prime_block(2, "2");

// Row 1 (Y = 136.0): 6x [2]s (Blue, h_vis = 12.64mm) - Completes 12x [2]s
translate([xs[0], 136.0, 0]) prime_block(2, "2");
translate([xs[1], 136.0, 0]) prime_block(2, "2");
translate([xs[2], 136.0, 0]) prime_block(2, "2");
translate([xs[3], 136.0, 0]) prime_block(2, "2");
translate([xs[4], 136.0, 0]) prime_block(2, "2");
translate([xs[5], 136.0, 0]) prime_block(2, "2");

// Row 2 (Y = 112.0): 6x [3]s (Green, h_vis = 20.04mm)
translate([xs[0], 112.0, 0]) prime_block(3, "3");
translate([xs[1], 112.0, 0]) prime_block(3, "3");
translate([xs[2], 112.0, 0]) prime_block(3, "3");
translate([xs[3], 112.0, 0]) prime_block(3, "3");
translate([xs[4], 112.0, 0]) prime_block(3, "3");
translate([xs[5], 112.0, 0]) prime_block(3, "3");

// Row 3 (Y = 88.0): 2x [3]s (Green) + 2x [5]s (Yellow) + 2x [7]s (Purple)
translate([xs[0], 88.0, 0]) prime_block(3, "3");
translate([xs[1], 88.0, 0]) prime_block(3, "3");
translate([xs[2], 88.0, 0]) prime_block(5, "5");
translate([xs[3], 88.0, 0]) prime_block(5, "5");
translate([xs[4], 88.0, 0]) prime_block(7, "7");
translate([xs[5], 88.0, 0]) prime_block(7, "7");

// Row 4 (Y = 64.0): Semi-primes [11], [13], [17], [19], [23] (Red / Coral)
translate([xs[0], 64.0, 0]) prime_block(11, "11");
translate([xs[1], 64.0, 0]) prime_block(13, "13");
translate([xs[2], 64.0, 0]) prime_block(17, "17");
translate([xs[3], 64.0, 0]) prime_block(19, "19");
translate([xs[4], 64.0, 0]) prime_block(23, "23");

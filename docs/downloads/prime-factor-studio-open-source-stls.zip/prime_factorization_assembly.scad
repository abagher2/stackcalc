// ============================================================================
// Prime Factor Studio: Physical Tower Assembly & Comparator Scale Verification
// ============================================================================
// Demonstrates exact physical alignment of prime factorization towers standing
// on the desk (Z=0) against the logarithmic slide rule scale on the 3x1x13U box.
//
// Displayed Factorizations:
// 1. N = 2   : [2]               (Single block, Teal)
// 2. N = 4   : [2] x [2]         (Square of 2, Teal + Teal)
// 3. N = 6   : [2] x [3]         (Semi-prime, Teal + Amber)
// 4. N = 10  : [2] x [5]         (Decade benchmark, Teal + Royal Blue)
// 5. N = 20  : [2] x [2] x [5]   (Composite, Teal + Teal + Royal Blue)
// 6. N = 50  : [2] x [5] x [5]   (Composite square, Teal + 2x Royal Blue)
// 7. N = 100 : [2]^2 x [5]^2     (Full scale benchmark, 2x Teal + 2x Royal Blue)

use <prime_studio_box.scad>
use <prime_studio_parts.scad>

$fn = 24;

// Colors
COLOR_BOX   = [0.93, 0.92, 0.90]; // Warm Bone / Off-White
COLOR_P2    = [0.03, 0.50, 0.51]; // Teal
COLOR_P3    = [0.85, 0.55, 0.15]; // Amber
COLOR_P5    = [0.20, 0.40, 0.65]; // Royal Blue
COLOR_P7    = [0.70, 0.25, 0.25]; // Crimson
COLOR_P11   = [0.30, 0.60, 0.35]; // Forest Green
COLOR_TABLE = [0.22, 0.25, 0.28]; // Dark Slate Surface

function get_prime_color(p) =
    (p == 2) ? COLOR_P2 :
    (p == 3) ? COLOR_P3 :
    (p == 5) ? COLOR_P5 :
    (p == 7) ? COLOR_P7 :
    (p == 11) ? COLOR_P11 : [0.5, 0.5, 0.5];

// 1. Desk Surface Plane (Z = 0)
module desktop_surface() {
    color(COLOR_TABLE)
        translate([62.75, 42.0, -1.0])
            cube([200.0, 140.0, 2.0], center=true);
}

// 2. 3x1x13U Storage Box seated on Desk
// Base plugs extend 3.0mm below floor, resting at Z = 0
module assembled_box() {
    translate([0, 0, 3.0])
        box_plate();
}

// 3. Modular Tower Assembly on Desk
// Bottom block base rests on desk at Z = 0.
// Each subsequent block stacks into the top socket, sinking 1.85mm.
module prime_tower(factors) {
    for (i = [0 : len(factors) - 1]) {
        p = factors[i];
        // Calculate stacking elevation: sum of visible heights of prior blocks
        z_offset = (i == 0) ? 0 : 42.0 * log(
            (i == 1) ? factors[0] :
            (i == 2) ? factors[0] * factors[1] :
            (i == 3) ? factors[0] * factors[1] * factors[2] :
                       factors[0] * factors[1] * factors[2] * factors[3]
        );
        translate([0, 0, z_offset])
            color(get_prime_color(p))
                prime_block(p, str(p));
    }
}

// ============================================================================
// Scene Setup: Lineup of 6 Factorization Towers
// ============================================================================
desktop_surface();
assembled_box();

// Distance in front of back wall (Y = 41.75 + 9.5 + clearance)
tower_y = 41.75 + 9.5 + 1.2;

// Tower 1: N = 2 (Single [2], Teal) -> Z = 14.49mm (Box Z = 11.49mm)
translate([13.0, tower_y, 0])
    prime_tower([2]);

// Tower 2: N = 4 (2^2: [2] + [2], Teal) -> Z = 27.14mm (Box Z = 24.14mm)
translate([33.0, tower_y, 0])
    prime_tower([2, 2]);

// Tower 3: N = 6 (2 x 3: [2] + [3], Teal + Amber) -> Z = 34.53mm (Box Z = 31.53mm)
translate([53.0, tower_y, 0])
    prime_tower([2, 3]);

// Tower 4: N = 10 (2 x 5: [2] + [5], Teal + Royal Blue) -> Z = 43.85mm (Box Z = 40.85mm)
translate([73.0, tower_y, 0])
    prime_tower([2, 5]);

// Tower 5: N = 20 (2^2 x 5: [2] + [2] + [5]) -> Z = 56.49mm (Box Z = 53.49mm)
translate([92.5, tower_y, 0])
    prime_tower([2, 2, 5]);

// Tower 6: N = 50 (2 x 5^2: [2] + [5] + [5]) -> Z = 73.21mm (Box Z = 70.21mm)
translate([112.5, tower_y, 0])
    prime_tower([2, 5, 5]);

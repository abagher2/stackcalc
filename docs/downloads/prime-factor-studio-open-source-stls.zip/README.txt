================================================================================
STACKCALC LEARNING LAB // PRIME FACTOR STUDIO & COMPARATOR SCALE (PRIME-01)
================================================================================
Open-Source 3D Printable STL & OpenSCAD Source Pack
Standard: Zack Freedman 42mm Gridfinity Ecosystem (13U Master Height)
Target Grades: 3 - 9 (Prime factorization, prime vs composite, Fundamental Theorem of Arithmetic)

CONTENTS:
1. prime_studio_parts.stl / prime_studio_parts.scad
   - 29 Proportional Stacking Prime Factor Blocks:
     12x [2]  (Teal / Blue,      h_vis = 42.0 * log10(2)  = 12.64 mm)
      8x [3]  (Green / Amber,    h_vis = 42.0 * log10(3)  = 20.04 mm)
      2x [5]  (Royal Blue / Gold, h_vis = 42.0 * log10(5)  = 29.36 mm)
      2x [7]  (Crimson / Purple,  h_vis = 42.0 * log10(7)  = 35.49 mm)
      1x each of [11], [13], [17], [19], [23] (Red / Coral semi-prime markers)
   - Additive Logarithmic Pitch: Each block's visible stacking height is exactly 42.0 * log10(p).
   - Stacking blocks physically sums their logarithms, measuring product N against the box scale!

2. prime_studio_box.stl / prime_studio_box.scad
   - 3x1x13U Gridfinity Enclosure Box (125.5 x 42.0 x 91.0 mm body, 95.4mm with lip).
   - Front debossed instrument plaque: "PRIME"
   - Rear button badge: "[FACT]"
   - Back Wall Bilateral Logarithmic Slide Rule Comparator Scale (1 to 100):
     Towers resting on desk (Z=0) align perfectly (0.000 mm error) with engraved marks
     (2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100).
   - Stackable lid with prime power sockets (2^6, 3^4, 5^2, 7^2, 11, 13, 17, 19, 23, GCD).

3. prime_factorization_assembly.scad
   - OpenSCAD scene verifying 6 simultaneous factorization towers ([2], [4], [6], [10], [20], [50])
     standing against the comparator scale.

PRINT SETTINGS:
- Layer Height: 0.20 mm Standard (0.12 mm for fine prime block legends)
- Infill: 15% - 20% Gyroid
- Supports: NONE (100% Support-Free)
- Material: PLA 2.0+ or PETG

License: CERN Open Hardware License v2 - Strongly Reciprocal
Web: https://stackcalc.io/products/prime-factor-studio/
Etsy Store: https://stackcalcmath.etsy.com
================================================================================

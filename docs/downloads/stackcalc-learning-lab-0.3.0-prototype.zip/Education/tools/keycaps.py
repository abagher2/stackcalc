"""Canonical Hardware Trapezoid Keycap generator for StackCalc educational materials.

Directly reads Firmware/Simulator/labels.json and the TeX-rendered math bitmaps
in Firmware/Simulator/labels/ to ensure single-source-of-truth parity.
Generates authentic HP-32 Pioneer tapered trapezoid caps conforming to
Hardware/designs/buttons.scad and RPNCore/Sources/RPNCore/Display/HP32PhysicalLayout.swift.
All output is rendered with smooth fillets and thresholded for high-contrast black-and-white print.
"""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
SIMULATOR_DIR = REPO_ROOT / "Firmware" / "Simulator"
LABELS_JSON = SIMULATOR_DIR / "labels.json"
BITMAPS_DIR = SIMULATOR_DIR / "labels"
FONTS_DIR = REPO_ROOT / "Shared" / "Fonts"
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "build" / "keycaps"
KEYCAPS_DIR = OUTPUT_DIR

SPACE_MONO_BOLD = FONTS_DIR / "SpaceMono-Bold.ttf"
SPACE_MONO_REGULAR = FONTS_DIR / "SpaceMono-Regular.ttf"


def load_manifest():
    if not LABELS_JSON.exists():
        raise FileNotFoundError(f"Key manifest not found at {LABELS_JSON}")
    with open(LABELS_JSON, "r", encoding="utf-8") as f:
        return json.load(f)


def sanitize_filename(name: str) -> str:
    replacements = {
        "+": "plus",
        "-": "minus",
        "×": "times",
        "*": "times",
        "÷": "divide",
        "/": "divide",
        ".": "dot",
        "√𝑥": "sqrt_x",
        "sqrt": "sqrt_x",
        "𝑥²": "x_squared",
        "x^2": "x_squared",
        "𝑦ˣ": "y_to_x",
        "𝑥!": "x_factorial",
        "¹/𝑥": "one_over_x",
        "𝑥⁻¹": "one_over_x",
        "+/-": "plus_minus",
        "<-": "backspace",
        "𝑥⇄𝑦": "x_swap_y",
        "π": "pi",
        "Σ+": "sigma_plus",
        "Σ-": "sigma_minus",
        "yellow": "shift_yellow",
        "blue": "shift_blue",
        "=": "equals",
        "?": "help",
    }
    cleaned = replacements.get(name, name)
    for ch in [" ", "(", ")", ",", "/", "\\", ":", ";"]:
        cleaned = cleaned.replace(ch, "_")
    return cleaned.strip("_").lower()


def draw_rounded_trapezoid(draw, cx, cy, w, h, slant, r, fill=None, outline=None, width=1):
    """Draw a smooth trapezoid with rounded corners."""
    r = max(1.0, min(r, h / 2.0 - 1.0, (w - 2.0 * slant) / 2.0 - 1.0))
    c0 = (cx - w / 2.0 + r, cy + h / 2.0 - r)
    c1 = (cx + w / 2.0 - r, cy + h / 2.0 - r)
    c2 = (cx + w / 2.0 - slant - r, cy - h / 2.0 + r)
    c3 = (cx - w / 2.0 + slant + r, cy - h / 2.0 + r)

    if fill is not None:
        for c in [c0, c1, c2, c3]:
            draw.ellipse([c[0] - r, c[1] - r, c[0] + r, c[1] + r], fill=fill)
        for a, b in [(c0, c1), (c1, c2), (c2, c3), (c3, c0)]:
            draw.line([a, b], fill=fill, width=int(round(2 * r)))
        draw.polygon([c0, c1, c2, c3], fill=fill)

    if outline and width > 0:
        for a, b in [(c0, c1), (c1, c2), (c2, c3), (c3, c0)]:
            draw.line([a, b], fill=outline, width=int(width))


class HardwareKeycapRenderer:
    """Renders canonical HP-32 Pioneer hardware trapezoid button caps."""
    def __init__(self, target_height_px: int = 88):
        self.target_height = target_height_px
        # HP-32 physical cap height is 5.5 mm (from buttons.scad and HP32PhysicalLayout.swift)
        self.scale = target_height_px / 5.5
        self.manifest = load_manifest()
        self.keys = self.manifest.get("keys", [])
        self.key_map = self._build_key_map()

    def _build_key_map(self):
        m = {}
        for k in self.keys:
            label = k.get("label", "")
            if label:
                m[label] = k
                m[sanitize_filename(label)] = k

            # Map primaryLegend text
            p_text = k.get("primaryLegend", {}).get("text", "")
            if p_text and p_text not in m:
                m[p_text] = k
                m[sanitize_filename(p_text)] = k

            # Map yellowLabel
            y_label = k.get("yellowLabel", "")
            if y_label:
                m[f"yellow_{y_label}"] = (k, "yellow")
                m[sanitize_filename(f"yellow_{y_label}")] = (k, "yellow")

            # Map blueLabel
            b_label = k.get("blueLabel", "")
            if b_label:
                m[f"blue_{b_label}"] = (k, "blue")
                m[sanitize_filename(f"blue_{b_label}")] = (k, "blue")

        # Aliases for lessons
        aliases = {
            "enter": "ENTER",
            "+": "+",
            "-": "-",
            "*": "×",
            "x": "×",
            "/": "÷",
            ".": ".",
            "sqrt": "√𝑥",
            "x^2": "yellow_𝑥²",
            "lastx": "yellow_LAST𝑥",
            "modes": "yellow_MODES",
            "backspace": "<-",
            "drop": "<-",
            "yellow": "yellow",
            "blue": "blue",
            "shift": "yellow",
        }
        for alias, target in aliases.items():
            if target in m:
                m[alias] = m[target]
        return m

    def render_key(self, key_data, active_shift: str = None) -> Image.Image:
        label = key_data.get("label", "")
        row = key_data.get("row", 4)
        is_enter = (label == "ENTER" or key_data.get("primaryOperation") == 26)

        # Hardware dimensions from buttons.scad & HP32PhysicalLayout.swift:
        # - ENTER cap: 18.4 mm x 5.5 mm
        # - Lower matrix arithmetic buttons (rows 4–7): 8.6 mm x 5.5 mm
        # - Upper function row buttons (rows 0–3): 7.0 mm x 5.5 mm
        # - Lateral slant: 0.8 mm
        if is_enter:
            w_mm = 18.4
            h_mm = 5.5
            slant_mm = 0.8
        elif row >= 4:
            w_mm = 8.6
            h_mm = 5.5
            slant_mm = 0.8
        else:
            w_mm = 7.0
            h_mm = 5.5
            slant_mm = 0.8

        r_mm = 0.85
        trench_mm = 0.45

        # 4x supersampling for crisp antialiased rendering before 1-bit thresholding
        ss = 4
        scale = self.scale * ss
        w_px = w_mm * scale
        h_px = h_mm * scale
        slant_px = slant_mm * scale
        r_px = r_mm * scale
        trench_px = trench_mm * scale

        pad = int(round(trench_px + 3 * ss))
        canvas_w = int(round(w_px + 2 * pad))
        canvas_h = int(round(h_px + 2 * pad))

        cx = canvas_w / 2.0
        cy = canvas_h / 2.0

        img = Image.new("RGBA", (canvas_w, canvas_h), (255, 255, 255, 0))
        draw = ImageDraw.Draw(img)

        # 1. Outer recessed trench (black base cavity)
        trench_w = w_px + 2 * trench_px
        trench_h = h_px + 2 * trench_px
        draw_rounded_trapezoid(
            draw, cx, cy, trench_w, trench_h, slant_px, r_px + trench_px,
            fill=(25, 25, 25, 255)
        )

        # 2. Main trapezoid cap body
        is_shift_key = (label in ("yellow", "blue") or key_data.get("primaryOperation") in (129, 130) or active_shift is not None)
        if is_shift_key:
            cap_fill = (35, 35, 35, 255)
            text_color = (255, 255, 255, 255)
        else:
            cap_fill = (255, 255, 255, 255)
            text_color = (0, 0, 0, 255)

        draw_rounded_trapezoid(
            draw, cx, cy, w_px, h_px, slant_px, r_px,
            fill=cap_fill
        )

        # 3. Inner tactile bevel line
        bevel_inset = 1.2 * ss
        bevel_color = (80, 80, 80, 255) if is_shift_key else (160, 160, 160, 255)
        draw_rounded_trapezoid(
            draw, cx, cy, w_px - 2 * bevel_inset, h_px - 2 * bevel_inset, slant_px, max(1.0, r_px - bevel_inset),
            outline=bevel_color, width=max(1, int(0.75 * ss))
        )

        # 4. Legend positioning (centered on trapezoid face)
        center_x = cx
        center_y = cy + 0.5 * ss

        primary_legend = key_data.get("primaryLegend", {})
        bitmap_id = primary_legend.get("bitmapIdentifier")

        if active_shift == "yellow":
            y_label = key_data.get("yellowLabel", "")
            y_legend = key_data.get("yellowLegend", {})
            y_bmp = y_legend.get("bitmapIdentifier")
            if y_bmp and (BITMAPS_DIR / f"{y_bmp}.png").exists():
                bitmap_id = y_bmp
                label = ""
            else:
                label = y_label
                bitmap_id = None
        elif active_shift == "blue":
            b_label = key_data.get("blueLabel", "")
            b_legend = key_data.get("blueLegend", {})
            b_bmp = b_legend.get("bitmapIdentifier")
            if b_bmp and (BITMAPS_DIR / f"{b_bmp}.png").exists():
                bitmap_id = b_bmp
                label = ""
            else:
                label = b_label
                bitmap_id = None

        if label in ("yellow", "shift_yellow") or key_data.get("primaryOperation") == 129:
            shift_text = "YELLOW"
            font_size = int(10 * ss)
            font = ImageFont.truetype(str(SPACE_MONO_BOLD), font_size)
            bbox = font.getbbox(shift_text)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            draw.text((center_x - tw / 2.0, center_y - th / 2.0 - bbox[1]), shift_text, font=font, fill=text_color)
        elif label in ("blue", "shift_blue") or key_data.get("primaryOperation") == 130:
            shift_text = "BLUE"
            font_size = int(11 * ss)
            font = ImageFont.truetype(str(SPACE_MONO_BOLD), font_size)
            bbox = font.getbbox(shift_text)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            draw.text((center_x - tw / 2.0, center_y - th / 2.0 - bbox[1]), shift_text, font=font, fill=text_color)
        elif bitmap_id and (BITMAPS_DIR / f"{bitmap_id}.png").exists():
            bmp_path = BITMAPS_DIR / f"{bitmap_id}.png"
            with Image.open(bmp_path) as bmp:
                bmp = bmp.convert("RGBA")
                max_w = w_px - int(12 * ss)
                max_h = h_px - int(7 * ss)
                ratio = min(max_w / bmp.width, max_h / bmp.height)
                new_size = (max(1, int(bmp.width * ratio)), max(1, int(bmp.height * ratio)))
                bmp_resized = bmp.resize(new_size, Image.Resampling.LANCZOS)

                r, g, b, a = bmp_resized.split()
                glyph_color = (255, 255, 255, 255) if is_shift_key else (0, 0, 0, 255)
                pure_glyph = Image.new("RGBA", new_size, glyph_color)
                paste_x = int(center_x - new_size[0] / 2.0)
                paste_y = int(center_y - new_size[1] / 2.0)
                img.paste(pure_glyph, (paste_x, paste_y), mask=a)
        else:
            text = label or primary_legend.get("text", "")
            if text:
                if len(text) == 1:
                    font_size = int(16 * ss)
                elif len(text) <= 3:
                    font_size = int(12 * ss)
                elif len(text) <= 5:
                    font_size = int(9.5 * ss)
                else:
                    font_size = int(8 * ss)

                font = ImageFont.truetype(str(SPACE_MONO_BOLD), font_size)
                bbox = font.getbbox(text)
                tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
                draw.text((center_x - tw / 2.0, center_y - th / 2.0 - bbox[1]), text, font=font, fill=text_color)

        # Downsample to target size with anti-aliasing
        final_w = int(round(canvas_w / ss))
        final_h = int(round(canvas_h / ss))
        final_img = img.resize((final_w, final_h), Image.Resampling.LANCZOS)
        return final_img

    def render_named(self, name: str) -> Image.Image:
        item = self.key_map.get(name) or self.key_map.get(sanitize_filename(name))
        if item is None:
            synthetic = {
                "capWidth": 8.6 if len(name) <= 3 else (14.0 if len(name) <= 5 else 18.4),
                "capHeight": 5.5,
                "label": name,
                "primaryLegend": {"text": name},
                "row": 4,
            }
            return self.render_key(synthetic)

        if isinstance(item, tuple):
            key_data, shift_kind = item
            return self.render_key(key_data, active_shift=shift_kind)
        return self.render_key(item)

    def generate_all(self):
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        rendered_count = 0

        for key in self.keys:
            label = key.get("label", "")
            if not label:
                continue
            fname = sanitize_filename(label) + ".png"
            img = self.render_key(key)
            img.save(OUTPUT_DIR / fname, "PNG")
            rendered_count += 1
            if label != sanitize_filename(label) and "/" not in label and "\\" not in label:
                img.save(OUTPUT_DIR / f"{label}.png", "PNG")

        for key in self.keys:
            y_lbl = key.get("yellowLabel", "")
            if y_lbl:
                fname = sanitize_filename(f"yellow_{y_lbl}") + ".png"
                img = self.render_key(key, active_shift="yellow")
                img.save(OUTPUT_DIR / fname, "PNG")
                rendered_count += 1
                if y_lbl != sanitize_filename(y_lbl) and "/" not in y_lbl and "\\" not in y_lbl:
                    img.save(OUTPUT_DIR / f"yellow_{y_lbl}.png", "PNG")

        # Common ASCII / lesson aliases
        common_aliases = {
            "yellow_x_squared.png": "yellow_𝑥².png",
            "yellow_x_factorial.png": "yellow_𝑥!.png",
            "x_squared.png": "yellow_𝑥².png",
            "x_factorial.png": "yellow_𝑥!.png",
            "yellow_lastx.png": "yellow_last𝑥.png",
            "one_over_x.png": "¹_𝑥.png",
            "times.png": "×.png",
            "divide.png": "÷.png",
            "plus.png": "+.png",
            "minus.png": "-.png",
            "dot.png": "..png",
        }
        for alias, src_name in common_aliases.items():
            src_path = OUTPUT_DIR / src_name
            if src_path.exists():
                (OUTPUT_DIR / alias).write_bytes(src_path.read_bytes())

        print(f"Generated {rendered_count} thresholded Hardware Trapezoid keycap assets into {OUTPUT_DIR}")



# Backward-compatibility alias
RetroFuturismKeyRenderer = HardwareKeycapRenderer


if __name__ == "__main__":
    renderer = HardwareKeycapRenderer()
    renderer.generate_all()

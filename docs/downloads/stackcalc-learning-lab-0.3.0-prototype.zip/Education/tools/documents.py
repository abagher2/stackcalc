"""Teacher curriculum guide, reference cards, and student proficiency trials for StackCalc Learning Lab.

Revision 0.3.0:
- Detailed lesson plans for Singapore Dimensions Math, Big Ideas Math, Bridges in Mathematics, and AP Standards
- Comprehensive K-12 coverage from Pre-K (Counting) through High School / AP (Trig, Exponentials, Combinatorics, CS)
- Master curriculum cross-reference index
- Keystrokes rendered as exact thresholded Hardware Trapezoid keycaps
- Gridfinity manipulative diagrams, follow-up lessons, and student practice worksheets
- UIL-style Calculator Applications timed student proficiency trials
"""
import argparse
from pathlib import Path
from PIL import Image

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.utils import simpleSplit
from reportlab.lib.units import mm

from catalog import catalog, INK, TEAL, GOLD, PAPER, REVISION, UNIT_HEIGHT, GRIDFINITY_PITCH
from generate import FONT_DIR
from curricula import (
    CURRICULUM_UNITS, CURRICULA_LESSONS, CURRICULUM_CROSS_REFERENCES,
    LessonPlan, CurriculumCrossReference, PROFICIENCY_TRIALS, ProficiencyTrial,
    ProficiencyProblem, get_all_trials
)
from keycaps import OUTPUT_DIR as KEYCAPS_DIR, sanitize_filename

pdfmetrics.registerFont(TTFont("Lab", str(FONT_DIR / "Vera.ttf")))
pdfmetrics.registerFont(TTFont("LabBold", str(FONT_DIR / "VeraBd.ttf")))
PARTS = {p.id: p for p in catalog()}


class Page:
    def __init__(self, c, size):
        self.c = c
        self.w, self.h = [v / mm for v in size]

    def text(self, x, y, text, size=3.7, bold=False, color=INK):
        self.c.setFillColor(HexColor(color))
        self.c.setFont("LabBold" if bold else "Lab", size * mm)
        self.c.drawString(x * mm, (self.h - y) * mm, text)

    def para(self, x, y, text, width=None, size=3.6, color=INK):
        lines = simpleSplit(text, "Lab", size * mm, (width or self.w - x - 18) * mm)
        for line in lines:
            self.text(x, y, line, size, color=color)
            y += size * 1.55
        return y + 3

    def rect(self, x, y, w, h, color=PAPER, stroke=None, r=0):
        self.c.setFillColor(HexColor(color))
        if stroke:
            self.c.setStrokeColor(HexColor(stroke))
        self.c.roundRect(x * mm, (self.h - y - h) * mm, w * mm, h * mm, r * mm, fill=1, stroke=bool(stroke))

    def line(self, x, y, x2, y2, color=TEAL, width=0.25):
        self.c.setStrokeColor(HexColor(color))
        self.c.setLineWidth(width * mm)
        self.c.line(x * mm, (self.h - y) * mm, x2 * mm, (self.h - y2) * mm)

    def header(self, kicker, title, subtitle):
        self.text(18, 16, "STACKCALC / LEARNING LAB", 3, bold=True, color=TEAL)
        self.text(18, 26, kicker.upper(), 2.7, color=TEAL)
        self.text(18, 37, title, 7.0, bold=True)
        self.para(18, 46, subtitle, size=3.2)
        self.line(18, 56, self.w - 18, 56, color=GOLD, width=0.8)

    def footer(self, number, doc_title="CURRICULAR TEACHER GUIDE"):
        self.line(18, self.h - 14, self.w - 18, self.h - 14, color="#c3d3cd")
        self.text(18, self.h - 8, f"COLLECTION 01 / REVISION {REVISION} / {doc_title.upper()}", 2.2)
        self.text(self.w - 24, self.h - 8, str(number), 2.6, bold=True)

    def note(self, y, title, body):
        self.rect(18, y, self.w - 36, 22, color="#e5efeb", r=2)
        self.text(22, y + 6, title, 3.4, bold=True, color=TEAL)
        self.para(22, y + 12, body, width=self.w - 44, size=2.8)

    def draw_keycap(self, key_token: str, x: float, y: float, h: float = 6.0) -> float:
        """Draw an exact thresholded Hardware Trapezoid keycap and return its width in mm."""
        key_token = key_token.strip()
        fname = sanitize_filename(key_token) + ".png"
        img_path = KEYCAPS_DIR / fname

        alt_map = {
            "+": "plus.png",
            "-": "minus.png",
            "*": "times.png",
            "times": "times.png",
            "×": "times.png",
            "/": "divide.png",
            "divide": "divide.png",
            "÷": "divide.png",
            "enter": "enter.png",
            "ENTER": "enter.png",
            ".": "dot.png",
            "dot": "dot.png",
            "sqrt": "sqrt_x.png",
            "sqrt_x": "sqrt_x.png",
            "√𝑥": "sqrt_x.png",
            "x^2": "yellow_𝑥².png",
            "x²": "yellow_𝑥².png",
            "yellow_x_squared": "yellow_𝑥².png",
            "yellow_𝑥²": "yellow_𝑥².png",
            "x!": "yellow_𝑥!.png",
            "yellow_x!": "yellow_𝑥!.png",
            "yellow_𝑥!": "yellow_𝑥!.png",
            "plus_minus": "plus_minus.png",
            "+/-": "plus_minus.png",
            "polar": "yellow_▸θ_r.png",
            "yellow_▸θ_r": "yellow_▸θ_r.png",
            "to_polar": "yellow_▸θ_r.png",
            "x_swap_y": "x_swap_y.png",
            "x⇄y": "x_swap_y.png",
            "base": "yellow_base.png",
            "yellow_base": "yellow_base.png",
            "e^x": "𝑒ˣ.png",
            "𝑒ˣ": "𝑒ˣ.png",
            "y^x": "y_to_x.png",
            "y_to_x": "y_to_x.png",
            "ln": "ln.png",
            "LN": "ln.png",
            "sigma_plus": "sigma_plus.png",
            "Σ+": "sigma_plus.png",
            "sin": "sin.png",
            "cos": "cos.png",
            "tan": "tan.png",
            "c": "c.png",
            "clear": "yellow_clear.png",
            "yellow_clear": "yellow_clear.png",
            "lastx": "yellow_last𝑥.png",
            "yellow_lastx": "yellow_last𝑥.png",
            "yellow_last𝑥": "yellow_last𝑥.png",
            "1/x": "one_over_x.png",
            "one_over_x": "one_over_x.png",
            "backspace": "backspace.png",
            "<-": "backspace.png",
        }
        if not img_path.exists() and key_token in alt_map:
            img_path = KEYCAPS_DIR / alt_map[key_token]

        if img_path.exists():
            with Image.open(img_path) as im:
                w_px, h_px = im.size
            aspect = w_px / h_px
            w_mm = h * aspect
            self.c.drawImage(str(img_path), x * mm, (self.h - y - h) * mm,
                             width=w_mm * mm, height=h * mm, preserveAspectRatio=True, mask='auto')
            return w_mm
        else:
            # Fallback text pill box
            w_mm = max(7.0, len(key_token) * 3.0 + 3.0)
            self.rect(x, y, w_mm, h, color="#ffffff", stroke="#000000", r=1.0)
            self.text(x + w_mm / 2 - (len(key_token) * 0.9), y + h / 2 + 1.0, key_token, size=2.6, bold=True)
            return w_mm

    def draw_key_sequence(self, keys: list, x: float, y: float, h: float = 6.0, spacing: float = 1.6) -> float:
        cur_x = x
        for k in keys:
            w = self.draw_keycap(k, cur_x, y, h=h)
            cur_x += w + spacing
        return cur_x

    def diagram(self, part_id, x, y, width):
        if part_id not in PARTS:
            return
        p = PARTS[part_id]
        scale = width / p.width
        c = self.c
        c.saveState()
        c.translate(x * mm, (self.h - y) * mm)
        c.scale(scale * mm, -scale * mm)
        for shapes, fill in [(p.bodies, PAPER), (p.pockets, "#dce9e5")]:
            for s in shapes:
                c.setFillColor(HexColor(fill))
                c.setStrokeColor(HexColor(TEAL))
                c.setLineWidth(0.2)
                if s["kind"] == "circle":
                    c.circle(s["x"], s["y"], s["r"], fill=1, stroke=1)
                else:
                    c.roundRect(s["x"], s["y"], s["w"], s["h"], s["r"], fill=1, stroke=1)
        for l in p.lines:
            c.setStrokeColor(HexColor(TEAL))
            c.setLineWidth(l["width"])
            c.line(l["x1"], l["y1"], l["x2"], l["y2"])
        for s in p.pockets:
            c.setFillColor(HexColor("#dce9e5"))
            c.setLineWidth(0.2)
            if s["kind"] == "circle":
                c.circle(s["x"], s["y"], s["r"], fill=1, stroke=1)
            else:
                c.roundRect(s["x"], s["y"], s["w"], s["h"], s["r"], fill=1, stroke=1)
        for label in p.labels:
            c.saveState()
            c.translate(label["x"], label["y"])
            c.scale(1, -1)
            c.setFont("LabBold" if label["bold"] else "Lab", label["size"])
            c.setFillColor(HexColor(INK))
            (c.drawCentredString if label["align"] == "center" else c.drawString)(0, 0, label["text"])
            c.restoreState()
        c.restoreState()


def document(path, size):
    c = canvas.Canvas(str(path), pagesize=size, invariant=1, pageCompression=1)
    c.setTitle("StackCalc Learning Lab - Curriculum Guide")
    c.setAuthor("StackCalc")
    c.setSubject("Modular Gridfinity Manipulatives & Curricular Alignment")
    return c


def cards(path, size):
    c = document(path, size)
    p = Page(c, size)
    p.text(17, 16, "STACKCALC / POCKET LAB", 5.5, bold=True)
    p.para(17, 24, "Three single-sided reference cards. Two sets per sheet. Print at 100% / actual size.", size=3.0)
    gap = 8
    left = (p.w - 2 * 85.6 - gap) / 2
    for row, cid in enumerate(["card_stack", "card_fractions", "card_distance"]):
        for col in range(2):
            x, y = left + col * (85.6 + gap), 36 + row * 62
            p.diagram(cid, x, y, 85.6)
            for a, b, sx, sy in [(x, y, -1, -1), (x + 85.6, y, 1, -1), (x, y + 53.98, -1, 1), (x + 85.6, y + 53.98, 1, 1)]:
                p.line(a + sx * 0.7, b, a + sx * 2.7, b, color=INK, width=0.15)
                p.line(a, b + sy * 0.7, a, b + sy * 2.7, color=INK, width=0.15)
    p.line(18, 230, 68, 230, color=INK, width=0.4)
    p.line(18, 228, 18, 232, color=INK)
    p.line(68, 228, 68, 232, color=INK)
    p.text(73, 231, "This line must measure 50 mm.", 2.8)
    p.para(18, 240, "Trim to the outlines: 85.60 x 53.98 mm. Keep rounded corners. Inset lettering (0.4 mm).", size=2.8, width=p.w - 36)
    p.footer(1)
    c.showPage()
    c.save()


def curriculum_guide(path, size):
    c = document(path, size)

    def new_page(page_num, kicker, title, subtitle):
        p = Page(c, size)
        p.header(kicker, title, subtitle)
        p.footer(page_num)
        return p

    # -------------------------------------------------------------
    # PAGE 1: Overview & Gridfinity Hardware System
    # -------------------------------------------------------------
    p = new_page(1, "Modular Hardware & Curriculum Guide", "Make the Math Tangible.",
                 "Modular Gridfinity manipulatives and chapter-by-chapter lesson plans from Pre-K to Grade 12+.")
    
    # 6 station diagrams arranged across the page
    p.diagram("gridfinity_baseplate", 18, 64, 56)
    p.diagram("ten_frame_tray", 80, 64, 54)
    p.diagram("number_bond_stage", 140, 64, 52)

    p.diagram("number_rack", 18, 126, 54)
    p.diagram("fraction_tray", 78, 126, 56)
    p.diagram("stack_board", 140, 126, 52)

    p.text(18, 190, "ZERO-WASTE MODULAR PACKAGING: THE BOX IS THE LAB", 3.8, bold=True, color=TEAL)
    p.para(18, 197,
           "All activity stages adhere to the open-source 42.0 mm Gridfinity standard. The storage baseplate provides rock-solid physical support during classroom use and nests all manipulatives for compact storage. No disposable packaging.",
           size=2.9)
    p.text(18, 216, "SINGLE-OPERATION FDM PRINTING: 0.6 MM DEBOSSED TEXT", 3.8, bold=True, color=TEAL)
    p.para(18, 223,
           "Numerals, labels, and coordinate grids are debossed directly into top surfaces (0.6 mm deep, exactly 3 layers at 0.20 mm). Prints cleanly in PLA or PETG without secondary laser marking or multi-material setup.",
           size=2.9)
    p.text(18, 242, "FULL EDUCATIONAL SPAN: PRE-K TO AP COMPUTER SCIENCE & CALCULUS", 3.8, bold=True, color=TEAL)
    p.para(18, 249,
           "StackCalc connects early arithmetic (counting on, number bonds, ten-frames, rekenreks) directly to middle school algebra, high school trigonometry, exponential growth, combinatorics, and computer architecture.",
           size=2.9)
    c.showPage()

    # -------------------------------------------------------------
    # PAGES 2, 3 & 4: Master Curriculum Cross-Reference & Pacing Concordance
    # -------------------------------------------------------------
    curricula_sections = [
        ("Singapore Math", 2, "Singapore Dimensions Math Master Pacing Concordance",
         "Find your current Dimensions Math PK–8 book, chapter, and lesson number to locate the matching Gridfinity stage and book pages."),
        ("Bridges in Mathematics", 3, "Bridges in Mathematics Master Pacing Concordance",
         "Find your current unit, module, and daily session number to locate the matching Gridfinity stage and book pages."),
        ("Big Ideas Math", 4, "Big Ideas Math & AP Master Pacing Concordance",
         "Find your current grade, chapter, and section number to locate the matching Gridfinity stage and book pages."),
    ]

    for curr_filter, page_idx, page_title, page_subtitle in curricula_sections:
        p = new_page(page_idx, "Textbook Pacing & Lesson Index", page_title, page_subtitle)
        
        # Table Header
        cols = [14, 38, 76, 126, 154, 180]
        headers = ["Grade", "Textbook Ref", "Topic & Objective", "Manipulative", "Keystrokes", "Book Pages"]
        p.rect(14, 62, p.w - 28, 6.5, color="#dce9e5")
        for cx, h in zip(cols, headers):
            p.text(cx + 1, 66.5, h, 2.3, bold=True, color=INK)

        # Get entries matching filter
        if curr_filter == "Big Ideas Math":
            entries = [cr for cr in CURRICULUM_CROSS_REFERENCES if cr.curriculum in ["Big Ideas Math", "AP Math / CS"]]
        else:
            entries = [cr for cr in CURRICULUM_CROSS_REFERENCES if cr.curriculum == curr_filter]

        row_y = 69.0
        row_h = 7.0
        for r_i, cr in enumerate(entries[:23]):  # Show up to 23 primary highlights per page
            p.rect(14, row_y, p.w - 28, row_h, color="#ffffff" if r_i % 2 == 0 else "#f6f3ea", stroke="#c3d3cd")
            p.text(cols[0] + 1, row_y + 4.8, cr.grade[:12], 2.2, bold=True, color=TEAL)
            p.text(cols[1] + 1, row_y + 4.8, cr.textbook_reference[:22], 2.1)
            p.text(cols[2] + 1, row_y + 4.8, cr.lesson_title[:28], 2.1, bold=True)
            p.text(cols[3] + 1, row_y + 4.8, cr.manipulative.split(" (")[0][:15], 2.0)
            p.text(cols[4] + 1, row_y + 4.8, cr.keystroke_preview[:16], 1.9, color="#4a605a")
            p.text(cols[5] + 1, row_y + 4.8, f"pp. {cr.page_core}–{cr.page_worksheet}", 2.2, bold=True, color=TEAL)
            row_y += row_h

        p.note(234, f"Using the {curr_filter} Pacing Index",
               f"Locate your lesson above for this week's class. Turn to the listed pages in this guide: Page {cr.page_core} provides the Core Lesson Plan, Page {cr.page_ext} the Extension, and Page {cr.page_worksheet} the reproducible Student Activity Sheet.")
        c.showPage()

    # -------------------------------------------------------------
    # UNITS 1 to 12: Detailed 3-Page Units (Pages 5 to 40)
    # -------------------------------------------------------------
    current_page = 5
    for u in CURRICULUM_UNITS:
        # ---------------------------------------------------------
        # PAGE A: Primary Core Lesson Plan
        # ---------------------------------------------------------
        lp = u.primary_lesson
        p = new_page(current_page, f"Unit {u.unit_number} Core Lesson / {lp.curriculum} ({u.grades})", lp.title,
                     f"{lp.chapter} • Standard: {lp.standard}")

        # 1. Manipulative Setup
        p.text(18, 64, "1. CONCRETE MANIPULATIVE SETUP", 3.6, bold=True, color=TEAL)
        p.text(18, 71, f"Manipulative: {lp.manipulative}", 3.0, bold=True)
        p.para(18, 77, lp.manipulative_setup, size=2.9)

        # 2. Student Prediction
        p.text(18, 93, "2. STUDENT PREDICTION (BEFORE PRESSING)", 3.6, bold=True, color=TEAL)
        p.para(18, 100, lp.prediction_step, size=2.9)

        # 3. Calculator Flow with Hardware Trapezoid Keycaps
        p.text(18, 118, "3. CALCULATOR ACTION (HARDWARE TRAPEZOID KEYCAPS)", 3.6, bold=True, color=TEAL)
        p.text(18, 126, "Keystroke Flow:", 2.8, bold=True)
        p.draw_key_sequence(lp.key_tokens, 50, 121, h=6.2)

        # Execution Trace Table
        table_top = 134
        p.rect(18, table_top, p.w - 36, 6.5, color="#dce9e5")
        p.text(22, table_top + 4.5, "Key Pressed", 2.5, bold=True)
        p.text(54, table_top + 4.5, "Screen (X)", 2.5, bold=True)
        p.text(88, table_top + 4.5, "Internal 4-Level Stack Effect (T, Z, Y, X)", 2.5, bold=True)

        cur_y = table_top + 6.5
        for step_idx, (k_tok, disp, desc) in enumerate(lp.calculator_flow):
            p.rect(18, cur_y, p.w - 36, 7.8, color="#ffffff" if step_idx % 2 == 0 else "#f6f3ea", stroke="#c3d3cd")
            p.draw_keycap(k_tok, 22, cur_y + 1, h=5.2)
            p.text(54, cur_y + 5.2, disp, 2.9, bold=True)
            p.text(88, cur_y + 5.2, desc[:62], 2.4)
            cur_y += 8.0

        # 4. Mathematical Explanation & Classroom Worksheet Problem
        p.note(cur_y + 3, "4. MATHEMATICAL EXPLANATION & RPN ADVANTAGE", lp.explanation)
        
        # Classroom Problem Box
        prob_y = cur_y + 28
        p.rect(18, prob_y, p.w - 36, 18, color="#ffffff", stroke="#087f82", r=1.5)
        p.text(22, prob_y + 5, "Classroom Investigation Problem:", 2.8, bold=True, color=TEAL)
        p.text(22, prob_y + 11, lp.worksheet_problem[:95], 2.7)
        c.showPage()
        current_page += 1

        # ---------------------------------------------------------
        # PAGE B: Follow-Up Extension Lesson Plan
        # ---------------------------------------------------------
        ext = u.followup_lesson
        p = new_page(current_page, f"Unit {u.unit_number} Extension / {ext.curriculum} ({u.grades})", ext.title,
                     f"{ext.chapter} • Standard: {ext.standard}")

        p.text(18, 64, "1. ADVANCED INVESTIGATION SETUP", 3.6, bold=True, color=TEAL)
        p.text(18, 71, f"Manipulative: {ext.manipulative}", 3.0, bold=True)
        p.para(18, 77, ext.manipulative_setup, size=2.9)

        p.text(18, 93, "2. HYPOTHESIS & MATHEMATICAL PREDICTION", 3.6, bold=True, color=TEAL)
        p.para(18, 100, ext.prediction_step, size=2.9)

        p.text(18, 118, "3. CALCULATOR ACTION & REGISTER TRANSFORMATION", 3.6, bold=True, color=TEAL)
        p.text(18, 126, "Keystroke Flow:", 2.8, bold=True)
        p.draw_key_sequence(ext.key_tokens, 50, 121, h=6.2)

        table_top = 134
        p.rect(18, table_top, p.w - 36, 6.5, color="#dce9e5")
        p.text(22, table_top + 4.5, "Key Pressed", 2.5, bold=True)
        p.text(54, table_top + 4.5, "Screen (X)", 2.5, bold=True)
        p.text(88, table_top + 4.5, "Internal 4-Level Stack Effect", 2.5, bold=True)

        cur_y = table_top + 6.5
        for step_idx, (k_tok, disp, desc) in enumerate(ext.calculator_flow):
            p.rect(18, cur_y, p.w - 36, 7.8, color="#ffffff" if step_idx % 2 == 0 else "#f6f3ea", stroke="#c3d3cd")
            p.draw_keycap(k_tok, 22, cur_y + 1, h=5.2)
            p.text(54, cur_y + 5.2, disp, 2.9, bold=True)
            p.text(88, cur_y + 5.2, desc[:62], 2.4)
            cur_y += 8.0

        p.note(cur_y + 3, "4. EXTENSION ANALYSIS & DEEPER CONNECTIONS", ext.explanation)

        prob_y = cur_y + 28
        p.rect(18, prob_y, p.w - 36, 18, color="#ffffff", stroke="#087f82", r=1.5)
        p.text(22, prob_y + 5, "Extension Investigation Challenge:", 2.8, bold=True, color=TEAL)
        p.text(22, prob_y + 11, ext.worksheet_problem[:95], 2.7)
        c.showPage()
        current_page += 1

        # ---------------------------------------------------------
        # PAGE C: Student Learning Lab Worksheet & Reference Guide
        # ---------------------------------------------------------
        p = new_page(current_page, f"Student Lab Worksheet • Unit {u.unit_number}",
                     u.title,
                     "Name: __________________________________   Date: ______________   Class: ______________")

        # Student Quick Reference Box
        p.rect(18, 62, p.w - 36, 28, color="#e5efeb", stroke="#087f82", r=2.0)
        p.text(22, 68, f"STUDENT REFERENCE GUIDE: {u.student_guide_title.upper()}", 3.0, bold=True, color=TEAL)
        ref_y = 74
        for r_line in u.student_guide_rules[:3]:
            p.text(24, ref_y, f"• {r_line}", 2.5)
            ref_y += 4.5
        p.text(24, ref_y + 1, f"Calculator Shortcut: {u.calculator_shortcut}", 2.6, bold=True, color=INK)

        # 4 Student Practice Problems with Keystroke Boxes
        y_pos = 96
        for p_idx, prob in enumerate(u.practice_problems):
            p.rect(18, y_pos, p.w - 36, 36, color="#ffffff", stroke="#a3bbb4", r=1.5)
            p.text(22, y_pos + 6, f"Problem {p_idx + 1}: {prob['prompt']}", 2.9, bold=True, color=INK)

            # Left: Manipulative Sketch Area
            p.text(22, y_pos + 13, "Manipulative Setup / Notes:", 2.3, bold=True, color="#4a605a")
            p.rect(22, y_pos + 15, 60, 16, color="#f6f3ea", stroke="#c3d3cd")

            # Center: Keystroke Write-In Boxes
            p.text(90, y_pos + 13, "Keystrokes:", 2.3, bold=True, color="#4a605a")
            for box_i in range(5):
                p.rect(90 + box_i * 9, y_pos + 17, 7.5, 7.5, color="#ffffff", stroke="#000000", r=1)

            # Right: Predicted Answer and Final Result
            p.text(142, y_pos + 13, "Prediction:", 2.3, bold=True, color="#4a605a")
            p.line(142, y_pos + 22, p.w - 24, y_pos + 22, color="#173d43", width=0.3)

            p.text(142, y_pos + 27, "Final X Result:", 2.3, bold=True, color=TEAL)
            p.line(142, y_pos + 33, p.w - 24, y_pos + 33, color="#087f82", width=0.4)

            y_pos += 39

        c.showPage()
        current_page += 1

    # -------------------------------------------------------------
    # PAGES 39 & 40: Teacher Answer Key & Solutions
    # -------------------------------------------------------------
    for key_page in [1, 2]:
        p = new_page(current_page, "Teacher Solution Guide",
                     f"Master Solutions & Keystrokes — Part {key_page}",
                     "Complete worked solutions, keystroke sequences, and expected rational results.")
        units_for_page = CURRICULUM_UNITS[:6] if key_page == 1 else CURRICULUM_UNITS[6:]
        y_pos = 64
        for u in units_for_page:
            p.rect(18, y_pos, p.w - 36, 29, color="#ffffff" if u.unit_number % 2 == 1 else "#f6f3ea", stroke="#c3d3cd", r=1.0)
            p.text(22, y_pos + 5, f"Unit {u.unit_number}: {u.title} ({u.grades})", 2.9, bold=True, color=TEAL)
            p.text(22, y_pos + 10, f"Core Lesson: {u.primary_lesson.worksheet_answer}", 2.6)
            p.text(22, y_pos + 15, "Core Keys:", 2.4, bold=True)
            p.draw_key_sequence(u.primary_lesson.worksheet_expected_keys, 42, y_pos + 11.5, h=4.6)

            p.text(22, y_pos + 21, f"Extension: {u.followup_lesson.worksheet_answer}", 2.6)
            p.text(22, y_pos + 26, "Extension Keys:", 2.4, bold=True)
            p.draw_key_sequence(u.followup_lesson.worksheet_expected_keys, 48, y_pos + 22.5, h=4.6)
            y_pos += 31

        p.note(252, "Scoring Criteria",
               "Award credit for: (1) Correct concrete manipulative modeling, (2) Accurate prediction prior to calculator entry, (3) Valid RPN key sequence preserving operand order, and (4) Clear explanation of stack flow.")
        c.showPage()
        current_page += 1

    # -------------------------------------------------------------
    # PAGE 41: Production & Classroom Print Specifications
    # -------------------------------------------------------------
    p = new_page(current_page, "Classroom Implementation & 3D Printing", "Fabrication & Slicer Profiles",
                 "Guidelines for 3D printing the modular Gridfinity Learning Lab set in PLA or PETG.")
    y_pos = 64
    specs = [
        ("Material Selection", "PLA or PETG. Standard PLA provides crisp debossed text definition. PETG offers superior impact resistance for frequent classroom handling. No multi-material system or laser required."),
        ("Slicer Profile Recommendations", "Layer height: 0.20 mm. Perimeters: 3. Infill: 15-20% gyroid. Top/bottom solid layers: 4. The 0.6 mm inset debossing creates exactly 3 solid recessed layers for high visual contrast under classroom lighting."),
        ("Gridfinity Tolerances", "Trays use Zack Freedman's 42.0 mm pitch with standard 0.5 mm bin clearances and 4.0 mm base profiles. Always print the 'fit_coupon.stl' first to test socket clearances on your printer."),
        ("Storage & Organization", "The 4x4 baseplate (168 x 168 mm) acts as both the activity dock and the storage foundation. Trays stack cleanly into classroom cubbies, completely eliminating disposable cardboard packaging."),
        ("Hardware Keycap Parity", "All keycaps in this guide are rendered directly from StackCalc firmware simulator definitions (Firmware/Simulator/labels.json) ensuring 100% exact parity with the physical and watch calculator."),
    ]
    for title, desc in specs:
        p.text(18, y_pos, title, 3.6, bold=True, color=TEAL)
        y_pos = p.para(18, y_pos + 7, desc, size=2.9) + 3

    p.text(18, 246, "Open-Source Repository & STL Downloads", 3.2, bold=True)
    p.para(18, 252,
           "All STLs, OpenSCAD source files, PDFs, and classroom curriculum guides are fully open-source and downloadable at stackcalc.io.",
           size=2.7)
    c.showPage()
    c.save()


def proficiency_trials_book(path, size):
    c = canvas.Canvas(str(path), pagesize=size, invariant=1, pageCompression=1)
    c.setTitle("StackCalc Calculator Applications - Student Proficiency Trials")
    c.setAuthor("StackCalc")
    c.setSubject("UIL-Style Timed Calculator Proficiency Trials & Stack Time Trials")

    def new_page(page_num, kicker, title, subtitle):
        p = Page(c, size)
        p.header(kicker, title, subtitle)
        p.footer(page_num, doc_title="STUDENT PROFICIENCY TRIALS")
        return p

    trials = get_all_trials()
    current_page = 1

    # -------------------------------------------------------------
    # PAGE 1: Competition Rules & Student Competitor Log Sheet
    # -------------------------------------------------------------
    p = new_page(current_page, "Classroom Time Trials & Competition", "StackCalc Calculator Applications",
                 "UIL-Style speed and accuracy proficiency tests aligned to maximum stack depth limits.")

    p.text(18, 62, "1. INVITATIONAL TIME TRIAL & SPEED SCORING RULES", 3.4, bold=True, color=TEAL)
    p.para(18, 68,
           "Modeled after University Interscholastic League (UIL) Calculator Applications competitions, these timed trials challenge students to build rapid, instinctive fluency with Reverse Polish Notation (RPN). Each sprint tests numerical accuracy, operand sequencing, and strict stack depth consciousness.",
           size=2.7)

    p.rect(18, 86, 38, 16, color="#e5efeb", stroke=TEAL, r=1.0)
    p.text(21, 92, "CORRECT ANSWER", 2.2, bold=True, color=TEAL)
    p.text(21, 98, "+5 Points", 3.4, bold=True, color=INK)

    p.rect(60, 86, 38, 16, color="#fdf0ed", stroke="#c84c32", r=1.0)
    p.text(63, 92, "INCORRECT / ERROR", 2.2, bold=True, color="#c84c32")
    p.text(63, 98, "-2 Points", 3.4, bold=True, color=INK)

    p.rect(102, 86, 38, 16, color="#f6f3ea", stroke="#c3d3cd", r=1.0)
    p.text(105, 92, "UNATTEMPTED / SKIP", 2.2, bold=True, color="#556660")
    p.text(105, 98, "0 Points", 3.4, bold=True, color=INK)

    p.rect(144, 86, p.w - 162, 16, color="#fdf4df", stroke=GOLD, r=1.0)
    p.text(147, 92, "SPEED BONUS", 2.2, bold=True, color=GOLD)
    p.text(147, 98, "+1 pt / rem. min", 3.2, bold=True, color=INK)

    p.text(18, 110, "2. MAXIMUM STACK LEVEL DISCIPLINE", 3.4, bold=True, color=TEAL)
    p.para(18, 116,
           "Competitors must respect the Max Stack Depth badge on each trial. Problems must be solved using only the allowed stack registers (Stack Level 1 = single register X; Stack Level 2 = registers X & Y; Stack Level 4 = full 4-register stack T-Z-Y-X). Solutions requiring deeper stacks are disqualified.",
           size=2.7)

    p.text(18, 134, "3. OFFICIAL COMPETITOR TIME TRIAL LOG SHEET", 3.4, bold=True, color=TEAL)

    table_top = 140
    cols = [14, 34, 94, 118, 136, 151, 166, p.w - 14]
    p.rect(14, table_top, p.w - 28, 5.8, color="#dce9e5")
    headers = ["Trial", "Topic / Stage", "Max Stack", "Time", "Attempt", "Correct", "Errors", "Score"]
    for cx, h in zip(cols[:-1], headers):
        p.text(cx + 1, table_top + 4.0, h, 2.1, bold=True, color=INK)

    log_y = table_top + 5.8
    for idx, tr in enumerate(trials):
        row_bg = "#ffffff" if idx % 2 == 0 else "#fbfaf7"
        p.rect(14, log_y, p.w - 28, 6.2, color=row_bg, stroke="#d8e2dc")
        p.text(cols[0] + 1, log_y + 4.3, tr.trial_id.replace("trial_", "T-").upper(), 2.2, bold=True, color=TEAL)
        p.text(cols[1] + 1, log_y + 4.3, tr.title[:40], 2.1)
        p.text(cols[2] + 2, log_y + 4.3, f"Level {tr.max_stack_depth}", 2.1, bold=True)
        p.text(cols[3] + 2, log_y + 4.3, f"{tr.time_limit_minutes} min", 2.1)
        p.text(cols[4] + 2, log_y + 4.3, "___/10", 2.0, color="#889990")
        p.text(cols[5] + 2, log_y + 4.3, "___(+5)", 2.0, color="#889990")
        p.text(cols[6] + 2, log_y + 4.3, "___(-2)", 2.0, color="#889990")
        p.text(cols[7] - 12, log_y + 4.3, "_____", 2.2, bold=True)
        log_y += 6.2

    p.note(244, "Classroom Implementation",
           "Run time trials as weekly sprint rounds. Time starts when students turn the page. All keystrokes must be entered on the physical StackCalc hardware or firmware simulator.")
    c.showPage()
    current_page += 1

    # -------------------------------------------------------------
    # PAGES 2 TO 16: The 15 Individual Time Trials
    # -------------------------------------------------------------
    trial_order = [
        "trial_1", "trial_2", "trial_3", "trial_4", "trial_cum_1",
        "trial_5", "trial_6", "trial_7", "trial_8", "trial_cum_2",
        "trial_9", "trial_10", "trial_11", "trial_12", "trial_cum_3"
    ]
    trial_map = {tr.trial_id: tr for tr in trials}

    for tid in trial_order:
        tr = trial_map[tid]
        p = new_page(current_page, "Student Calculator Applications", tr.title,
                     f"{tr.subtitle} • Stage: {tr.stage_name}")

        p.rect(14, 60, 48, 7.5, color="#e5efeb", stroke=TEAL, r=1.0)
        p.text(17, 65.0, f"MAX STACK DEPTH: {tr.max_stack_depth}", 2.6, bold=True, color=TEAL)

        p.rect(66, 60, 42, 7.5, color="#fdf4df", stroke=GOLD, r=1.0)
        p.text(69, 65.0, f"TIME LIMIT: {tr.time_limit_minutes} MIN", 2.6, bold=True, color=GOLD)

        p.rect(112, 60, 40, 7.5, color="#f6f3ea", stroke="#c3d3cd", r=1.0)
        p.text(115, 65.0, "MAX SCORE: 50 PTS", 2.6, bold=True)

        p.rect(14, 70, p.w - 28, 7.8, color="#ffffff", stroke="#c3d3cd", r=1.0)
        p.text(18, 75.2, "Competitor: __________________________", 2.5)
        p.text(82, 75.2, "Date: ____________", 2.5)
        p.text(122, 75.2, "Elapsed: ____:____", 2.5)
        p.text(156, 75.2, "Score: ____ / 50", 2.6, bold=True, color=TEAL)

        cur_y = 80.0
        for p_idx, prob in enumerate(tr.problems):
            bg = "#ffffff" if p_idx % 2 == 0 else "#fbfaf7"
            p.rect(14, cur_y, p.w - 28, 15.2, color=bg, stroke="#d8e2dc", r=1.0)

            p.rect(17, cur_y + 2.5, 7.5, 7.5, color=TEAL, r=1.0)
            x_off = 19.8 if prob.index < 10 else 18.2
            p.text(x_off, cur_y + 7.5, str(prob.index), 3.0, bold=True, color="#ffffff")

            p.text(28, cur_y + 6.8, prob.prompt[:55], 3.1, bold=True, color=INK)
            p.text(28, cur_y + 11.8, f"Stack Hint: {prob.hint[:58]}", 2.2, color="#556660")

            p.rect(p.w - 100, cur_y + 2.0, 44, 11.2, color="#ffffff", stroke="#c3d3cd", r=0.5)
            p.text(p.w - 98, cur_y + 5.2, "Keystroke Entry:", 1.9, color="#889990")

            p.rect(p.w - 52, cur_y + 2.0, 38, 11.2, color="#ffffff", stroke=TEAL, r=0.5)
            p.text(p.w - 50, cur_y + 5.2, "Final Answer:", 1.9, bold=True, color=TEAL)

            cur_y += 16.6

        p.note(250, "UIL Calculator Competition Rules",
               f"Scoring: (+5 × Correct) - (2 × Incorrect). Skipped items receive 0. Enforce Max Stack Depth {tr.max_stack_depth} on this trial. Round decimals to 4 significant digits or write exact rational fractions.")
        c.showPage()
        current_page += 1

    # -------------------------------------------------------------
    # PAGES 17 & 18: Master Teacher Answer Keys & Keystrokes
    # -------------------------------------------------------------
    p = new_page(current_page, "Teacher Competition Solution Guide", "Official Solutions & Keystrokes — Part 1",
                 "Answer keys, required numerical results, and canonical keystroke sequences for Trials 1 to 6 and C1.")

    col1_trials = ["trial_1", "trial_2", "trial_3", "trial_4"]
    col2_trials = ["trial_cum_1", "trial_5", "trial_6"]

    for col_idx, col_list in enumerate([col1_trials, col2_trials]):
        col_x = 14 if col_idx == 0 else (p.w / 2.0 + 2.0)
        col_w = (p.w - 32) / 2.0
        row_y = 62.0
        for tid in col_list:
            tr = trial_map[tid]
            box_h = 44.0 if tid in ["trial_1", "trial_2", "trial_3", "trial_4"] else 58.0
            p.rect(col_x, row_y, col_w, box_h, color="#ffffff", stroke="#c3d3cd", r=1.0)
            p.rect(col_x, row_y, col_w, 5.5, color="#dce9e5", r=1.0)
            p.text(col_x + 3, row_y + 4.0, f"{tr.title[:32]} (Stack {tr.max_stack_depth})", 2.3, bold=True, color=TEAL)

            ans_y = row_y + 9.5
            for prob in tr.problems:
                key_str = " ".join(f"[{k}]" for k in prob.keystrokes[:6])
                p.text(col_x + 3, ans_y, f"{prob.index}. Ans: {prob.expected_answer} — {key_str[:34]}", 2.0)
                ans_y += 3.7
            row_y += box_h + 3.0

    p.note(250, "Scoring Adjudication", "Accept equivalent decimal fractions (e.g. 0.75 or 3/4). If a student pressed superfluous ENTER keys exceeding the maximum stack depth, deduct 2 points for stack overflow violation.")
    c.showPage()
    current_page += 1

    p = new_page(current_page, "Teacher Competition Solution Guide", "Official Solutions & Keystrokes — Part 2",
                 "Answer keys, required numerical results, and canonical keystroke sequences for Trials 7 to 12, C2 & C3.")

    col1_trials_p2 = ["trial_7", "trial_8", "trial_cum_2", "trial_9"]
    col2_trials_p2 = ["trial_10", "trial_11", "trial_12", "trial_cum_3"]

    for col_idx, col_list in enumerate([col1_trials_p2, col2_trials_p2]):
        col_x = 14 if col_idx == 0 else (p.w / 2.0 + 2.0)
        col_w = (p.w - 32) / 2.0
        row_y = 62.0
        for tid in col_list:
            tr = trial_map[tid]
            box_h = 44.0
            p.rect(col_x, row_y, col_w, box_h, color="#ffffff", stroke="#c3d3cd", r=1.0)
            p.rect(col_x, row_y, col_w, 5.5, color="#dce9e5", r=1.0)
            p.text(col_x + 3, row_y + 4.0, f"{tr.title[:32]} (Stack {tr.max_stack_depth})", 2.3, bold=True, color=TEAL)

            ans_y = row_y + 9.5
            for prob in tr.problems:
                key_str = " ".join(f"[{k}]" for k in prob.keystrokes[:6])
                p.text(col_x + 3, ans_y, f"{prob.index}. Ans: {prob.expected_answer} — {key_str[:34]}", 2.0)
                ans_y += 3.7
            row_y += box_h + 3.0

    p.note(250, "Scoring Adjudication", "Accept equivalent scientific notation for large magnitudes (e.g. 1024 or 1.024e3). All answers match canonical RPNCore engine execution.")
    c.showPage()
    c.save()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path("output/pdf"))
    out = parser.parse_args().out
    out.mkdir(parents=True, exist_ok=True)
    for name, size in [("letter", letter), ("a4", A4)]:
        cards(out / f"reference-cards-{name}.pdf", size)
        curriculum_guide(out / f"teacher-booklet-{name}.pdf", size)
        curriculum_guide(out / f"teacher-curriculum-guide-{name}.pdf", size)
        proficiency_trials_book(out / f"student-proficiency-trials-{name}.pdf", size)
    print("Created Letter and A4 reference sheets, teacher booklets, curriculum guides, and proficiency trial books.")


"""Shared millimetre geometry and original lesson content. Y increases downwards.

Revision 0.3.0:
- Modular Gridfinity standard geometry (42 mm pitch)
- Debossed inset text (0.6 mm depth) for single-operation FDM printing (PLA/PETG)
- Trays and baseplate serve as both classroom manipulative station and reusable storage box
"""
from dataclasses import dataclass, field, asdict

REVISION = "0.3.0"
GRIDFINITY_PITCH = 42.0
GRIDFINITY_TOLERANCE = 0.5
INSET_DEPTH = 0.6

INK = "#173d43"
TEAL = "#087f82"
GOLD = "#d79b36"
PAPER = "#f6f3ea"
DENOMINATORS = (1, 2, 3, 4, 5, 6, 7, 8, 9)
UNIT_HEIGHT = 84.0
BLOCK_SIDE = 41.5


@dataclass
class Part:
    id: str
    title: str
    width: float
    height: float
    thickness: float = 4.0
    pocket_depth: float = 1.6
    inset_depth: float = INSET_DEPTH
    gridfinity_x: int = 0
    gridfinity_y: int = 0
    is_baseplate: bool = False
    has_top_sockets: bool = False
    is_ten_frame_tray: bool = False
    is_fraction_bin: bool = False
    bodies: list = field(default_factory=list)
    pockets: list = field(default_factory=list)
    labels: list = field(default_factory=list)
    lines: list = field(default_factory=list)
    bosses: list = field(default_factory=list)
    notes: str = ""

    def rect(self, x, y, w, h, r=2, pocket=False, height_divisor=1, pieces=1):
        (self.pockets if pocket else self.bodies).append(
            dict(kind="rect", x=x, y=y, w=w, h=h, r=r, height_divisor=height_divisor, pieces=pieces)
        )

    def circle(self, x, y, radius, pocket=False):
        (self.pockets if pocket else self.bodies).append(
            dict(kind="circle", x=x, y=y, r=radius)
        )

    def label(self, x, y, text, size=3, align="left", bold=False, surface_z=None):
        self.labels.append(
            dict(x=x, y=y, text=text, size=size, align=align, bold=bold,
                 surface_z=self.thickness if surface_z is None else surface_z)
        )

    def line(self, x1, y1, x2, y2, width=0.35):
        self.lines.append(dict(x1=x1, y1=y1, x2=x2, y2=y2, width=width))

    def plate(self):
        r = 3.75 if self.gridfinity_x > 0 else (4 if self.width > 90 else 3.18)
        self.rect(0, 0, self.width, self.height, r)

    def heading(self, subtitle):
        self.label(8, 12, "STACKCALC / " + self.title.upper(), 3.6, bold=True)
        self.label(8, 20, subtitle, 2.5)


CARDS = [
    dict(id="card_stack", title="01 / THE STACK", tagline="Keep the order. See the result.", rows=[
        ("T   Z   Y   X", "Four registers; X is the screen."),
        ("ENTER", "Copies X up; next number replaces X."),
        ("Y - X     Y / X", "First value in Y, second value in X."),
        ("8  ENTER  3  -  = 5", "After an operation, entry lifts the stack."),
    ]),
    dict(id="card_fractions", title="02 / BUILD A FRACTION", tagline="Whole . numerator . denominator", rows=[
        ("3/4        . 3 . 4", "No whole part? Start with a dot."),
        ("2 1/2      2 . 1 . 2", "Two dots make the fraction entry."),
        (".3.4  ENTER  2.1.2  +", "Result: 3 1/4, or decimal 3.25."),
        ("BUILD / NAME / TYPE / CHECK", "Dots separate fields; they do not divide."),
    ]),
    dict(id="card_distance", title="03 / MEASURE DISTANCE", tagline="From (1, 2) to (4, 6)", rows=[
        ("1  ENTER  4  -  x^2", "Horizontal difference squared: 9."),
        ("2  ENTER  6  -  x^2", "Vertical difference squared: 16."),
        ("+  sqrt", "9 + 16 = 25; square root = 5."),
        ("SQUARE / ADD / ROOT", "Function names may need a shift key."),
    ]),
]


def catalog():
    parts = []

    # 1. Gridfinity 4x4 Baseplate (Desk Organizer / Classroom Storage Dock)
    p = Part("gridfinity_baseplate", "Gridfinity 4x4 Baseplate", 168.0, 168.0, thickness=6.0,
             gridfinity_x=4, gridfinity_y=4, is_baseplate=True)
    p.plate()
    p.label(8, 10, "STACKCALC / LEARNING LAB 4x4 BASE", 3.2, bold=True)
    p.label(8, 162, "Gridfinity Standard 42mm Pitch / Zero-Waste Modular Packaging", 2.2)
    p.notes = "Standard 4x4 Gridfinity baseplate (168 x 168 mm). Holds modular trays securely on student desks and stacks into classroom kit boxes."
    parts.append(p)

    # 2. Fraction Studio: 3x3 Gridfinity Bin with Wall Guides (125.5 x 125.5 x 86.4 mm)
    p = Part("fraction_tray", "Fraction studio", 125.5, 125.5, thickness=86.4,
             gridfinity_x=3, gridfinity_y=3, pocket_depth=84.0, is_fraction_bin=True)
    p.plate()
    p.label(8, 7, "STACKCALC / FRACTION STUDIO 3x3 BIN", 2.8, bold=True)
    tower_labels = [
        ("WHOLE", "1"), ("HALVES", "1/2"), ("THIRDS", "1/3"),
        ("FOURTHS", "1/4"), ("FIFTHS", "1/5"), ("SIXTHS", "1/6"),
        ("SEVENTHS", "1/7"), ("EIGHTHS", "1/8"), ("NINTHS", "1/9")
    ]
    for gy in range(3):
        for gx in range(3):
            idx = gx + gy * 3
            cx = (p.width / 2.0) + (gx - 1.0) * 42.0
            cy = (p.height / 2.0) + (gy - 1.0) * 42.0
            p.rect(cx - 20.8, cy - 20.8, 41.6, 41.6, r=3.8, pocket=True)
            name, sub = tower_labels[idx]
            p.label(cx, cy - 12, name, 1.8, "center", True)
            p.label(cx, cy + 13, sub, 2.4, "center", True)
    p.label(62.75, 122.0, "3x3 Gridfinity Bin: 9 towers (1 to 1/9). Wall guides show heights.", 1.8, "center")
    p.notes = "3x3 Gridfinity bin (125.5 x 125.5 x 84 mm). 9 floor sockets. Wall height guides show 1/9, 1/8, 1/7, 1/6, 1/5, 1/4, 1/3, 1/2, 1 whole."
    parts.append(p)

    # 3. Fraction Blocks (45 stackable pieces in 9 vertical towers: 1, 1/2, 1/3, 1/4, 1/5, 1/6, 1/7, 1/8, 1/9)
    p = Part("fraction_blocks", "Fraction blocks / 45 stackable pieces in 9 towers", 126.0, 126.0, thickness=UNIT_HEIGHT)
    for gy in range(3):
        for gx in range(3):
            d = 1 + gx + gy * 3
            x = 0.25 + gx * 42.0
            y = 0.25 + gy * 42.0
            lbl = "1" if d == 1 else f"1/{d}"
            p.rect(x, y, BLOCK_SIDE, BLOCK_SIDE, r=3.75, height_divisor=d, pieces=d)
            p.label(x + BLOCK_SIDE / 2, y + BLOCK_SIDE / 2, lbl, 5, "center", True, surface_z=UNIT_HEIGHT / d)
    p.notes = "Standard 1x1 Gridfinity footprint (41.5 x 41.5 mm). 45 blocks across 9 vertical towers (1 to 1/9). Heights 84/n mm. Vertically stacked with sacrificial tear-off supports on a single build plate (126 x 126 mm)."
    parts.append(p)

    # 4. Numeral Tiles (30 pieces) with Inset Digits
    p = Part("fraction_digits", "Numeral tiles / 30 pieces", 208, 128, thickness=2.4)
    for i in range(30):
        x, y = 2 + (i % 6) * 34, 2 + (i // 6) * 25
        p.rect(x, y, 31, 21, 2)
        p.label(x + 15.5, y + 14, str(i % 10), 8, "center", True)
    p.notes = "Three copies of digits 0-9. Digits debossed 0.6 mm deep into top face. Fit fraction tray entry wells."
    parts.append(p)

    # 5. Stack Stage: 3x3 Gridfinity Tray (125.5 x 125.5 mm)
    p = Part("stack_board", "Stack stage", 125.5, 125.5, thickness=4.5,
             gridfinity_x=3, gridfinity_y=3, pocket_depth=2.0)
    p.plate()
    p.heading("Read from T to X. Move values after each action.")
    for i, (reg, role) in enumerate([("T", "fourth"), ("Z", "third"), ("Y", "first operand"), ("X", "screen / result")]):
        y = 28 + i * 22
        p.label(10, y + 13, reg, 7, bold=True)
        p.rect(40, y, 78, 18, 1.5, pocket=True)
        p.label(26, y + 12, role, 1.8, "center")
    p.label(8, 116, "ENTER copies X; next entry replaces X. Operation combines Y and X.", 2.4, bold=True)
    p.label(8, 122, "After arithmetic, entering a new number lifts the stack.", 2.2)
    p.notes = "3x3 Gridfinity stage (125.5 x 125.5 mm). Inset debossed lettering. Gridfinity base on underside."
    parts.append(p)

    # 6. Stack Value Tiles (4 blank tiles)
    p = Part("stack_tiles", "Stack value tiles / 4 blanks", 84, 88, thickness=2.4)
    for i in range(4):
        p.rect(2, 2 + i * 21, 76.8, 16.8, 1.5)
    p.notes = "Blank reusable value tiles (76.8 x 16.8 mm) for the Stack Stage register wells. Compatible with writable film or paper inserts."
    parts.append(p)

    # 7. Expression Tree: 4x3 Gridfinity Tray (167.5 x 125.5 mm)
    p = Part("tree_board", "Expression tree", 167.5, 125.5, thickness=4.5,
             gridfinity_x=4, gridfinity_y=3, pocket_depth=2.0)
    p.plate()
    p.heading("(a + b) * (c - d) / Postorder: visit left, right, then operator")
    nodes = [
        (24, 98, "1 / a"), (68, 98, "2 / b"), (46, 64, "3 / +"),
        (104, 98, "4 / c"), (148, 98, "5 / d"), (126, 64, "6 / -"),
        (86, 32, "7 / *")
    ]
    for a, b in [(6, 2), (6, 5), (2, 0), (2, 1), (5, 3), (5, 4)]:
        p.line(*nodes[a][:2], *nodes[b][:2], 0.65)
    for x, y, label in nodes:
        p.circle(x, y, 11.5, pocket=True)
        p.label(x, y + 16, label, 2.7, "center", True)
    p.label(83.75, 120, "Read out:  a  b  +  c  d  -  *", 3.2, "center", True)
    p.notes = "4x3 Gridfinity tray (167.5 x 125.5 mm). 7 token wells (23 mm diameter) with connecting branch lines and postorder labels debossed 0.6 mm deep."
    parts.append(p)

    # 8. Tree Tokens (7 pieces) with Inset Glyphs
    p = Part("tree_tokens", "Tree tokens / 7 pieces", 108, 58, thickness=3.0)
    for i, token in enumerate(["a", "b", "+", "c", "d", "-", "*"]):
        x, y = 14 + (i % 4) * 26, 14 + (i // 4) * 26
        p.circle(x, y, 11.2)
        p.label(x, y + 2.6, token, 8, "center", True)
    p.notes = "Seven 22.4 mm diameter tokens (3.0 mm thick). Characters debossed 0.6 mm into top face."
    parts.append(p)

    # 9. Coordinate Lab: 4x4 Gridfinity Tray (167.5 x 167.5 mm)
    p = Part("distance_board", "Coordinate lab", 167.5, 167.5, thickness=4.5,
             gridfinity_x=4, gridfinity_y=4, pocket_depth=2.2)
    p.plate()
    p.heading("10 x 10 points / coordinates 0-9 / pitch 12 mm")
    grid_ox, grid_oy = 28.0, 32.0
    for i in range(10):
        x = grid_ox + 12 * i
        y = grid_oy + 12 * i
        p.line(x, grid_oy, x, grid_oy + 108, 0.22)
        p.line(grid_ox, y, grid_ox + 108, y, 0.22)
        p.label(x, grid_oy + 116, str(i), 2.5, "center")
        p.label(grid_ox - 8, y + 1, str(9 - i), 2.5, "center")
        for j in range(10):
            p.circle(x, grid_oy + 12 * j, 2.2, pocket=True)
    p.label(grid_ox + 115, grid_oy + 112, "x", 3, bold=True)
    p.label(grid_ox - 8, grid_oy - 4, "y", 3, bold=True)
    p.label(8, 154, "A(1,2) to B(4,6): run 3, rise 4, distance 5", 2.8, bold=True)
    p.label(8, 161, "1 ENTER 4 - x^2   2 ENTER 6 - x^2   + sqrt", 2.5)
    p.notes = "4x4 Gridfinity plate (167.5 x 167.5 mm). 100 blind sockets (4.4 mm dia x 2.2 mm deep). Inset lines and numbers; Gridfinity base on underside."
    parts.append(p)

    # 10. Locator Pegs (4 pieces)
    p = Part("distance_pegs", "Locator pegs / 4 pieces", 56, 16, thickness=2.0)
    for x in [8, 21, 34, 47]:
        p.circle(x, 8, 5)
        p.bosses.append(dict(x=x, y=8, r=1.9, height=2.0))
    p.notes = "Four locator pegs. 3.8 mm stems fit 4.4 mm sockets. Debossed center pip on flat heads."
    parts.append(p)

    # 11. Reference Cards (3 CR80 cards) with Inset Lettering
    for card in CARDS:
        p = Part(card["id"], card["title"], 85.60, 53.98, thickness=1.4, pocket_depth=0.4)
        p.plate()
        p.label(4, 6, "STACKCALC / " + card["title"], 2.5, bold=True)
        p.label(4, 10, card["tagline"], 2.1)
        p.line(4, 12, 81.6, 12)
        for i, (a, b) in enumerate(card["rows"]):
            p.label(4, 17 + i * 9, a, 2.65, bold=True)
            p.label(4, 21 + i * 9, b, 2.05)
        p.label(4, 51, "LEARNING LAB / 4-REGISTER RPN / REV 0.3.0", 1.8)
        p.notes = "CR80 format (85.60 x 53.98 mm). 1.4 mm thick with 0.4 mm debossed text."
        parts.append(p)

    # 12. Fit Coupon
    p = Part("fit_coupon", "Fit first", 92, 48, pocket_depth=2.2)
    p.plate()
    p.label(5, 9, "STACKCALC / FIT COUPON", 3.5, bold=True)
    for x, d in [(16, 4.0), (44, 4.4), (72, 4.8)]:
        p.circle(x, 24, d / 2, pocket=True)
        p.label(x, 37, f"{d:.1f} mm", 3, "center")
    p.label(46, 44, "Test 3.8 mm peg stem before full print.", 2.4, "center")
    p.notes = "Test coupon with 4.0, 4.4, 4.8 mm sockets. Verify printer tolerance before printing full boards."
    parts.append(p)

    # 13. Double Ten-Frame Tray (4x2 Gridfinity: 20 Quarter-Width Sockets)
    p = Part("ten_frame_tray", "Double Ten-Frame stage", 167.5, 83.5, thickness=6.0,
             gridfinity_x=4, gridfinity_y=2, pocket_depth=2.2, is_ten_frame_tray=True)
    p.plate()
    p.label(8, 7, "STACKCALC / DOUBLE TEN-FRAME (NUMBERS TO 20)", 3.0, bold=True)
    ox = 167.5 / 2.0
    oy = 83.5 / 2.0
    col_pitch = 22.0
    row_pitch = 16.0
    for row in range(4):
        for col in range(5):
            cx = ox + (col - 2.0) * col_pitch
            cy = oy + (row - 1.5) * row_pitch
            p.rect(cx - 10.4, cy - 10.4, 20.8, 20.8, r=1.9, pocket=True)
            num = col + 1 + (row % 2) * 5 + (row // 2) * 10
            p.label(cx, cy + 6.0, str(num), 1.9, "center")
    p.line(83.75, 12.0, 83.75, 78.0, width=0.8)
    p.label(83.75, 81.0, "Double Ten-Frame (1-20): Frame 1 (top) & Frame 2 (bottom).", 1.9, "center")
    p.notes = "4x2 Gridfinity Double Ten-Frame tray (167.5 x 83.5 mm). 20 quarter-width (21 mm) sockets arranged as Frame 1 (1-10) and Frame 2 (11-20)."
    parts.append(p)

    # 14. Number Bond Stage (3x2 Gridfinity: Part-Part-Whole)
    p = Part("number_bond_stage", "Number bond stage", 125.5, 83.5, thickness=4.5,
             gridfinity_x=3, gridfinity_y=2, pocket_depth=2.0)
    p.plate()
    p.heading("Part + Part = Whole  //  Y + X = X")
    # Whole well (top center)
    p.circle(62.75, 34.0, 16.0, pocket=True)
    p.label(62.75, 14.0, "WHOLE (X)", 2.8, "center", bold=True)
    # Part 1 (bottom left)
    p.circle(30.0, 62.0, 14.0, pocket=True)
    p.label(30.0, 80.0, "PART 1 (Y)", 2.4, "center", bold=True)
    # Part 2 (bottom right)
    p.circle(95.5, 62.0, 14.0, pocket=True)
    p.label(95.5, 80.0, "PART 2 (X)", 2.4, "center", bold=True)
    # Connecting channels
    p.line(30.0, 62.0, 62.75, 34.0, width=0.8)
    p.line(95.5, 62.0, 62.75, 34.0, width=0.8)
    p.label(42.0, 44.0, "+", 3.5, bold=True)
    p.label(82.0, 44.0, "+", 3.5, bold=True)
    p.notes = "3x2 Gridfinity number bond stage (125.5 x 83.5 mm). Part-Part-Whole wells. Directly embodies RPN: Part 1 in Y, Part 2 in X; addition evaluates Whole in X."
    parts.append(p)

    # 15. Number Rack (Rekenrek Stage: 4x2 Gridfinity)
    p = Part("number_rack", "Number rack", 167.5, 83.5, thickness=4.5,
             gridfinity_x=4, gridfinity_y=2, pocket_depth=2.0)
    p.plate()
    p.heading("Dual 10-bead rows / 5 red + 5 white / Doubles")
    # Row 1 and Row 2 channels
    for row_y in [36.0, 60.0]:
        p.rect(14.0, row_y - 8.0, 139.5, 16.0, 2.0, pocket=True)
        # 10 bead markers
        for b in range(10):
            bx = 20.0 + b * 14.0
            p.circle(bx, row_y, 4.5, pocket=True)
    # 5-bead divider marker
    p.line(83.75, 24.0, 83.75, 76.0, width=0.8)
    p.label(48.0, 24.0, "5 RED", 2.2, "center", bold=True)
    p.label(118.0, 24.0, "5 WHITE", 2.2, "center", bold=True)
    p.label(83.75, 80, "Push beads to count on / ENTER duplicates for doubles", 2.2, "center")
    p.notes = "4x2 Gridfinity number rack / Rekenrek (167.5 x 83.5 mm). Two rows of 10 beads grouped in 5s. Teaches doubles (n ENTER +) and near-doubles."
    parts.append(p)

    # 18. Ten-Frame Mini-Blocks (20 pieces)
    p = Part("ten_frame_dots", "Ten-frame mini-blocks / 20 pieces", 106.0, 86.0, thickness=7.0)
    pitch_mini = 21.0
    for i in range(20):
        col = i % 5
        row = i // 5
        x = 0.5 + col * pitch_mini
        y = 0.5 + row * pitch_mini
        p.rect(x, y, 20.5, 20.5, r=1.8)
        p.label(x + 10.25, y + 10.25, str(i + 1), 4.5, "center", True, surface_z=7.0)
    p.notes = "Quarter-width (21 mm pitch) Gridfinity mini-blocks (20.5 x 20.5 mm, 7.0 mm height = 1U). 20 stackable blocks for the Double Ten-Frame."
    parts.append(p)

    return parts


def manifest():
    return dict(
        collection="StackCalc Learning Lab",
        version=REVISION,
        status="revision 0.3.0 - Gridfinity modular & inset debossed",
        units="mm",
        finish="inset debossed lettering (0.6 mm depth); no laser engraving required",
        gridfinity_standard="42.0 mm unit pitch, 4.0 mm base profile",
        parts=[asdict(p) for p in catalog()]
    )


def laser_setups(p):
    heights = sorted({l["surface_z"] for l in p.labels} | ({p.thickness} if p.lines else set()))
    return [dict(surface_z_mm=z, file=f"svg/{p.id}-engrave" + (f"-z{z:g}" if len(heights) > 1 else "") + ".svg") for z in heights]

"""Generate 3D assembly images and animated usage demonstrations for the StackCalc website.

Outputs:
1. Assembly Images (PNG):
   - fraction_studio_assembly.png
   - stack_stage_assembly.png
   - expression_tree_assembly.png
   - coordinate_lab_assembly.png
   - gridfinity_ecosystem_assembly.png

2. Usage Animations (GIF):
   - fraction_studio_usage.gif
   - stack_stage_usage.gif
   - expression_tree_usage.gif
   - coordinate_lab_usage.gif
   - gridfinity_docking_usage.gif

Files are saved directly to Website/docs/assets/education/ and Education/build/preview/.
"""
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
EDUCATION_DIR = REPO_ROOT / "Education"
BUILD_DIR = EDUCATION_DIR / "build"
SCENE_DIR = BUILD_DIR / "scenes"
PREVIEW_DIR = BUILD_DIR / "preview"
WEBSITE_ASSETS_DIR = REPO_ROOT / "Website" / "docs" / "assets" / "education"
KEYCAPS_DIR = BUILD_DIR / "keycaps"
FONTS_DIR = REPO_ROOT / "Shared" / "Fonts"

OPENSCAD = Path("/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD")
if not OPENSCAD.exists():
    OPENSCAD = "openscad"

SPACE_MONO_BOLD = FONTS_DIR / "SpaceMono-Bold.ttf"
SPACE_MONO_REG = FONTS_DIR / "SpaceMono-Regular.ttf"

# Colors matching StackCalc Hardware & Learning Lab visual identity
COLOR_BG = (246, 243, 234)        # Warm paper #f6f3ea
COLOR_TEXT = (23, 61, 67)          # Dark ink #173d43
COLOR_TEAL = (8, 127, 130)         # StackCalc Teal #087f82
COLOR_GOLD = (215, 155, 54)        # Gold #d79b36
COLOR_CARD = (255, 255, 255)       # Pure white
COLOR_MUTED = (163, 187, 180)      # Muted border #a3bbb4


def ensure_dirs():
    SCENE_DIR.mkdir(parents=True, exist_ok=True)
    PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
    WEBSITE_ASSETS_DIR.mkdir(parents=True, exist_ok=True)


def render_openscad_scene(scad_file: Path, out_png: Path, img_size=(1000, 750), camera="0,0,0,55,0,25,0"):
    cmd = [
        str(OPENSCAD),
        "--autocenter", "--viewall",
        f"--camera={camera}",
        f"--imgsize={img_size[0]},{img_size[1]}",
        "--colorscheme=Solarized",
        "-o", str(out_png),
        str(scad_file)
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"OpenSCAD render error for {scad_file}: {res.stderr}")
    return res.returncode == 0


def add_banner(im: Image.Image, title: str, subtitle: str) -> Image.Image:
    """Add a clean, polished brutalist header banner to 3D renders."""
    w, h = im.size
    canvas = Image.new("RGB", (w, h + 100), COLOR_BG)
    draw = ImageDraw.Draw(canvas)
    
    # Header background and text
    f_kicker = ImageFont.truetype(str(SPACE_MONO_BOLD), 15)
    f_title = ImageFont.truetype(str(SPACE_MONO_BOLD), 26)
    f_sub = ImageFont.truetype(str(SPACE_MONO_REG), 14)
    
    draw.text((36, 18), "STACKCALC LEARNING LAB  //  MODULAR GRIDFINITY", font=f_kicker, fill=COLOR_TEAL)
    draw.text((36, 40), title, font=f_title, fill=COLOR_TEXT)
    draw.text((36, 76), subtitle, font=f_sub, fill=COLOR_TEAL)
    draw.line([(36, 96), (w - 36, 96)], fill=COLOR_GOLD, width=3)
    
    # Paste 3D render below banner
    canvas.paste(im, (0, 100))
    return canvas


def draw_keycap_on(draw, canvas, key_name: str, x: int, y: int, h: int = 44):
    """Draw a keycap icon onto a PIL canvas."""
    fname = key_name + ".png"
    kpath = KEYCAPS_DIR / fname
    if not kpath.exists():
        # Fallbacks
        alt = {"+": "plus.png", "-": "minus.png", "*": "times.png", "/": "divide.png",
               "enter": "enter.png", ".": "dot.png", "sqrt": "sqrt_x.png"}.get(key_name)
        if alt and (KEYCAPS_DIR / alt).exists():
            kpath = KEYCAPS_DIR / alt
            
    if kpath.exists():
        with Image.open(kpath) as kim:
            aspect = kim.width / kim.height
            w = int(h * aspect)
            kim_resized = kim.resize((w, h), Image.Resampling.LANCZOS)
            canvas.paste(kim_resized, (x, y), mask=kim_resized.split()[3] if kim_resized.mode == "RGBA" else None)
            return w
    else:
        # Fallback text pill
        w = max(40, len(key_name) * 14 + 16)
        draw.rounded_rectangle([x, y, x + w, y + h], radius=6, fill=(255, 255, 255), outline=(0, 0, 0), width=2)
        f = ImageFont.truetype(str(SPACE_MONO_BOLD), 16)
        draw.text((x + 10, y + 10), key_name, font=f, fill=(0, 0, 0))
        return w


# =============================================================================
# 1. ASSEMBLY IMAGES (3D CAD OpenSCAD Renders)
# =============================================================================

def generate_assembly_images():
    print("Generating 3D Assembly Renders...")
    
    # A. Fraction Studio Assembly Scene
    scad_frac = SCENE_DIR / "fraction_assembly.scad"
    scad_frac.write_text(r"""$fn = 30;
// Baseplate
color([0.88, 0.86, 0.82]) translate([-0.25, -42, -6]) cube([168, 168, 6]);

// Fraction Tray (Apollo Cream)
color([0.92, 0.91, 0.89]) {
    difference() {
        cube([167.5, 83.5, 6]);
        // 4 entry wells
        for (x = [8, 48, 88, 128]) {
            translate([x, 83.5 - 26 - 20, 3.5]) cube([32, 20, 3]);
        }
        // 6 tower sockets
        for (x = [8, 35, 62, 89, 116, 143]) {
            translate([x, 83.5 - 56 - 25.2, 3]) cube([25.2, 25.2, 3.2]);
        }
    }
}
// Upright Fraction Blocks seated in sockets
color([0.03, 0.50, 0.51]) translate([8.6, 83.5 - 56 - 24.6, 4]) cube([24, 24, 96]); // 1 Whole (96mm)
color([0.85, 0.55, 0.15]) translate([35.6, 83.5 - 56 - 24.6, 4]) cube([24, 24, 48]); // 1/2
color([0.85, 0.55, 0.15]) translate([35.6, 83.5 - 56 - 24.6, 52]) cube([24, 24, 48]); // 1/2 (Stacked = 96mm)
color([0.20, 0.40, 0.65]) translate([62.6, 83.5 - 56 - 24.6, 4]) cube([24, 24, 32]); // 1/3
color([0.20, 0.40, 0.65]) translate([62.6, 83.5 - 56 - 24.6, 36]) cube([24, 24, 32]);
color([0.20, 0.40, 0.65]) translate([62.6, 83.5 - 56 - 24.6, 68]) cube([24, 24, 32]); // 3/3 = 96mm
color([0.70, 0.25, 0.25]) translate([89.6, 83.5 - 56 - 24.6, 4]) cube([24, 24, 24]); // 1/4
color([0.70, 0.25, 0.25]) translate([89.6, 83.5 - 56 - 24.6, 28]) cube([24, 24, 24]);
color([0.70, 0.25, 0.25]) translate([89.6, 83.5 - 56 - 24.6, 52]) cube([24, 24, 24]);
color([0.70, 0.25, 0.25]) translate([89.6, 83.5 - 56 - 24.6, 76]) cube([24, 24, 24]); // 4/4 = 96mm
color([0.45, 0.65, 0.35]) translate([116.6, 83.5 - 56 - 24.6, 4]) cube([24, 24, 16]); // 1/6
color([0.55, 0.30, 0.60]) translate([143.6, 83.5 - 56 - 24.6, 4]) cube([24, 24, 12]); // 1/8

// Numeral tiles in entry wells
color([0.96, 0.95, 0.92]) translate([9, 83.5 - 25 - 18, 4.5]) cube([30, 18, 2.4]);
color([0.96, 0.95, 0.92]) translate([49, 83.5 - 25 - 18, 4.5]) cube([30, 18, 2.4]);
color([0.96, 0.95, 0.92]) translate([89, 83.5 - 25 - 18, 4.5]) cube([30, 18, 2.4]);
""")
    tmp_out = BUILD_DIR / "frac_raw.png"
    render_openscad_scene(scad_frac, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Fraction Studio Assembly", "Upright height comparison (96 mm) with Gridfinity tray dock")
        banner.save(PREVIEW_DIR / "fraction_studio_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "fraction_studio_assembly.png")

    # B. Stack Stage Assembly Scene
    scad_stack = SCENE_DIR / "stack_assembly.scad"
    scad_stack.write_text(r"""$fn = 30;
color([0.92, 0.91, 0.89]) {
    difference() {
        cube([125.5, 125.5, 6]);
        // 4 register wells: T, Z, Y, X
        for (i = [0:3]) {
            translate([36, 125.5 - (28 + i * 22) - 18, 3.5]) cube([82, 18, 3.2]);
        }
    }
}
// Blank value tiles inserted
color([0.98, 0.98, 0.96]) translate([38, 125.5 - 28 - 16, 4.5]) cube([78, 16, 2.4]); // T
color([0.98, 0.98, 0.96]) translate([38, 125.5 - 50 - 16, 4.5]) cube([78, 16, 2.4]); // Z
color([0.98, 0.98, 0.96]) translate([38, 125.5 - 72 - 16, 4.5]) cube([78, 16, 2.4]); // Y
color([0.03, 0.50, 0.51]) translate([38, 125.5 - 94 - 16, 4.5]) cube([78, 16, 2.4]); // X (Active)
""")
    tmp_out = BUILD_DIR / "stack_raw.png"
    render_openscad_scene(scad_stack, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Stack Stage Assembly", "4-Register RPN (T, Z, Y, X) 3x3 Gridfinity Stage with Value Tiles")
        banner.save(PREVIEW_DIR / "stack_stage_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "stack_stage_assembly.png")

    # C. Expression Tree Assembly Scene
    scad_tree = SCENE_DIR / "tree_assembly.scad"
    scad_tree.write_text(r"""$fn = 30;
color([0.92, 0.91, 0.89]) {
    difference() {
        cube([167.5, 125.5, 6]);
        // 7 circular wells
        for (pos = [[24,98],[68,98],[46,64],[104,98],[148,98],[126,64],[86,32]]) {
            translate([pos[0], 125.5 - pos[1], 3.5]) cylinder(r=11.5, h=3.2);
        }
    }
}
// Removable tokens
color([0.03, 0.50, 0.51]) translate([24, 125.5 - 98, 4.2]) cylinder(r=11.2, h=3); // 1 / a
color([0.03, 0.50, 0.51]) translate([68, 125.5 - 98, 4.2]) cylinder(r=11.2, h=3); // 2 / b
color([0.85, 0.55, 0.15]) translate([46, 125.5 - 64, 4.2]) cylinder(r=11.2, h=3); // 3 / +
color([0.03, 0.50, 0.51]) translate([104, 125.5 - 98, 4.2]) cylinder(r=11.2, h=3); // 4 / c
color([0.03, 0.50, 0.51]) translate([148, 125.5 - 98, 4.2]) cylinder(r=11.2, h=3); // 5 / d
color([0.85, 0.55, 0.15]) translate([126, 125.5 - 64, 4.2]) cylinder(r=11.2, h=3); // 6 / -
color([0.70, 0.25, 0.25]) translate([86, 125.5 - 32, 4.2]) cylinder(r=11.2, h=3);  // 7 / *
""")
    tmp_out = BUILD_DIR / "tree_raw.png"
    render_openscad_scene(scad_tree, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Expression Tree Assembly", "4x3 Gridfinity Tray: Postorder binary tree (a + b) * (c - d)")
        banner.save(PREVIEW_DIR / "expression_tree_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "expression_tree_assembly.png")

    # D. Coordinate Lab Assembly Scene
    scad_coord = SCENE_DIR / "coord_assembly.scad"
    scad_coord.write_text(r"""$fn = 30;
color([0.92, 0.91, 0.89]) {
    difference() {
        cube([167.5, 167.5, 6]);
        // 10x10 sockets
        for (i = [0:9]) {
            for (j = [0:9]) {
                translate([28 + 12*i, 167.5 - (32 + 12*j), 3.5]) cylinder(r=2.2, h=3.2);
            }
        }
    }
}
// Locator pegs at A(1, 2) and B(4, 6)
// A: i=1, j=7 (from bottom y=2) -> x = 28+12 = 40, y = 32 + 12*(9-2) = 116
color([0.85, 0.25, 0.15]) translate([40, 167.5 - 116, 4.5]) {
    cylinder(r=5, h=2);
    cylinder(r=1.9, h=5);
}
// B: i=4, j=3 (from bottom y=6) -> x = 28+48 = 76, y = 32 + 12*(9-6) = 68
color([0.85, 0.25, 0.15]) translate([76, 167.5 - 68, 4.5]) {
    cylinder(r=5, h=2);
    cylinder(r=1.9, h=5);
}
// Hypotenuse yarn string
color([0.03, 0.50, 0.51]) hull() {
    translate([40, 167.5 - 116, 6]) sphere(r=1.5);
    translate([76, 167.5 - 68, 6]) sphere(r=1.5);
}
""")
    tmp_out = BUILD_DIR / "coord_raw.png"
    render_openscad_scene(scad_coord, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Coordinate Lab Assembly", "10x10 Point Grid with Locator Pegs & 3-4-5 Triangle Hypotenuse")
        banner.save(PREVIEW_DIR / "coordinate_lab_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "coordinate_lab_assembly.png")

    # E. Full Gridfinity Ecosystem Assembly (The Box as the Lab)
    scad_eco = SCENE_DIR / "ecosystem_assembly.scad"
    scad_eco.write_text(r"""$fn = 30;
// 4x4 Baseplate
color([0.85, 0.83, 0.80]) cube([168, 168, 6]);

// Fraction Tray docked in bottom 2 rows (4x2)
color([0.92, 0.91, 0.89]) translate([0.25, 0.25, 6]) cube([167.5, 83.5, 6]);
// Fraction blocks
color([0.03, 0.50, 0.51]) translate([10, 20, 12]) cube([24, 24, 60]);
color([0.85, 0.55, 0.15]) translate([38, 20, 12]) cube([24, 24, 48]);

// Stack Stage docked in upper row (3x2 portion)
color([0.94, 0.93, 0.91]) translate([0.25, 84.25, 6]) cube([125.5, 83.5, 6]);

// Accessory organizer bin (1x2 portion)
color([0.90, 0.89, 0.87]) translate([126.25, 84.25, 6]) cube([41.5, 83.5, 18]);
""")
    tmp_out = BUILD_DIR / "eco_raw.png"
    render_openscad_scene(scad_eco, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Gridfinity Modular Classroom Kit", "Zero-waste packaging: baseplate acts as activity dock & storage foundation")
        banner.save(PREVIEW_DIR / "gridfinity_ecosystem_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "gridfinity_ecosystem_assembly.png")

    # F. Ten-Frame Stage Assembly
    scad_ten = SCENE_DIR / "ten_frame_assembly.scad"
    scad_ten.write_text(r"""$fn = 30;
color([0.92, 0.91, 0.89]) {
    difference() {
        cube([167.5, 83.5, 6]);
        for (r = [0:1]) {
            for (c = [0:4]) {
                translate([24 + c * 28, 83.5 - (38 + r * 26), 3.5]) cylinder(r=11.5, h=3.2);
            }
        }
    }
}
// 7 counters: 5 top row, 2 bottom row (subitizing 7)
for (c = [0:4]) {
    color([0.03, 0.50, 0.51]) translate([24 + c * 28, 83.5 - 38, 4.2]) cylinder(r=11, h=3);
}
for (c = [0:1]) {
    color([0.85, 0.55, 0.15]) translate([24 + c * 28, 83.5 - 64, 4.2]) cylinder(r=11, h=3);
}
""")
    tmp_out = BUILD_DIR / "ten_raw.png"
    render_openscad_scene(scad_ten, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Ten-Frame Stage Assembly", "4x2 Gridfinity: 2x5 Counter Array & Subitizing 5-Split")
        banner.save(PREVIEW_DIR / "ten_frame_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "ten_frame_assembly.png")

    # G. Number Bond Stage Assembly
    scad_bond = SCENE_DIR / "bond_assembly.scad"
    scad_bond.write_text(r"""$fn = 30;
color([0.92, 0.91, 0.89]) {
    difference() {
        cube([125.5, 83.5, 6]);
        translate([62.75, 83.5 - 34, 3.5]) cylinder(r=16, h=3.2);
        translate([30, 83.5 - 62, 3.5]) cylinder(r=14, h=3.2);
        translate([95.5, 83.5 - 62, 3.5]) cylinder(r=14, h=3.2);
    }
}
color([0.03, 0.50, 0.51]) translate([62.75, 83.5 - 34, 4.2]) cylinder(r=15, h=3); // Whole (7)
color([0.85, 0.55, 0.15]) translate([30, 83.5 - 62, 4.2]) cylinder(r=13, h=3); // Part 1 (4)
color([0.70, 0.25, 0.25]) translate([95.5, 83.5 - 62, 4.2]) cylinder(r=13, h=3); // Part 2 (3)
""")
    tmp_out = BUILD_DIR / "bond_raw.png"
    render_openscad_scene(scad_bond, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Number Bond Stage Assembly", "3x2 Gridfinity: Part-Part-Whole RPN Binary Addition")
        banner.save(PREVIEW_DIR / "number_bond_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "number_bond_assembly.png")

    # H. Number Rack Assembly
    scad_rack = SCENE_DIR / "rack_assembly.scad"
    scad_rack.write_text(r"""$fn = 30;
color([0.92, 0.91, 0.89]) {
    difference() {
        cube([167.5, 83.5, 6]);
        translate([14, 83.5 - 44, 3.5]) cube([139.5, 16, 3.2]);
        translate([14, 83.5 - 68, 3.5]) cube([139.5, 16, 3.2]);
    }
}
for (b = [0:4]) {
    color([0.85, 0.25, 0.15]) translate([22 + b * 11, 83.5 - 36, 5]) sphere(r=5.5);
    color([0.85, 0.25, 0.15]) translate([22 + b * 11, 83.5 - 60, 5]) sphere(r=5.5);
}
for (b = [5:9]) {
    color([0.98, 0.98, 0.98]) translate([55 + b * 10, 83.5 - 36, 5]) sphere(r=5.5);
    color([0.98, 0.98, 0.98]) translate([55 + b * 10, 83.5 - 60, 5]) sphere(r=5.5);
}
""")
    tmp_out = BUILD_DIR / "rack_raw.png"
    render_openscad_scene(scad_rack, tmp_out)
    with Image.open(tmp_out) as raw:
        banner = add_banner(raw, "Number Rack Stage Assembly", "4x2 Gridfinity: Dual 10-Bead Rows (5 Red + 5 White) & ENTER Doubles")
        banner.save(PREVIEW_DIR / "number_rack_assembly.png")
        banner.save(WEBSITE_ASSETS_DIR / "number_rack_assembly.png")



# =============================================================================
# 2. USAGE ANIMATIONS (High-Clarity Looping Animated GIFs)
# =============================================================================

def generate_usage_animations():
    print("Generating Usage Animations (GIF)...")

    # -------------------------------------------------------------------------
    # A. STACK STAGE USAGE ANIMATION (8 ENTER 3 - 2 * = 10)
    # -------------------------------------------------------------------------
    steps_stack = [
        {"title": "Initial State", "sub": "4-Level RPN Registers initialized to zero", "keys": [], "stack": ["0", "0", "0", "0"], "desc": "Screen display X is 0. Stack registers T, Z, Y are cleared."},
        {"title": "Step 1: Enter 8", "sub": "Digit 8 enters active display register X", "keys": ["8"], "stack": ["0", "0", "0", "8"], "desc": "Value 8 is entered into X. Y, Z, T remain 0."},
        {"title": "Step 2: Press ENTER", "sub": "ENTER duplicates X into Y; disables next lift", "keys": ["enter"], "stack": ["0", "0", "8", "8"], "desc": "Value 8 copied up to register Y. Both Y and X hold 8."},
        {"title": "Step 3: Enter 3", "sub": "New number replaces X without moving Y", "keys": ["3"], "stack": ["0", "0", "8", "3"], "desc": "X is replaced by 3. First operand 8 remains in Y."},
        {"title": "Step 4: Press MINUS (-)", "sub": "Binary operation combines Y - X (8 - 3 = 5)", "keys": ["minus"], "stack": ["0", "0", "0", "5"], "desc": "Result 5 drops into X! Top register T repeats downward."},
        {"title": "Step 5: Enter 2 (Automatic Lift)", "sub": "New entry after arithmetic automatically lifts stack!", "keys": ["2"], "stack": ["0", "0", "5", "2"], "desc": "Previous answer 5 automatically lifts to Y! 2 enters X."},
        {"title": "Step 6: Press MULTIPLY (*)", "sub": "Binary multiplication combines Y * X (5 * 2 = 10)", "keys": ["times"], "stack": ["0", "0", "0", "10"], "desc": "Final result 10 in X. Perfect stack execution without parentheses!"}
    ]

    frames_stack = []
    w_anim, h_anim = 900, 560
    f_title = ImageFont.truetype(str(SPACE_MONO_BOLD), 22)
    f_sub = ImageFont.truetype(str(SPACE_MONO_BOLD), 14)
    f_reg = ImageFont.truetype(str(SPACE_MONO_BOLD), 24)
    f_val = ImageFont.truetype(str(SPACE_MONO_BOLD), 26)
    f_desc = ImageFont.truetype(str(SPACE_MONO_REG), 14)

    for step in steps_stack:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        # Header
        draw.text((36, 20), "STACK STAGE USAGE  //  4-REGISTER RPN", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Physical Stack Stage Tray Graphic
        tray_x, tray_y, tray_w, tray_h = 36, 120, 380, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "STACK STAGE (3x3 GRIDFINITY)", font=f_sub, fill=COLOR_TEAL)

        reg_names = [("T", "fourth"), ("Z", "third"), ("Y", "first operand"), ("X", "screen / active")]
        for idx, (reg, label) in enumerate(reg_names):
            ry = tray_y + 50 + idx * 72
            # Register Label
            draw.text((tray_x + 16, ry + 12), reg, font=f_reg, fill=COLOR_TEXT)
            draw.text((tray_x + 16, ry + 38), label[:12], font=ImageFont.truetype(str(SPACE_MONO_REG), 10), fill=COLOR_TEAL)
            
            # Value Well & Tile
            well_x = tray_x + 80
            is_active = (reg == "X") or (reg == "Y" and step["stack"][2] != "0")
            tile_fill = (255, 255, 255) if is_active else (245, 243, 238)
            outline_color = COLOR_TEAL if (reg == "X") else COLOR_MUTED
            draw.rounded_rectangle([well_x, ry, well_x + 270, ry + 56], radius=6, fill=tile_fill, outline=outline_color, width=2 if is_active else 1)
            
            val_text = step["stack"][idx]
            val_color = COLOR_TEAL if is_active else (140, 160, 155)
            draw.text((well_x + 115, ry + 12), val_text, font=f_val, fill=val_color)

        # Right Column: Keystrokes & Mathematical Explanation
        right_x = 440
        draw.rounded_rectangle([right_x, tray_y, right_x + 424, tray_y + 160], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 16), "ACTION KEYSTROKE", font=f_sub, fill=COLOR_TEAL)

        if step["keys"]:
            kx = right_x + 20
            for k in step["keys"]:
                kw = draw_keycap_on(draw, frame, k, kx, tray_y + 50, h=52)
                kx += kw + 12
        else:
            draw.text((right_x + 20, tray_y + 60), "[Ready for Input]", font=f_sub, fill=(160, 170, 165))

        # Bottom Explanation Card
        exp_y = tray_y + 180
        draw.rounded_rectangle([right_x, exp_y, right_x + 424, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 18), "INTERNAL RPN BEHAVIOR", font=f_sub, fill=COLOR_TEAL)
        
        # Word wrap description
        words = step["desc"].split()
        lines = []
        cur_line = []
        for w in words:
            if len(" ".join(cur_line + [w])) < 38:
                cur_line.append(w)
            else:
                lines.append(" ".join(cur_line))
                cur_line = [w]
        if cur_line: lines.append(" ".join(cur_line))

        for l_idx, l in enumerate(lines):
            draw.text((right_x + 20, exp_y + 54 + l_idx * 26), l, font=f_desc, fill=COLOR_TEXT)

        # Progress dots
        for dot_i in range(len(steps_stack)):
            dot_color = COLOR_TEAL if dot_i == steps_stack.index(step) else COLOR_MUTED
            draw.ellipse([right_x + 20 + dot_i * 24, exp_y + 140, right_x + 32 + dot_i * 24, exp_y + 152], fill=dot_color)

        frames_stack.append(frame)

    frames_stack[0].save(
        PREVIEW_DIR / "stack_stage_usage.gif",
        save_all=True, append_images=frames_stack[1:], duration=1800, loop=0
    )
    frames_stack[0].save(
        WEBSITE_ASSETS_DIR / "stack_stage_usage.gif",
        save_all=True, append_images=frames_stack[1:], duration=1800, loop=0
    )

    # -------------------------------------------------------------------------
    # B. FRACTION STUDIO USAGE ANIMATION (.3.4 ENTER 2.1.2 + = 3 1/4)
    # -------------------------------------------------------------------------
    steps_frac = [
        {"title": "Step 1: Equivalent Tower Proof", "sub": "Two 1/2 blocks equal one whole (96 mm)", "keys": [], "h1": 96, "h2": 96, "disp": "0", "desc": "Both stacks reach exactly 96 mm. Equal heights = visual rational equivalence."},
        {"title": "Step 2: Enter 3/4 in Tower 1", "sub": "Three 1/4 blocks (72 mm); type . 3 . 4", "keys": ["dot", "3", "dot", "4"], "h1": 72, "h2": 0, "disp": "3/4", "desc": "Two dots separate Whole . Numerator . Denominator fields without dividing."},
        {"title": "Step 3: Press ENTER", "sub": "3/4 copied to register Y; second tower ready", "keys": ["enter"], "h1": 72, "h2": 0, "disp": "3/4", "desc": "Register Y holds first fraction 3/4. Sockets compare towers on a common floor."},
        {"title": "Step 4: Enter 2 1/2 in Tower 2", "sub": "Two wholes (192 mm) + one half (48 mm); type 2 . 1 . 2", "keys": ["2", "dot", "1", "dot", "2"], "h1": 72, "h2": 240, "disp": "2 1/2", "desc": "Mixed number 2 1/2 entered in X. Adjacent towers show the two amounts."},
        {"title": "Step 5: Press PLUS (+)", "sub": "Binary addition evaluates 3/4 + 2 1/2 = 3 1/4", "keys": ["plus"], "h1": 312, "h2": 0, "disp": "3 1/4 (3.25)", "desc": "Result combined in X: 3 1/4. Direct physical connection from height to answer!"}
    ]

    frames_frac = []
    for step in steps_frac:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        draw.text((36, 20), "FRACTION STUDIO USAGE  //  UPRIGHT TOWERS", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Tower Socket Stage
        tray_x, tray_y, tray_w, tray_h = 36, 120, 380, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "FRACTION TRAY & SOCKETS", font=f_sub, fill=COLOR_TEAL)

        # Common Floor Line
        floor_y = tray_y + 300
        draw.line([(tray_x + 20, floor_y), (tray_x + tray_w - 20, floor_y)], fill=COLOR_TEXT, width=3)
        draw.text((tray_x + 20, floor_y + 8), "Common Socket Floor (0 mm)", font=ImageFont.truetype(str(SPACE_MONO_REG), 10), fill=COLOR_TEAL)

        # 96mm Reference Target Line
        ref_96_y = floor_y - int(96 * 1.5)
        draw.line([(tray_x + 20, ref_96_y), (tray_x + tray_w - 20, ref_96_y)], fill=COLOR_GOLD, width=2)
        draw.text((tray_x + 20, ref_96_y - 16), "1 Whole Benchmark (96 mm)", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 10), fill=COLOR_GOLD)

        # Draw Tower 1
        t1_x = tray_x + 80
        t1_h = int(min(step["h1"], 180) * 1.5)
        if t1_h > 0:
            draw.rounded_rectangle([t1_x, floor_y - t1_h, t1_x + 50, floor_y], radius=3, fill=(3, 128, 130), outline=(20, 20, 20), width=1)
            draw.text((t1_x + 12, floor_y - t1_h / 2 - 8), f"{step['h1']}mm", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 11), fill=(255, 255, 255))
        draw.text((t1_x + 6, floor_y + 26), "Tower 1", font=f_sub, fill=COLOR_TEXT)

        # Draw Tower 2
        t2_x = tray_x + 200
        t2_h = int(min(step["h2"], 180) * 1.5)
        if t2_h > 0:
            draw.rounded_rectangle([t2_x, floor_y - t2_h, t2_x + 50, floor_y], radius=3, fill=(215, 140, 38), outline=(20, 20, 20), width=1)
            draw.text((t2_x + 12, floor_y - t2_h / 2 - 8), f"{step['h2']}mm", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 11), fill=(255, 255, 255))
        draw.text((t2_x + 6, floor_y + 26), "Tower 2", font=f_sub, fill=COLOR_TEXT)

        # Right Column: Keystrokes & Screen Display
        right_x = 440
        draw.rounded_rectangle([right_x, tray_y, right_x + 424, tray_y + 150], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 14), "TWO-DOT CALCULATOR ENTRY", font=f_sub, fill=COLOR_TEAL)
        
        if step["keys"]:
            kx = right_x + 20
            for k in step["keys"]:
                kw = draw_keycap_on(draw, frame, k, kx, tray_y + 44, h=46)
                kx += kw + 8
        else:
            draw.text((right_x + 20, tray_y + 54), "[Visual Representation]", font=f_sub, fill=(160, 170, 165))

        draw.text((right_x + 20, tray_y + 110), f"Display X: {step['disp']}", font=f_title, fill=COLOR_TEAL)

        # Bottom Explanation Card
        exp_y = tray_y + 170
        draw.rounded_rectangle([right_x, exp_y, right_x + 424, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 16), "PEDAGOGICAL INSIGHT", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, exp_y + 50), step["desc"], font=f_desc, fill=COLOR_TEXT)

        frames_frac.append(frame)

    frames_frac[0].save(
        PREVIEW_DIR / "fraction_studio_usage.gif",
        save_all=True, append_images=frames_frac[1:], duration=1800, loop=0
    )
    frames_frac[0].save(
        WEBSITE_ASSETS_DIR / "fraction_studio_usage.gif",
        save_all=True, append_images=frames_frac[1:], duration=1800, loop=0
    )

    # -------------------------------------------------------------------------
    # C. EXPRESSION TREE USAGE ANIMATION ((3 + 2) * (8 - 4) = 20)
    # -------------------------------------------------------------------------
    steps_tree = [
        {"title": "Tree Overview: Postorder Traversal", "sub": "(a + b) * (c - d) without parentheses", "active_node": 0, "keys": [], "val": "Ready", "desc": "Infix syntax requires grouping symbols. RPN uses postorder traversal: left, right, operator."},
        {"title": "Step 1: Left Operand 'a' (3)", "sub": "Node 1: Value 3 enters stack", "active_node": 1, "keys": ["3", "enter"], "val": "3 in Y", "desc": "Token 'a' assigned value 3. Press 3 then ENTER to stage for next leaf."},
        {"title": "Step 2: Left Operand 'b' (2)", "sub": "Node 2: Value 2 enters X", "active_node": 2, "keys": ["2"], "val": "2 in X", "desc": "Token 'b' assigned value 2. Both operands are ready for the left operator."},
        {"title": "Step 3: Evaluate Left Operator (+)", "sub": "Node 3: Evaluates 3 + 2 = 5", "active_node": 3, "keys": ["plus"], "val": "5 (Subtotal 1)", "desc": "Addition combines 3 and 2. Subtree result 5 remains safely in X!"},
        {"title": "Step 4: Right Operand 'c' (8)", "sub": "Node 4: 8 enters X; 5 automatically lifts to Y!", "active_node": 4, "keys": ["8", "enter"], "val": "8 in Y (5 in Z)", "desc": "Entering 8 lifts subtotal 5 into Y. Duplicate 8 with ENTER."},
        {"title": "Step 5: Right Operand 'd' (4)", "sub": "Node 5: Value 4 enters X", "active_node": 5, "keys": ["4"], "val": "4 in X", "desc": "Token 'd' enters X. Stack holds Z=5, Y=8, X=4."},
        {"title": "Step 6: Evaluate Right Operator (-)", "sub": "Node 6: Evaluates 8 - 4 = 4", "active_node": 6, "keys": ["minus"], "val": "4 (Subtotal 2)", "desc": "Subtraction combines 8 - 4 = 4. Subtotal 5 drops down to register Y."},
        {"title": "Step 7: Evaluate Root Operator (*)", "sub": "Node 7: Final root evaluates 5 * 4 = 20", "active_node": 7, "keys": ["times"], "val": "20 (Final Result)", "desc": "Root multiplication combines the two subtrees: 5 * 4 = 20. Zero parentheses required!"}
    ]

    frames_tree = []
    # Tree node positions (x, y) relative to diagram canvas
    nodes_pos = {
        1: (80, 260, "1 / a"),
        2: (150, 260, "2 / b"),
        3: (115, 180, "3 / +"),
        4: (240, 260, "4 / c"),
        5: (310, 260, "5 / d"),
        6: (275, 180, "6 / -"),
        7: (195, 100, "7 / *"),
    }
    branches = [(7, 3), (7, 6), (3, 1), (3, 2), (6, 4), (6, 5)]

    for step in steps_tree:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        draw.text((36, 20), "EXPRESSION TREE USAGE  //  POSTORDER PARSING", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Expression Tree Diagram
        tray_x, tray_y, tray_w, tray_h = 36, 120, 390, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "BALANCED BINARY TREE TRAY", font=f_sub, fill=COLOR_TEAL)

        # Draw branches
        for p1, p2 in branches:
            x1, y1, _ = nodes_pos[p1]
            x2, y2, _ = nodes_pos[p2]
            draw.line([(tray_x + x1, tray_y + y1), (tray_x + x2, tray_y + y2)], fill=COLOR_MUTED, width=3)

        # Draw nodes
        for n_id, (nx, ny, nlbl) in nodes_pos.items():
            is_active = (n_id == step["active_node"])
            n_color = COLOR_GOLD if is_active else ((3, 128, 130) if n_id in (1,2,4,5) else (215, 140, 38))
            draw.ellipse([tray_x + nx - 20, tray_y + ny - 20, tray_x + nx + 20, tray_y + ny + 20],
                         fill=n_color, outline=(20, 20, 20), width=2 if is_active else 1)
            f_tok = ImageFont.truetype(str(SPACE_MONO_BOLD), 12)
            draw.text((tray_x + nx - 6, tray_y + ny - 8), nlbl.split("/")[1].strip(), font=f_tok, fill=(255, 255, 255))
            draw.text((tray_x + nx - 10, tray_y + ny + 24), nlbl.split("/")[0].strip(), font=ImageFont.truetype(str(SPACE_MONO_BOLD), 9), fill=COLOR_TEXT)

        # Right Column: Keystrokes & RPN Result
        right_x = 450
        draw.rounded_rectangle([right_x, tray_y, right_x + 414, tray_y + 150], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 14), "HARDWARE KEYSTROKES", font=f_sub, fill=COLOR_TEAL)

        if step["keys"]:
            kx = right_x + 20
            for k in step["keys"]:
                kw = draw_keycap_on(draw, frame, k, kx, tray_y + 44, h=48)
                kx += kw + 10
        else:
            draw.text((right_x + 20, tray_y + 54), "[Structural Readout]", font=f_sub, fill=(160, 170, 165))

        draw.text((right_x + 20, tray_y + 110), f"Current State: {step['val']}", font=f_title, fill=COLOR_TEAL)

        # Bottom Explanation Card
        exp_y = tray_y + 170
        draw.rounded_rectangle([right_x, exp_y, right_x + 414, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 16), "TRAVERSAL LOGIC", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, exp_y + 50), step["desc"], font=f_desc, fill=COLOR_TEXT)

        frames_tree.append(frame)

    frames_tree[0].save(
        PREVIEW_DIR / "expression_tree_usage.gif",
        save_all=True, append_images=frames_tree[1:], duration=1800, loop=0
    )
    frames_tree[0].save(
        WEBSITE_ASSETS_DIR / "expression_tree_usage.gif",
        save_all=True, append_images=frames_tree[1:], duration=1800, loop=0
    )

    # -------------------------------------------------------------------------
    # D. COORDINATE LAB USAGE ANIMATION (3-4-5 Triangle Distance Pipeline)
    # -------------------------------------------------------------------------
    steps_coord = [
        {"title": "Step 1: Insert Locator Pegs", "sub": "Place Peg A at (1, 2) and Peg B at (4, 6)", "keys": [], "res": "A(1,2) & B(4,6)", "desc": "Grid uses standard 12 mm pitch with 10x10 coordinates 0-9. Count grid intervals directly."},
        {"title": "Step 2: Measure Horizontal Run", "sub": "Run = 4 - 1 = 3; Keystrokes: 1 ENTER 4 - x^2", "keys": ["1", "enter", "4", "minus", "yellow_x_squared"], "res": "Δx² = 9 in X", "desc": "Horizontal difference squared is 9. Sits in X register."},
        {"title": "Step 3: Measure Vertical Rise", "sub": "Rise = 6 - 2 = 4; Keystrokes: 2 ENTER 6 - x^2", "keys": ["2", "enter", "6", "minus", "yellow_x_squared"], "res": "Δy² = 16 in X (9 in Y)", "desc": "Entering 2 lifts 9 into Y! Vertical square is 16. Stack holds both squares simultaneously."},
        {"title": "Step 4: Sum of Squares (+)", "sub": "Add the squares: 9 + 16 = 25", "keys": ["plus"], "res": "Sum = 25 in X", "desc": "Plus combines horizontal and vertical squares. One operation combines both axes."},
        {"title": "Step 5: Square Root (√𝑥)", "sub": "Square root yields exact Euclidean distance 5", "keys": ["sqrt_x"], "res": "Distance = 5", "desc": "Exact 3-4-5 right triangle hypotenuse verified. Physical yarn length matches numerical output!"}
    ]

    frames_coord = []
    for step in steps_coord:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        draw.text((36, 20), "COORDINATE LAB USAGE  //  PYTHAGOREAN PIPELINE", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Coordinate Grid Graphic
        tray_x, tray_y, tray_w, tray_h = 36, 120, 390, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "10x10 POINT GRID (12mm PITCH)", font=f_sub, fill=COLOR_TEAL)

        grid_ox, grid_oy = tray_x + 50, tray_y + 50
        cell_size = 28
        # Draw grid sockets
        for i in range(10):
            for j in range(10):
                gx = grid_ox + i * cell_size
                gy = grid_oy + (9 - j) * cell_size
                draw.ellipse([gx - 3, gy - 3, gx + 3, gy + 3], fill=(180, 195, 190))

        # Peg A(1, 2)
        ax = grid_ox + 1 * cell_size
        ay = grid_oy + (9 - 2) * cell_size
        draw.ellipse([ax - 9, ay - 9, ax + 9, ay + 9], fill=(215, 55, 35), outline=(20, 20, 20), width=2)
        draw.text((ax - 18, ay - 24), "A(1,2)", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 10), fill=COLOR_TEXT)

        # Peg B(4, 6)
        bx = grid_ox + 4 * cell_size
        by = grid_oy + (9 - 6) * cell_size
        draw.ellipse([bx - 9, by - 9, bx + 9, by + 9], fill=(215, 55, 35), outline=(20, 20, 20), width=2)
        draw.text((bx + 12, by - 12), "B(4,6)", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 10), fill=COLOR_TEXT)

        # Right Triangle lines
        corner_x = bx
        corner_y = ay
        draw.line([(ax, ay), (corner_x, corner_y)], fill=(8, 127, 130), width=3)      # Run (Δx = 3)
        draw.line([(corner_x, corner_y), (bx, by)], fill=(8, 127, 130), width=3)      # Rise (Δy = 4)
        draw.line([(ax, ay), (bx, by)], fill=COLOR_GOLD, width=4)                     # Hypotenuse (c = 5)
        draw.text((ax + 35, ay + 6), "run = 3", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 10), fill=COLOR_TEAL)
        draw.text((corner_x + 8, ay - 55), "rise = 4", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 10), fill=COLOR_TEAL)
        draw.text((ax + 20, ay - 60), "dist = 5", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 11), fill=COLOR_GOLD)

        # Right Column: Keystrokes & RPN Result
        right_x = 450
        draw.rounded_rectangle([right_x, tray_y, right_x + 414, tray_y + 150], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 14), "PYTHAGOREAN KEYSTROKES", font=f_sub, fill=COLOR_TEAL)

        if step["keys"]:
            kx = right_x + 20
            for k in step["keys"]:
                kw = draw_keycap_on(draw, frame, k, kx, tray_y + 44, h=46)
                kx += kw + 8
        else:
            draw.text((right_x + 20, tray_y + 54), "[Physical Peg Setup]", font=f_sub, fill=(160, 170, 165))

        draw.text((right_x + 20, tray_y + 110), f"Status: {step['res']}", font=f_title, fill=COLOR_TEAL)

        # Bottom Explanation Card
        exp_y = tray_y + 170
        draw.rounded_rectangle([right_x, exp_y, right_x + 414, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 16), "GEOMETRIC PARITY", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, exp_y + 50), step["desc"], font=f_desc, fill=COLOR_TEXT)

        frames_coord.append(frame)

    frames_coord[0].save(
        PREVIEW_DIR / "coordinate_lab_usage.gif",
        save_all=True, append_images=frames_coord[1:], duration=1800, loop=0
    )
    frames_coord[0].save(
        WEBSITE_ASSETS_DIR / "coordinate_lab_usage.gif",
        save_all=True, append_images=frames_coord[1:], duration=1800, loop=0
    )

    # -------------------------------------------------------------------------
    # E. GRIDFINITY MODULAR DOCKING USAGE ANIMATION (The Box as the Lab)
    # -------------------------------------------------------------------------
    steps_dock = [
        {"title": "Step 1: 4x4 Gridfinity Baseplate", "sub": "Standard 42 mm grid unit foundation on student desk", "docked": [1], "desc": "Solid 168 x 168 mm baseplate anchors securely to desk. Sockets accept any modular manipulative."},
        {"title": "Step 2: Dock Fraction Studio (4x2)", "sub": "Snaps into the lower two grid rows", "docked": [1, 2], "desc": "Standard Gridfinity underside plugs lock into baseplate sockets with zero wobble."},
        {"title": "Step 3: Dock Stack Stage (3x3)", "sub": "Stands adjacent to Fraction Studio", "docked": [1, 2, 3], "desc": "Modular form factors allow configuring exactly the manipulatives needed for today's lesson."},
        {"title": "Step 4: Pack & Stack for Classroom Storage", "sub": "Trays stack together into compact self-contained kit", "docked": [1, 2, 3, 4], "desc": "No cardboard boxes, plastic baggies, or disposable packaging. The box IS the lab!"}
    ]

    frames_dock = []
    for step in steps_dock:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        draw.text((36, 20), "GRIDFINITY MODULAR LAB  //  ZERO-WASTE SYSTEM", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Isometric Grid Diagram
        tray_x, tray_y, tray_w, tray_h = 36, 120, 390, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "DESK DOCKING & STACKING", font=f_sub, fill=COLOR_TEAL)

        # Baseplate grid outline
        base_x, base_y = tray_x + 45, tray_y + 50
        draw.rectangle([base_x, base_y, base_x + 300, base_y + 280], fill=(215, 210, 200), outline=COLOR_TEXT, width=2)
        for gx in range(4):
            for gy in range(4):
                draw.rectangle([base_x + gx * 75, base_y + gy * 70, base_x + (gx + 1) * 75, base_y + (gy + 1) * 70], outline=(180, 175, 165), width=1)

        # Docked module overlays
        if 2 in step["docked"]:
            # Fraction Studio (4x2 on bottom)
            draw.rounded_rectangle([base_x + 4, base_y + 144, base_x + 296, base_y + 276], radius=4, fill=(3, 128, 130), outline=(20, 20, 20), width=2)
            draw.text((base_x + 60, base_y + 200), "Fraction Studio (4x2)", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 14), fill=(255, 255, 255))

        if 3 in step["docked"]:
            # Stack Stage (3x2 on top left)
            draw.rounded_rectangle([base_x + 4, base_y + 4, base_x + 221, base_y + 136], radius=4, fill=(215, 140, 38), outline=(20, 20, 20), width=2)
            draw.text((base_x + 30, base_y + 60), "Stack Stage (3x2)", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 14), fill=(255, 255, 255))

        if 4 in step["docked"]:
            # Stacking indicator
            draw.rounded_rectangle([base_x + 229, base_y + 4, base_x + 296, base_y + 136], radius=4, fill=(180, 70, 70), outline=(20, 20, 20), width=2)
            draw.text((base_x + 236, base_y + 60), "Caddy", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 12), fill=(255, 255, 255))

        # Right Column: System Specs
        right_x = 450
        draw.rounded_rectangle([right_x, tray_y, right_x + 414, tray_y + 150], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 14), "MODULAR SPECIFICATIONS", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, tray_y + 44), "• Unit Pitch: 42.0 mm Standard", font=f_desc, fill=COLOR_TEXT)
        draw.text((right_x + 20, tray_y + 72), "• Base Profile: 4.0 mm with 45° Chamfer", font=f_desc, fill=COLOR_TEXT)
        draw.text((right_x + 20, tray_y + 100), "• Fit Clearance: 0.5 mm Tolerance", font=f_desc, fill=COLOR_TEXT)

        # Bottom Explanation Card
        exp_y = tray_y + 170
        draw.rounded_rectangle([right_x, exp_y, right_x + 414, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 16), "ZERO-WASTE PACKAGING PHILOSOPHY", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, exp_y + 50), step["desc"], font=f_desc, fill=COLOR_TEXT)

        frames_dock.append(frame)

    frames_dock[0].save(
        PREVIEW_DIR / "gridfinity_docking_usage.gif",
        save_all=True, append_images=frames_dock[1:], duration=1800, loop=0
    )
    frames_dock[0].save(
        WEBSITE_ASSETS_DIR / "gridfinity_docking_usage.gif",
        save_all=True, append_images=frames_dock[1:], duration=1800, loop=0
    )

    # -------------------------------------------------------------------------
    # F. TEN-FRAME USAGE ANIMATION (Making 10: 10 - 7 = 3)
    # -------------------------------------------------------------------------
    steps_ten = [
        {"title": "Initial State", "sub": "7 counters placed on 2x5 Ten-Frame", "keys": [], "occ": 7, "disp": "0", "desc": "5 counters fill top row; 2 in bottom row. 3 empty spaces visible immediately."},
        {"title": "Step 1: Enter 10", "sub": "Total frame capacity enters register X", "keys": ["1", "0"], "occ": 7, "disp": "10", "desc": "Full capacity of 10 enters register X."},
        {"title": "Step 2: Press ENTER", "sub": "10 lifted to Y to hold target whole", "keys": ["enter"], "occ": 7, "disp": "10", "desc": "10 copied to register Y. Ready for subtractive complement."},
        {"title": "Step 3: Enter 7", "sub": "Current occupied counters enter register X", "keys": ["7"], "occ": 7, "disp": "7", "desc": "7 occupied counters entered into active display X."},
        {"title": "Step 4: Press MINUS (-)", "sub": "10 - 7 = 3: Exactly 3 empty wells to make 10!", "keys": ["minus"], "occ": 7, "disp": "3", "desc": "Result 3 in X. Verifies 7 + 3 = 10 without one-by-one counting!"}
    ]

    frames_ten = []
    for step in steps_ten:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        draw.text((36, 20), "TEN-FRAME STAGE USAGE  //  MAKING TEN", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Ten-Frame Stage
        tray_x, tray_y, tray_w, tray_h = 36, 120, 390, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "TEN-FRAME STAGE (4x2 GRIDFINITY)", font=f_sub, fill=COLOR_TEAL)

        # 2x5 grid of wells
        for r in range(2):
            for c in range(5):
                wx = tray_x + 35 + c * 64
                wy = tray_y + 70 + r * 110
                idx = r * 5 + c
                is_filled = idx < step["occ"]
                w_color = (8, 127, 130) if is_filled else (255, 255, 255)
                outline = (23, 61, 67) if is_filled else (180, 195, 190)
                draw.ellipse([wx, wy, wx + 54, wy + 54], fill=w_color, outline=outline, width=2)
                if is_filled:
                    draw.text((wx + 20, wy + 14), str(idx + 1), font=ImageFont.truetype(str(SPACE_MONO_BOLD), 16), fill=(255, 255, 255))
                else:
                    draw.text((wx + 20, wy + 14), "?", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 16), fill=(160, 175, 170))

        # 5-split line
        draw.line([(tray_x + 35 + 2 * 64 + 60, tray_y + 55), (tray_x + 35 + 2 * 64 + 60, tray_y + 260)], fill=COLOR_GOLD, width=2)

        # Right Column
        right_x = 450
        draw.rounded_rectangle([right_x, tray_y, right_x + 414, tray_y + 140], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 14), "CALCULATOR DISPLAY (REGISTER X)", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, tray_y + 44), f"Screen: {step['disp']}", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 36), fill=COLOR_TEXT)

        k_x = right_x + 20
        for k in step["keys"]:
            kw = draw_keycap_on(draw, frame, k, k_x, tray_y + 90, h=38)
            k_x += kw + 10

        exp_y = tray_y + 160
        draw.rounded_rectangle([right_x, exp_y, right_x + 414, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 16), "MATHEMATICAL EXPLANATION", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, exp_y + 50), step["desc"], font=f_desc, fill=COLOR_TEXT)

        frames_ten.append(frame)

    frames_ten[0].save(
        PREVIEW_DIR / "ten_frame_usage.gif",
        save_all=True, append_images=frames_ten[1:], duration=1600, loop=0
    )
    frames_ten[0].save(
        WEBSITE_ASSETS_DIR / "ten_frame_usage.gif",
        save_all=True, append_images=frames_ten[1:], duration=1600, loop=0
    )

    # -------------------------------------------------------------------------
    # G. NUMBER BOND USAGE ANIMATION (Part + Part = Whole: 4 + 3 = 7)
    # -------------------------------------------------------------------------
    steps_bond = [
        {"title": "Initial State", "sub": "Part 1 (4 counters) & Part 2 (3 counters)", "keys": [], "disp": "0", "desc": "Part 1 in bottom-left well (4). Part 2 in bottom-right well (3). Whole well empty."},
        {"title": "Step 1: Enter 4", "sub": "Part 1 enters active register X", "keys": ["4"], "disp": "4", "desc": "Value 4 entered in X."},
        {"title": "Step 2: Press ENTER", "sub": "Part 1 lifted to register Y", "keys": ["enter"], "disp": "4", "desc": "4 copied up to Y. Register Y holds Part 1."},
        {"title": "Step 3: Enter 3", "sub": "Part 2 enters active register X", "keys": ["3"], "disp": "3", "desc": "3 entered into X. Register X holds Part 2."},
        {"title": "Step 4: Press PLUS (+)", "sub": "4 + 3 = 7: Parts combine into Whole!", "keys": ["plus"], "disp": "7", "desc": "Both parts merge into the Whole well in X: 4 + 3 = 7!"}
    ]

    frames_bond = []
    for step in steps_bond:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        draw.text((36, 20), "NUMBER BOND STAGE USAGE  //  PART-PART-WHOLE", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Number Bond Graphic
        tray_x, tray_y, tray_w, tray_h = 36, 120, 390, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "NUMBER BOND STAGE (3x2 GRIDFINITY)", font=f_sub, fill=COLOR_TEAL)

        # Whole well (top center)
        wx, wy = tray_x + 155, tray_y + 60
        draw.ellipse([wx, wy, wx + 80, wy + 80], fill=(8, 127, 130) if step["disp"] == "7" else (245, 243, 238), outline=COLOR_TEAL, width=3)
        draw.text((wx + 18, wy + 26), "WHOLE", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 12), fill=(255, 255, 255) if step["disp"] == "7" else COLOR_TEAL)
        if step["disp"] == "7":
            draw.text((wx + 32, wy + 42), "7", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 24), fill=(255, 255, 255))

        # Part 1 well (bottom left)
        p1x, p1y = tray_x + 45, tray_y + 220
        draw.ellipse([p1x, p1y, p1x + 75, p1y + 75], fill=(215, 140, 38), outline=(23, 61, 67), width=2)
        draw.text((p1x + 14, p1y + 18), "PART 1 (Y)", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 10), fill=(255, 255, 255))
        draw.text((p1x + 28, p1y + 36), "4", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 22), fill=(255, 255, 255))

        # Part 2 well (bottom right)
        p2x, p2y = tray_x + 270, tray_y + 220
        draw.ellipse([p2x, p2y, p2x + 75, p2y + 75], fill=(180, 70, 70), outline=(23, 61, 67), width=2)
        draw.text((p2x + 14, p2y + 18), "PART 2 (X)", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 10), fill=(255, 255, 255))
        draw.text((p2x + 28, p2y + 36), "3", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 22), fill=(255, 255, 255))

        # Channels
        draw.line([(p1x + 60, p1y + 10), (wx + 20, wy + 70)], fill=COLOR_MUTED, width=3)
        draw.line([(p2x + 15, p2y + 10), (wx + 60, wy + 70)], fill=COLOR_MUTED, width=3)

        # Right Column
        right_x = 450
        draw.rounded_rectangle([right_x, tray_y, right_x + 414, tray_y + 140], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 14), "CALCULATOR DISPLAY (REGISTER X)", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, tray_y + 44), f"Screen: {step['disp']}", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 36), fill=COLOR_TEXT)

        k_x = right_x + 20
        for k in step["keys"]:
            kw = draw_keycap_on(draw, frame, k, k_x, tray_y + 90, h=38)
            k_x += kw + 10

        exp_y = tray_y + 160
        draw.rounded_rectangle([right_x, exp_y, right_x + 414, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 16), "MATHEMATICAL EXPLANATION", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, exp_y + 50), step["desc"], font=f_desc, fill=COLOR_TEXT)

        frames_bond.append(frame)

    frames_bond[0].save(
        PREVIEW_DIR / "number_bond_usage.gif",
        save_all=True, append_images=frames_bond[1:], duration=1600, loop=0
    )
    frames_bond[0].save(
        WEBSITE_ASSETS_DIR / "number_bond_usage.gif",
        save_all=True, append_images=frames_bond[1:], duration=1600, loop=0
    )

    # -------------------------------------------------------------------------
    # H. NUMBER RACK USAGE ANIMATION (Doubles: 6 ENTER + = 12)
    # -------------------------------------------------------------------------
    steps_rack = [
        {"title": "Initial State", "sub": "6 beads pushed left on top row (5 red, 1 white)", "keys": [], "disp": "0", "desc": "Top row has 6 beads pushed to counting side. Bottom row has 6 beads ready."},
        {"title": "Step 1: Enter 6", "sub": "Top row quantity enters register X", "keys": ["6"], "disp": "6", "desc": "6 entered in X."},
        {"title": "Step 2: Press ENTER", "sub": "ENTER duplicates 6 into Y (represents both rows)", "keys": ["enter"], "disp": "6", "desc": "ENTER creates an exact twin in Y! Both rows now on stack."},
        {"title": "Step 3: Press PLUS (+)", "sub": "6 + 6 = 12: Instant Double!", "keys": ["plus"], "disp": "12", "desc": "Plus combines both rows: 6 + 6 = 12! Perfect double."}
    ]

    frames_rack = []
    for step in steps_rack:
        frame = Image.new("RGB", (w_anim, h_anim), COLOR_BG)
        draw = ImageDraw.Draw(frame)

        draw.text((36, 20), "NUMBER RACK STAGE USAGE  //  REKENREK DOUBLES", font=f_sub, fill=COLOR_TEAL)
        draw.text((36, 44), step["title"], font=f_title, fill=COLOR_TEXT)
        draw.text((36, 76), step["sub"], font=f_sub, fill=COLOR_TEAL)
        draw.line([(36, 98), (w_anim - 36, 98)], fill=COLOR_GOLD, width=3)

        # Left Column: Number Rack Graphic
        tray_x, tray_y, tray_w, tray_h = 36, 120, 390, 360
        draw.rounded_rectangle([tray_x, tray_y, tray_x + tray_w, tray_y + tray_h], radius=12, fill=(235, 232, 224), outline=COLOR_MUTED, width=2)
        draw.text((tray_x + 16, tray_y + 14), "NUMBER RACK (4x2 GRIDFINITY)", font=f_sub, fill=COLOR_TEAL)

        # Dual channels
        for row_i, ry in enumerate([tray_y + 80, tray_y + 200]):
            draw.rounded_rectangle([tray_x + 25, ry, tray_x + 365, ry + 70], radius=8, fill=(245, 243, 238), outline=COLOR_MUTED, width=1)
            draw.text((tray_x + 35, ry + 6), f"Row {row_i + 1}", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 11), fill=COLOR_TEAL)
            # 6 pushed beads left
            for b in range(5):
                draw.ellipse([tray_x + 40 + b * 22, ry + 24, tray_x + 58 + b * 22, ry + 56], fill=(215, 60, 50), outline=(20, 20, 20), width=1)
            draw.ellipse([tray_x + 40 + 5 * 22, ry + 24, tray_x + 58 + 5 * 22, ry + 56], fill=(255, 255, 255), outline=(20, 20, 20), width=1)
            # Remaining 4 unpushed beads right
            for b in range(4):
                draw.ellipse([tray_x + 260 + b * 22, ry + 24, tray_x + 278 + b * 22, ry + 56], fill=(240, 240, 240), outline=(160, 160, 160), width=1)

        # Right Column
        right_x = 450
        draw.rounded_rectangle([right_x, tray_y, right_x + 414, tray_y + 140], radius=10, fill=COLOR_CARD, outline=COLOR_MUTED, width=1)
        draw.text((right_x + 20, tray_y + 14), "CALCULATOR DISPLAY (REGISTER X)", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, tray_y + 44), f"Screen: {step['disp']}", font=ImageFont.truetype(str(SPACE_MONO_BOLD), 36), fill=COLOR_TEXT)

        k_x = right_x + 20
        for k in step["keys"]:
            kw = draw_keycap_on(draw, frame, k, k_x, tray_y + 90, h=38)
            k_x += kw + 10

        exp_y = tray_y + 160
        draw.rounded_rectangle([right_x, exp_y, right_x + 414, tray_y + tray_h], radius=10, fill=(230, 240, 237), outline=COLOR_TEAL, width=2)
        draw.text((right_x + 20, exp_y + 16), "MATHEMATICAL EXPLANATION", font=f_sub, fill=COLOR_TEAL)
        draw.text((right_x + 20, exp_y + 50), step["desc"], font=f_desc, fill=COLOR_TEXT)

        frames_rack.append(frame)

    frames_rack[0].save(
        PREVIEW_DIR / "number_rack_usage.gif",
        save_all=True, append_images=frames_rack[1:], duration=1600, loop=0
    )
    frames_rack[0].save(
        WEBSITE_ASSETS_DIR / "number_rack_usage.gif",
        save_all=True, append_images=frames_rack[1:], duration=1600, loop=0
    )

    print("Successfully generated all assembly renders and animated usage GIFs!")


if __name__ == "__main__":
    ensure_dirs()
    generate_assembly_images()
    generate_usage_animations()

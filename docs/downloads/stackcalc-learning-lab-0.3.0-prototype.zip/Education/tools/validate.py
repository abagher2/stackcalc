"""Fail the build on missing files, broken meshes, or output drift.

Revision 0.3.0:
- Validates 14 watertight STL plates with inset debossed text and Gridfinity geometry
- Validates thresholded Hardware Trapezoid keycap PNGs
- Validates multi-page curriculum guides and reference sheets
"""
import hashlib
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np
import trimesh
from pypdf import PdfReader

from catalog import catalog, REVISION, laser_setups
from keycaps import KEYCAPS_DIR, sanitize_filename


def validate(stl_dir):
    checks = []
    # 1. Validate keycaps
    required_keys = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "ENTER", "+", "-", "times", "divide", "sqrt_x"]
    for k in required_keys:
        fname = sanitize_filename(k) + ".png"
        kpath = KEYCAPS_DIR / fname
        assert kpath.exists() and kpath.stat().st_size > 500, f"Missing or empty keycap: {kpath}"

    # 2. Validate parts and STL meshes
    for p in catalog():
        operations = ("cut", "pocket-guide") + (("engrave",) if len(laser_setups(p)) <= 1 else ())
        for operation in operations:
            path = Path(f"build/svg/{p.id}-{operation}.svg")
            root = ET.parse(path).getroot()
            assert root.get("width") == f"{p.width}mm", path
            assert root.get("height") == f"{p.height}mm", path
            assert not root.findall(".//{http://www.w3.org/2000/svg}text"), f"Live font dependency: {path}"

        for setup in laser_setups(p):
            path = Path("build") / setup["file"]
            root = ET.parse(path).getroot()
            assert root.get("viewBox") == f"0 0 {p.width} {p.height}", path

        log_path = Path(f"build/logs/{p.id}.log")
        if log_path.exists():
            log = log_path.read_text()
            assert not any(s in log for s in ["ERROR:"]), f"OpenSCAD compile error in {p.id}: {log}"

        path = stl_dir / f"{p.id}.stl"
        assert path.exists(), f"Missing STL: {path}"
        mesh = trimesh.load_mesh(path)
        assert mesh.is_watertight, f"Mesh not watertight: {p.id}"
        assert mesh.is_winding_consistent, f"Mesh winding inconsistent: {p.id}"
        assert mesh.volume > 0, f"Mesh volume zero or negative: {p.id}"

        components = mesh.split(only_watertight=False)
        assert len(components) == len(p.bodies), f"{p.id}: found {len(components)} components, expected {len(p.bodies)}"
        assert all(c.is_watertight and c.volume > 0 for c in components), f"Component not watertight in {p.id}"

        bounds = mesh.bounds
        # Allow negative Z for underside Gridfinity plugs (-3.0 mm)
        min_z = -3.05 if (p.gridfinity_x > 0 and not p.is_baseplate) else -0.01
        assert bounds[0, 2] >= min_z, f"Z min bounds violation in {p.id}: {bounds[0, 2]} < {min_z}"
        assert bounds[0, 0] >= -0.05 and bounds[0, 1] >= -0.05, f"XY min bounds violation in {p.id}: {bounds[0]}"
        assert bounds[1, 0] <= p.width + 0.05 and bounds[1, 1] <= p.height + 0.05, f"XY max bounds violation in {p.id}: {bounds[1]}"

        if p.id == "fraction_blocks":
            expected_max_z = p.thickness + 8 * 0.4
        elif p.is_fraction_bin:
            expected_max_z = p.thickness + 4.4
        elif any("height_divisor" in s for s in p.bodies):
            expected_body_z = max(p.thickness / s.get("height_divisor", 1) for s in p.bodies)
            expected_max_z = expected_body_z + (max(b["height"] for b in p.bosses) if p.bosses else 0)
        else:
            expected_max_z = p.thickness + (max(b["height"] for b in p.bosses) if p.bosses else 0)
        assert abs(bounds[1, 2] - expected_max_z) < 0.05, f"Z max bounds violation in {p.id}: {bounds[1, 2]} != {expected_max_z}"

        checks.append(dict(
            part=p.id,
            watertight=True,
            components=len(components),
            triangles=len(mesh.faces),
            bounds_mm=np.round(bounds, 4).tolist(),
            volume_mm3=round(mesh.volume, 2),
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()
        ))

    # 3. Validate PDFs
    pdf_checks = []
    for paper, size in [("letter", (612, 792)), ("a4", (595.2756, 841.8898))]:
        for kind, min_count in [("reference-cards", 1), ("teacher-curriculum-guide", 40), ("teacher-booklet", 40), ("student-proficiency-trials", 18)]:
            path = Path(f"output/pdf/{kind}-{paper}.pdf")
            assert path.exists(), f"Missing PDF: {path}"
            pdf = PdfReader(path)
            assert len(pdf.pages) >= min_count, f"PDF page count low for {path}: {len(pdf.pages)} < {min_count}"
            for page in pdf.pages:
                assert abs(float(page.mediabox.width) - size[0]) < 0.01, path
                assert abs(float(page.mediabox.height) - size[1]) < 0.01, path
                assert len(page.extract_text()) > 100, f"Insufficient text in {path}"
            pdf_checks.append(dict(file=str(path), pages=len(pdf.pages)))

    report = dict(
        version=REVISION,
        mesh_checks=checks,
        pdf_checks=pdf_checks,
        limits=[
            "FDM print verification is done with fit_coupon.stl",
            "Debossed text depth is 0.6 mm (3 layers at 0.20 mm)",
            "Gridfinity standard 42.0 mm unit pitch with 0.5 mm tolerance",
            "Teacher guide cross-references Singapore Dimensions Math, Big Ideas Math, and Bridges in Math",
            "Student proficiency trials provide timed UIL-style competition rounds"
        ]
    )
    Path("build/validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"PASS: {len(checks)} watertight STL plates with inset text, {len(pdf_checks)} PDFs verified.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--stl-dir", type=Path, default=Path("../scratch/stl/education"))
    validate(parser.parse_args().stl_dir)

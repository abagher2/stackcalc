"""Comprehensive Curricula Database for StackCalc Learning Lab.

Grades Pre-K to Grade 12+ Progression (Full Educational Span):
1.  Unit 1: Counting, Cardinality & The Step Counter (Pre-K - Kindergarten)
2.  Unit 2: Number Bonds: Part-Part-Whole & The RPN Stack (Grades K-1)
3.  Unit 3: Ten-Frames & Complements to 10 (Grade 1)
4.  Unit 4: Number Racks (Rekenrek), 5-Structure & Doubles (Grades 1-2)
5.  Unit 5: The 4-Register Stack: Four Operations & Automatic Lift (Grades 3-4)
6.  Unit 6: Fraction Studio: Equivalence & Two-Dot Notation (Grades 4-5)
7.  Unit 7: Expression Trees: Postorder Parenthesis-Free Traversal (Grades 5-6)
8.  Unit 8: Coordinate Lab: Pythagorean Distance Pipeline (Grades 7-8)
9.  Unit 9: Trigonometry, Vectors & Polar Coordinates (Grades 9-11)
10. Unit 10: Exponential Growth, Compound Interest & Logarithms (Grades 10-12)
11. Unit 11: Combinatorics, Probability & Series Accumulation (Grades 11-12 / AP)
12. Unit 12: Digital Logic, Base Conversions & Computer Architecture (Grades 9-12 / AP CS)

Every Unit includes:
- Primary Core Lesson Plan
- Follow-Up Extension Lesson Plan
- Student Practice Sheet (4 problems)
- Student Quick Reference Guide & Keystroke Rules
"""
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Optional


@dataclass
class LessonPlan:
    lesson_type: str  # "Primary Core" or "Follow-Up Extension"
    curriculum: str
    grade_unit: str
    chapter: str
    title: str
    standard: str
    manipulative: str
    objective: str
    key_tokens: List[str]
    manipulative_setup: str
    prediction_step: str
    calculator_flow: List[Tuple[str, str, str]]  # (Key, Display X, Stack Description)
    explanation: str
    worksheet_problem: str
    worksheet_expected_keys: List[str]
    worksheet_answer: str


@dataclass
class CurriculumUnit:
    unit_id: str
    unit_number: int
    title: str
    grades: str
    curricula_tags: List[str]
    standards: List[str]
    manipulative: str
    student_guide_title: str
    student_guide_rules: List[str]
    calculator_shortcut: str
    primary_lesson: LessonPlan
    followup_lesson: LessonPlan
    practice_problems: List[Dict[str, str]]


CURRICULUM_UNITS: List[CurriculumUnit] = [
    # =========================================================================
    # UNIT 1: COUNTING, CARDINALITY & STEP COUNTER (PRE-K - KINDERGARTEN)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_1_counting_counter",
        unit_number=1,
        title="Counting, Cardinality & The One-More Step Counter",
        grades="Pre-K – Kindergarten",
        curricula_tags=["Bridges in Mathematics (Kindergarten Unit 1)", "Singapore Math (Earlybird Kindergarten)"],
        standards=["CCSS.MATH.K.CC.A.1", "CCSS.MATH.K.CC.B.4", "CCSS.MATH.K.CC.B.5", "CCSS.MATH.K.OA.A.1"],
        manipulative="Ten-Frame Stage (4x2 Gridfinity) + Numeral Tiles / Pegs",
        student_guide_title="How Counting Maps to the Calculator",
        student_guide_rules=[
            "Every peg placed on the frame matches one count on the calculator screen.",
            "An empty ten-frame represents zero [0]. Press [C] to start a fresh count.",
            "To step count by 1: press [1] [ENTER] [1] [+], then press [1] [+] to see the count advance!",
            "Numbers show quantity (cardinality): the last number said is the total number of pegs."
        ],
        calculator_shortcut="[1] [ENTER] [1] [+] = 2, then [1] [+] = 3, [1] [+] = 4...",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Bridges in Mathematics",
            grade_unit="Kindergarten, Unit 1",
            chapter="Numbers to 5 & 10",
            title="1-to-1 Correspondence: The Concrete Step Counter",
            standard="CCSS.MATH.K.CC.B.4",
            manipulative="Ten-Frame Stage (4x2 Gridfinity)",
            objective="Establish one-to-one correspondence between physical pegs on the frame and calculator screen increments.",
            key_tokens=["1", "enter", "1", "plus", "1", "plus"],
            manipulative_setup="Place 1 peg into the first well of the Ten-Frame. Have students observe the single object.",
            prediction_step="When we place 1 more peg into the next well, how many pegs will be on our frame? (Prediction: 2)",
            calculator_flow=[
                ("1", "1", "First peg placed: 1 enters register X"),
                ("enter", "1", "1 copied to register Y: holds the current count"),
                ("1", "1", "Second peg placed: 1 enters register X"),
                ("plus", "2", "Press [+]: 1 + 1 = 2! Screen verifies 2 pegs on board"),
                ("1", "1", "Third peg placed in frame: 1 enters X"),
                ("plus", "3", "Press [+]: 2 + 1 = 3! Frame and screen match perfectly"),
            ],
            explanation="Each physical counter corresponds to a single increment. The calculator's stack preserves the running count in Y while new items enter X.",
            worksheet_problem="Place 4 pegs on your Ten-Frame. Add 1 more peg. Write the keystrokes to show 4 + 1 on the calculator.",
            worksheet_expected_keys=["4", "enter", "1", "plus"],
            worksheet_answer="5 pegs. Keystrokes: [4] [ENTER] [1] [+]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Singapore Math",
            grade_unit="Kindergarten, Book A",
            chapter="Comparing Sets & Magnitude",
            title="More, Less & Zero: Finding Differences",
            standard="CCSS.MATH.K.CC.C.6",
            manipulative="Ten-Frame Stage (4x2 Gridfinity)",
            objective="Compare two groups of physical counters and find the difference using subtraction.",
            key_tokens=["5", "enter", "2", "minus"],
            manipulative_setup="Place 5 pegs in the top row (Row 1) and 2 pegs in the bottom row (Row 2).",
            prediction_step="Look at the two rows. Which row has more? How many more pegs are in Row 1 than Row 2?",
            calculator_flow=[
                ("5", "5", "Row 1 quantity (5) enters register X"),
                ("enter", "5", "5 lifted to register Y (first set)"),
                ("2", "2", "Row 2 quantity (2) enters register X"),
                ("minus", "3", "Minus subtracts X from Y: Row 1 has 3 more pegs!"),
            ],
            explanation="Comparison subtraction answers 'how many more?'. Register Y holds the larger group and register X holds the smaller group.",
            worksheet_problem="Row 1 has 6 pegs and Row 2 has 2 pegs. How many more pegs in Row 1? Write the keystrokes.",
            worksheet_expected_keys=["6", "enter", "2", "minus"],
            worksheet_answer="4 more pegs. Keystrokes: [6] [ENTER] [2] [-]",
        ),
        practice_problems=[
            {"prompt": "Place 3 pegs on your frame. Add 2 more. Write the keystrokes to find the total.", "keys": "[3] [ENTER] [2] [+]", "ans": "5"},
            {"prompt": "A frame has 5 pegs. If you remove 2 pegs, how many remain?", "keys": "[5] [ENTER] [2] [-]", "ans": "3"},
            {"prompt": "Clear the calculator by pressing [C]. What number represents an empty ten-frame?", "keys": "[0] or [C]", "ans": "0 (Zero)"},
            {"prompt": "Step count by ones starting at 1: [1] [ENTER] [1] [+]. Press [1] [+] two more times. What is X?", "keys": "[1] [+] [1] [+]", "ans": "4"},
        ]
    ),

    # =========================================================================
    # UNIT 2: NUMBER BONDS (GRADES K - 1)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_2_number_bonds",
        unit_number=2,
        title="Number Bonds: Part-Part-Whole & The RPN Stack",
        grades="Grades K–1",
        curricula_tags=["Singapore Math (Primary 1 Chapter 2)", "Bridges in Math (K-1)"],
        standards=["CCSS.MATH.K.OA.A.3", "CCSS.MATH.1.OA.C.6"],
        manipulative="Number Bond Stage (Gridfinity 3x2)",
        student_guide_title="How Number Bonds Fit the Stack",
        student_guide_rules=[
            "Part 1 lives in register Y. Part 2 enters register X.",
            "Pressing [+] combines both parts into the Whole in register X.",
            "To find a missing part: start with Whole in Y, enter Part 1 in X, and press [-]!"
        ],
        calculator_shortcut="[PART 1] [ENTER] [PART 2] [+] = [WHOLE]",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Singapore Math",
            grade_unit="Grade 1, Chapter 2",
            chapter="Number Bonds to 10",
            title="Composing Numbers: Part + Part = Whole",
            standard="CCSS.MATH.1.OA.C.6",
            manipulative="Number Bond Stage (3x2 Gridfinity)",
            objective="Physically compose parts into a whole and connect to RPN binary addition.",
            key_tokens=["4", "enter", "3", "plus"],
            manipulative_setup="Place 4 counters in the Part 1 well (bottom-left) and 3 counters in the Part 2 well (bottom-right).",
            prediction_step="Slide both sets of counters up the channels into the Whole well. Count the combined total: 4 + 3 = 7.",
            calculator_flow=[
                ("4", "4", "Part 1 (4) enters register X"),
                ("enter", "4", "4 copied up to register Y; represents Part 1"),
                ("3", "3", "Part 2 (3) enters register X"),
                ("plus", "7", "Plus combines Part 1 (Y) + Part 2 (X) = Whole (7) in X!"),
            ],
            explanation="The RPN stack has dedicated registers for parts: register Y holds Part 1, register X holds Part 2, and [+] merges them into the Whole.",
            worksheet_problem="There are 5 red apples and 4 green apples. Use the Number Bond stage to find the whole. Write the keystrokes.",
            worksheet_expected_keys=["5", "enter", "4", "plus"],
            worksheet_answer="9 apples. Keystrokes: [5] [ENTER] [4] [+]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Bridges in Mathematics",
            grade_unit="Grade 1, Unit 2",
            chapter="Developing Number Sense",
            title="Decomposing the Whole: Finding the Missing Part",
            standard="CCSS.MATH.1.OA.B.4",
            manipulative="Number Bond Stage (3x2 Gridfinity)",
            objective="Determine an unknown addend using inverse operations on the RPN stack.",
            key_tokens=["1", "0", "enter", "6", "minus"],
            manipulative_setup="Place 10 counters in the top Whole well. Move 6 counters down the left channel into Part 1.",
            prediction_step="How many counters must move down the right channel into Part 2 so no counters remain in the Whole? (10 - 6 = 4).",
            calculator_flow=[
                ("1", "1", "Enter Whole (10)"),
                ("0", "10", "10 in register X"),
                ("enter", "10", "Whole (10) lifted to register Y"),
                ("6", "6", "Known Part 1 (6) enters register X"),
                ("minus", "4", "Minus subtracts known Part from Whole: Missing Part is 4!"),
            ],
            explanation="Finding a missing addend is inverse addition. Placing the Whole in Y and subtracting known Part in X yields the missing part in X.",
            worksheet_problem="The whole is 8. Part 1 is 5. Find the missing Part 2 using the calculator.",
            worksheet_expected_keys=["8", "enter", "5", "minus"],
            worksheet_answer="Missing Part is 3. Keystrokes: [8] [ENTER] [5] [-]",
        ),
        practice_problems=[
            {"prompt": "Make 6: Part 1 is 2. What is Part 2? Write the keystrokes.", "keys": "[6] [ENTER] [2] [-]", "ans": "4"},
            {"prompt": "Part 1 is 7, Part 2 is 2. What is the Whole?", "keys": "[7] [ENTER] [2] [+]", "ans": "9"},
            {"prompt": "Three parts make a whole: 2, 3, and 4. Add them on the stack.", "keys": "[2] [ENTER] [3] [+] [4] [+]", "ans": "9"},
            {"prompt": "The Whole is 10. Part 1 is 7. What is Part 2?", "keys": "[1][0] [ENTER] [7] [-]", "ans": "3"},
        ]
    ),

    # =========================================================================
    # UNIT 3: TEN-FRAMES & COMPLEMENTS TO 10 (GRADE 1)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_3_ten_frames",
        unit_number=3,
        title="Ten-Frames: Complements to 10 & 5-Structure",
        grades="Grade 1",
        curricula_tags=["Singapore Math (Primary 1 Ch 8)", "Bridges in Math (Grade 1)", "Big Ideas Math (Grade 1)"],
        standards=["CCSS.MATH.1.OA.B.4", "CCSS.MATH.1.OA.C.6", "CCSS.MATH.1.NBT.B.2"],
        manipulative="Ten-Frame Stage (Gridfinity 4x2)",
        student_guide_title="Ten-Frame 5-Structure Rules",
        student_guide_rules=[
            "The top row holds exactly 5 counters. The divider marks the 5-split.",
            "Subitizing: 7 is seen immediately as 5 on top plus 2 on bottom.",
            "Complements to 10: To find the empty wells, enter 10 [ENTER], then the number, then [-]."
        ],
        calculator_shortcut="10 [ENTER] [N] [-] = [COMPLEMENT TO 10]",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Big Ideas Math",
            grade_unit="Grade 1, Chapter 3",
            chapter="Addition Strategies to 10",
            title="Complements to 10: Making Ten",
            standard="CCSS.MATH.1.OA.C.6",
            manipulative="Ten-Frame Stage (4x2 Gridfinity)",
            objective="Quickly determine complements to 10 using physical 2x5 array subitizing and RPN subtraction.",
            key_tokens=["1", "0", "enter", "7", "minus"],
            manipulative_setup="Place 7 counters on the Ten-Frame: fill the entire top row of 5, then place 2 in the bottom row.",
            prediction_step="Look at the empty wells without counting one-by-one. 3 empty spaces mean 7 + 3 = 10.",
            calculator_flow=[
                ("1", "1", "Enter 1"),
                ("0", "10", "Full frame capacity (10) in X"),
                ("enter", "10", "10 lifted to Y"),
                ("7", "7", "Occupied counters (7) in X"),
                ("minus", "3", "10 - 7 = 3: Exactly 3 empty wells to make 10!"),
            ],
            explanation="The ten-frame physically structures 10 as two groups of 5. Subtraction verifies the visual complement.",
            worksheet_problem="A ten-frame has 6 counters. How many more counters are needed to make 10?",
            worksheet_expected_keys=["1", "0", "enter", "6", "minus"],
            worksheet_answer="4 counters. Keystrokes: [1][0] [ENTER] [6] [-]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Singapore Math",
            grade_unit="Grade 1, Chapter 8",
            chapter="Addition Within 20",
            title="Bridging Through 10: The Make-Ten Strategy",
            standard="CCSS.MATH.1.OA.C.6",
            manipulative="Ten-Frame Stage (4x2 Gridfinity)",
            objective="Decompose an addend to make a complete 10, then add the remainder.",
            key_tokens=["8", "enter", "2", "plus", "3", "plus"],
            manipulative_setup="Place 8 counters on Ten-Frame 1. Prepare 5 counters beside the board.",
            prediction_step="Take 2 from the 5 to fill Ten-Frame 1 to 10. How many are left? 3 counters. 10 + 3 = 13.",
            calculator_flow=[
                ("8", "8", "8 counters on frame"),
                ("enter", "8", "8 lifted to Y"),
                ("2", "2", "2 counters borrowed to make 10"),
                ("plus", "10", "8 + 2 = 10 (first full frame)"),
                ("3", "3", "Remaining 3 counters"),
                ("plus", "13", "10 + 3 = 13 total!"),
            ],
            explanation="Bridging decomposes 8 + 5 into (8 + 2) + 3. On RPN, intermediate sums remain in the accumulator register.",
            worksheet_problem="Use the Make-Ten strategy to solve 9 + 6 on your calculator.",
            worksheet_expected_keys=["9", "enter", "1", "plus", "5", "plus"],
            worksheet_answer="15. Keystrokes: [9] [ENTER] [1] [+] [5] [+]",
        ),
        practice_problems=[
            {"prompt": "What is the complement to 10 for 4? Write the keystrokes.", "keys": "[1][0] [ENTER] [4] [-]", "ans": "6"},
            {"prompt": "Solve 7 + 5 using Make-Ten: first make 10, then add 2.", "keys": "[7] [ENTER] [3] [+] [2] [+]", "ans": "12"},
            {"prompt": "A ten-frame has 9 counters. How many to make 10?", "keys": "[1][0] [ENTER] [9] [-]", "ans": "1"},
            {"prompt": "Solve 8 + 6 using Make-Ten on the calculator.", "keys": "[8] [ENTER] [2] [+] [4] [+]", "ans": "14"},
        ]
    ),

    # =========================================================================
    # UNIT 4: NUMBER RACKS / REKENREK (GRADES 1 - 2)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_4_number_racks",
        unit_number=4,
        title="Number Racks (Rekenrek): 5-Structure & Doubles",
        grades="Grades 1–2",
        curricula_tags=["Bridges in Math (Grade 1-2)", "Singapore Math (Primary 1-2)"],
        standards=["CCSS.MATH.1.OA.C.6", "CCSS.MATH.2.OA.B.2"],
        manipulative="Number Rack Stage (Gridfinity 4x2)",
        student_guide_title="Number Rack & ENTER Duplicate Rules",
        student_guide_rules=[
            "Each row has 5 red beads and 5 white beads.",
            "Pushing beads to the left counts them. 5 red + 5 white = 10 per row.",
            "Doubles shortcut: Enter a number, press [ENTER] to duplicate, then press [+]!"
        ],
        calculator_shortcut="[N] [ENTER] [+] = [DOUBLES (2 * N)]",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Bridges in Mathematics",
            grade_unit="Grade 1, Unit 3",
            chapter="Number Racks & Fact Strategies",
            title="Doubles Strategy: The ENTER Duplicate Key",
            standard="CCSS.MATH.1.OA.C.6",
            manipulative="Number Rack Stage (4x2 Gridfinity)",
            objective="Model doubles physically using dual bead rows and computationally using ENTER duplication.",
            key_tokens=["6", "enter", "plus"],
            manipulative_setup="Push 6 beads on the top row (5 red, 1 white). Push 6 beads on the bottom row.",
            prediction_step="Observe the matching rows. 6 + 6 = (5 + 5) + (1 + 1) = 10 + 2 = 12.",
            calculator_flow=[
                ("6", "6", "Top row quantity (6) enters register X"),
                ("enter", "6", "ENTER duplicates 6 into register Y! Both rows now on stack"),
                ("plus", "12", "Plus combines top and bottom rows: 6 + 6 = 12!"),
            ],
            explanation="ENTER creates an instant identical copy of register X in register Y. This perfectly represents a physical double.",
            worksheet_problem="Push 7 beads on each row of the Number Rack. Use [ENTER] [+] to double it on the calculator.",
            worksheet_expected_keys=["7", "enter", "plus"],
            worksheet_answer="14 beads. Keystrokes: [7] [ENTER] [+]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Bridges in Mathematics",
            grade_unit="Grade 2, Unit 1",
            chapter="Fact Fluency & Near Doubles",
            title="Near-Doubles: Doubles Plus One",
            standard="CCSS.MATH.2.OA.B.2",
            manipulative="Number Rack Stage (4x2 Gridfinity)",
            objective="Use known doubles facts to solve near-doubles on the physical rack and calculator.",
            key_tokens=["7", "enter", "plus", "1", "plus"],
            manipulative_setup="Push 7 beads on top row (5 red, 2 white). Push 8 beads on bottom row (5 red, 3 white).",
            prediction_step="7 and 8 is double 7 plus 1 more: 14 + 1 = 15.",
            calculator_flow=[
                ("7", "7", "Enter base number 7"),
                ("enter", "7", "Duplicate 7"),
                ("plus", "14", "Double: 7 + 7 = 14"),
                ("1", "1", "Near-double difference (1)"),
                ("plus", "15", "14 + 1 = 15!"),
            ],
            explanation="Near-doubles build upon doubles fluency. The calculator executes the base double, then accumulates the offset.",
            worksheet_problem="Use the near-doubles strategy to solve 6 + 7 on the calculator.",
            worksheet_expected_keys=["6", "enter", "plus", "1", "plus"],
            worksheet_answer="13. Keystrokes: [6] [ENTER] [+] [1] [+]",
        ),
        practice_problems=[
            {"prompt": "Calculate double 8 using [ENTER] [+].", "keys": "[8] [ENTER] [+]", "ans": "16"},
            {"prompt": "Solve near-double 8 + 9: double 8 then add 1.", "keys": "[8] [ENTER] [+] [1] [+]", "ans": "17"},
            {"prompt": "Calculate double 9 using [ENTER] [+].", "keys": "[9] [ENTER] [+]", "ans": "18"},
            {"prompt": "Solve 5 + 6 using doubles plus one.", "keys": "[5] [ENTER] [+] [1] [+]", "ans": "11"},
        ]
    ),

    # =========================================================================
    # UNIT 5: 4-REGISTER STACK & FOUR OPERATIONS (GRADES 3 - 4)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_5_stack_stage",
        unit_number=5,
        title="The 4-Register Stack: Four Operations & Automatic Lift",
        grades="Grades 3–4",
        curricula_tags=["Singapore Math (Primary 4)", "Big Ideas Math (Grade 4)"],
        standards=["CCSS.MATH.3.OA.A.1", "CCSS.MATH.3.OA.A.2", "CCSS.MATH.4.OA.A.3"],
        manipulative="Stack Stage (Gridfinity 3x3) + Value Tiles",
        student_guide_title="4-Register Stack Anatomy",
        student_guide_rules=[
            "Four registers: T (top), Z (third), Y (second/operand), X (screen/bottom).",
            "ENTER duplicates X into Y and pushes older values up into Z and T.",
            "Two-number operators (+, -, *, /) combine Y and X, dropping Z to Y and T to Z.",
            "Automatic Lift: Entering a new number after an operation automatically pushes the result to Y!"
        ],
        calculator_shortcut="[Y] [ENTER] [X] [OP] -> Drops stack and displays result in X",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Singapore Math",
            grade_unit="Primary 4, Chapter 3",
            chapter="Multi-Step Word Problems",
            title="Multi-Step Word Problems Without Parentheses",
            standard="CCSS.MATH.4.OA.A.3",
            manipulative="Stack Stage (3x3 Gridfinity)",
            objective="Evaluate chained arithmetic expressions without parentheses by managing stack register flow.",
            key_tokens=["8", "enter", "3", "minus", "2", "times"],
            manipulative_setup="Place value tile '8' in register X. Prepare tiles '3' and '2'.",
            prediction_step="Problem: (8 - 3) * 2. Predict: 8 - 3 = 5, then 5 * 2 = 10.",
            calculator_flow=[
                ("8", "8", "8 in X"),
                ("enter", "8", "8 copied to Y"),
                ("3", "3", "3 entered into X"),
                ("minus", "5", "8 - 3 = 5 in X"),
                ("2", "2", "Automatic lift! 5 lifts to Y; 2 enters X"),
                ("times", "10", "5 * 2 = 10 in X!"),
            ],
            explanation="Unlike traditional algebraic calculators that require parenthesis keys, RPN evaluates inner expressions first, lifting results naturally.",
            worksheet_problem="A baker has 15 cookies, sells 6, and packs the rest into 3 bags. How many per bag? Keystrokes for (15 - 6) / 3.",
            worksheet_expected_keys=["1", "5", "enter", "6", "minus", "3", "divide"],
            worksheet_answer="3 cookies per bag. Keystrokes: [1][5] [ENTER] [6] [-] [3] [÷]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Big Ideas Math",
            grade_unit="Grade 4, Chapter 2",
            chapter="Order of Operations & Stack Lift",
            title="Automatic Stack Lift & Register Retention",
            standard="CCSS.MATH.4.OA.A.3",
            manipulative="Stack Stage (3x3 Gridfinity)",
            objective="Demonstrate that the result of an operation acts as operand Y for the subsequent number entry.",
            key_tokens=["1", "2", "enter", "4", "divide", "7", "plus"],
            manipulative_setup="Move tiles down the stack stage as operations execute: (12 / 4) + 7.",
            prediction_step="12 / 4 = 3. Entering 7 will lift 3 to Y. 3 + 7 = 10.",
            calculator_flow=[
                ("12", "12", "12 entered in X"),
                ("enter", "12", "12 copied to Y"),
                ("4", "4", "4 enters X"),
                ("divide", "3", "12 / 4 = 3 in X"),
                ("7", "7", "7 entered: 3 lifts to Y automatically!"),
                ("plus", "10", "3 + 7 = 10!"),
            ],
            explanation="Automatic lift prevents unnecessary ENTER presses between sequential chained operations.",
            worksheet_problem="Calculate (24 / 6) + 15 on the calculator without pressing ENTER twice.",
            worksheet_expected_keys=["2", "4", "enter", "6", "divide", "1", "5", "plus"],
            worksheet_answer="19. Keystrokes: [2][4] [ENTER] [6] [÷] [1][5] [+]",
        ),
        practice_problems=[
            {"prompt": "Calculate (14 - 5) * 3 on the stack.", "keys": "[1][4] [ENTER] [5] [-] [3] [×]", "ans": "27"},
            {"prompt": "Calculate 30 / (2 + 3): add denominator first!", "keys": "[2] [ENTER] [3] [+] [3][0] [x⇄y] [÷] or [3][0] [ENTER] [2] [ENTER] [3] [+] [÷]", "ans": "6"},
            {"prompt": "Calculate (9 + 7) / (8 - 4) using 4 registers.", "keys": "[9] [ENTER] [7] [+] [8] [ENTER] [4] [-] [÷]", "ans": "4"},
            {"prompt": "A farmer collects 20 eggs, breaks 2, and divides among 6 cartons.", "keys": "[2][0] [ENTER] [2] [-] [6] [÷]", "ans": "3 eggs"},
        ]
    ),

    # =========================================================================
    # UNIT 6: FRACTION STUDIO (GRADES 4 - 5)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_6_fraction_studio",
        unit_number=6,
        title="Fraction Studio: Height Equivalence & Two-Dot Notation",
        grades="Grades 4–5",
        curricula_tags=["Singapore Math (Primary 5)", "Bridges in Math (Grade 4-5)"],
        standards=["CCSS.MATH.4.NF.A.1", "CCSS.MATH.4.NF.B.3", "CCSS.MATH.5.NF.A.1"],
        manipulative="Fraction Studio (Gridfinity 3x3 Bin) + 45 Fraction Blocks (1 to 1/9)",
        student_guide_title="Two-Dot Fraction Entry & Tower Equivalence",
        student_guide_rules=[
            "All fraction blocks share a standard 1x1 Gridfinity footprint (41.5 x 41.5 mm). One Whole is exactly 84 mm tall (12U double-height bin).",
            "Fraction heights: 1/2 is 42 mm, 1/3 is 28 mm, 1/4 is 21 mm, 1/5 is 16.8 mm, 1/6 is 14 mm, 1/7 is 12 mm, 1/8 is 10.5 mm, 1/9 is 9.33 mm.",
            "All 9 fraction towers stack to exactly 84 mm, fitting seamlessly into the 3x3 Gridfinity bin. Multiple 12U bins stack on top of each other.",
            "Two-dot entry format: [WHOLE] [.] [NUMERATOR] [.] [DENOMINATOR].",
            "Proper fractions have 0 whole: enter [. 3 . 4] for 3/4."
        ],
        calculator_shortcut="[. 3 . 4] = 3/4   |   [2 . 1 . 2] = 2 1/2",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Singapore Math",
            grade_unit="Primary 5, Chapter 4",
            chapter="Fraction Addition & Mixed Numbers",
            title="Mixed Numbers & Height Equivalence: 3/4 + 2 1/2",
            standard="CCSS.MATH.5.NF.A.1",
            manipulative="Fraction Studio (3x3 Gridfinity Bin)",
            objective="Represent proper and mixed fractions physically with block towers and computationally with two-dot notation.",
            key_tokens=["dot", "3", "dot", "4", "enter", "2", "dot", "1", "dot", "2", "plus"],
            manipulative_setup="Place three 1/4 blocks (3 * 21 = 63 mm). Beside them, stack two Whole blocks and one 1/2 block (84 + 84 + 42 = 210 mm).",
            prediction_step="Combine heights: 63 mm + 210 mm = 273 mm. In wholes: 3 1/4 (273 / 84 = 3.25).",
            calculator_flow=[
                ("dot", "0.", "Leading dot indicates 0 wholes"),
                ("3", "0.3", "Numerator = 3"),
                ("dot", "0.3.", "Second dot sets fraction entry mode"),
                ("4", "3/4", "Denominator = 4: displays 3/4 (or 0.75)"),
                ("enter", "3/4", "3/4 lifted to register Y"),
                ("2", "2", "Whole = 2"),
                ("dot", "2.", "Dot"),
                ("1", "2.1", "Numerator = 1"),
                ("dot", "2.1.", "Dot"),
                ("2", "2 1/2", "Denominator = 2: displays 2 1/2"),
                ("plus", "3 1/4", "Plus combines: 3 1/4 (decimal 3.25)!"),
            ],
            explanation="Two dots eliminate ambiguity between decimals and fractions. Physical block heights provide an infallible self-check against the bin wall guides.",
            worksheet_problem="Build 1/2 and 1/4 with blocks. Enter .1.2 [ENTER] .1.4 [+] on the calculator.",
            worksheet_expected_keys=["dot", "1", "dot", "2", "enter", "dot", "1", "dot", "4", "plus"],
            worksheet_answer="3/4 (height 63 mm). Keystrokes: [.][1][.][2] [ENTER] [.][1][.][4] [+]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Bridges in Mathematics",
            grade_unit="Grade 5, Unit 2",
            chapter="Fraction Multiplication & Inverses",
            title="Fraction Multiplication & The Reciprocal Key [¹/𝑥]",
            standard="CCSS.MATH.5.NF.B.4",
            manipulative="Fraction Studio (3x3 Gridfinity Bin)",
            objective="Multiply fractions and verify division as multiplication by the reciprocal using [¹/𝑥].",
            key_tokens=["dot", "3", "dot", "4", "enter", "dot", "2", "dot", "3", "times"],
            manipulative_setup="Set up 3/4 of a tower and divide into 3 parts, taking 2 parts: (3/4) * (2/3).",
            prediction_step="3/4 * 2/3 = 6/12 = 1/2. The resulting block height should match exactly one 1/2 block (42 mm).",
            calculator_flow=[
                (".3.4", "3/4", "First fraction in Y"),
                ("enter", "3/4", "Lifted"),
                (".2.3", "2/3", "Second fraction in X"),
                ("times", "1/2", "Multiplication gives 1/2! Exactly matches 42 mm block"),
            ],
            explanation="Multiplying fractions scales the height. Dividing by 2/3 is identical to multiplying by its reciprocal 3/2 using [¹/𝑥].",
            worksheet_problem="Calculate 4/5 * 5/8 on the calculator. Predict whether the result is greater or less than 1/2.",
            worksheet_expected_keys=["dot", "4", "dot", "5", "enter", "dot", "5", "dot", "8", "times"],
            worksheet_answer="1/2. Keystrokes: [.][4][.][5] [ENTER] [.][5][.][8] [×]",
        ),
        practice_problems=[
            {"prompt": "Add 1/3 + 1/6 using two-dot notation.", "keys": "[.][1][.][3] [ENTER] [.][1][.][6] [+]", "ans": "1/2 (0.5)"},
            {"prompt": "Calculate 1 1/2 - 3/4. What block height corresponds to this?", "keys": "[1][.][1][.][2] [ENTER] [.][3][.][4] [-]", "ans": "3/4 (63 mm)"},
            {"prompt": "Enter 3/8 on the calculator. What is its decimal equivalent?", "keys": "[.][3][.][8]", "ans": "0.375"},
            {"prompt": "Multiply 2/3 * 3/4. Check against your fraction blocks.", "keys": "[.][2][.][3] [ENTER] [.][3][.][4] [×]", "ans": "1/2 (42 mm)"},
        ]
    ),

    # =========================================================================
    # UNIT 7: EXPRESSION TREES (GRADES 5 - 6)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_7_expression_trees",
        unit_number=7,
        title="Expression Trees: Postorder Parenthesis-Free Parsing",
        grades="Grades 5–6",
        curricula_tags=["Singapore Math (Dimensions 6)", "Bridges in Math (Grade 5)", "Big Ideas Math (Grade 6)"],
        standards=["CCSS.MATH.5.OA.A.1", "CCSS.MATH.6.EE.A.2"],
        manipulative="Expression Tree Stage (Gridfinity 4x3) + 7 Tree Tokens",
        student_guide_title="Syntax Tree Traversal Rules",
        student_guide_rules=[
            "Syntax trees represent expressions hierarchically. Leaves are numbers; branches are operators.",
            "Postorder traversal rule: Visit Left Subtree, visit Right Subtree, then visit Operator.",
            "RPN Keystroke sequence matches the postorder readout exactly!",
            "Zero parentheses are needed because tree structure guarantees unambiguous precedence."
        ],
        calculator_shortcut="Postorder Readout: Left -> Right -> Operator",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Big Ideas Math",
            grade_unit="Grade 6, Chapter 3",
            chapter="Algebraic Expressions & Properties",
            title="Tree Traversal: (a + b) * (c - d) in Postorder",
            standard="CCSS.MATH.6.EE.A.2",
            manipulative="Expression Tree (4x3 Gridfinity)",
            objective="Map an algebraic expression to a binary syntax tree and execute via postorder traversal without parentheses.",
            key_tokens=["6", "enter", "1", "plus", "9", "enter", "5", "minus", "times"],
            manipulative_setup="Place tokens into wells: 'a'=6, 'b'=1, '+' in node 3; 'c'=9, 'd'=5, '-' in node 6; '*' at root node 7.",
            prediction_step="Left branch: 6 + 1 = 7. Right branch: 9 - 5 = 4. Root: 7 * 4 = 28.",
            calculator_flow=[
                ("6", "6", "Leaf a (6) in X"),
                ("enter", "6", "6 lifted to Y"),
                ("1", "1", "Leaf b (1) in X"),
                ("plus", "7", "Left operator (+): 6 + 1 = 7 in X"),
                ("9", "9", "Leaf c (9) entered: 7 lifted to Y!"),
                ("enter", "9", "9 lifted to Z; 7 pushed to T"),
                ("5", "5", "Leaf d (5) in X"),
                ("minus", "4", "Right operator (-): 9 - 5 = 4 in X; 7 drops to Y"),
                ("times", "28", "Root operator (*): 7 * 4 = 28 in X!"),
            ],
            explanation="Parentheses exist in written algebra only to compensate for linear notation. In 2D tree space or RPN, precedence is intrinsic.",
            worksheet_problem="Construct the tree for (8 + 2) * (14 - 9). Perform postorder traversal to find the keystrokes.",
            worksheet_expected_keys=["8", "enter", "2", "plus", "1", "4", "enter", "9", "minus", "times"],
            worksheet_answer="50. Keystrokes: [8] [ENTER] [2] [+] [1][4] [ENTER] [9] [-] [×]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Singapore Math",
            grade_unit="Dimensions 6, Chapter 1",
            chapter="Order of Operations & Nested Trees",
            title="Deep Tree Balancing & Stack Depth Limits",
            standard="CCSS.MATH.6.EE.A.2",
            manipulative="Expression Tree (4x3 Gridfinity)",
            objective="Evaluate deeply nested expressions while keeping track of stack depth (T, Z, Y, X).",
            key_tokens=["1", "2", "enter", "4", "minus", "2", "enter", "1", "enter", "1", "plus", "times", "divide"],
            manipulative_setup="Set up the nested tree for (12 - 4) / (2 * (1 + 1)).",
            prediction_step="Numerator: 12 - 4 = 8. Denominator: 2 * 2 = 4. Result: 8 / 4 = 2.",
            calculator_flow=[
                ("12 ENTER 4 -", "8", "Numerator evaluated and held in stack"),
                ("2 ENTER", "2", "Denominator subterm"),
                ("1 ENTER 1 +", "2", "Innermost term: 1 + 1 = 2"),
                ("times", "4", "Denominator combined: 2 * 2 = 4"),
                ("divide", "2", "8 / 4 = 2!"),
            ],
            explanation="The 4-register stack can evaluate any binary expression tree up to depth 4 without spilling to storage registers.",
            worksheet_problem="Write the postorder RPN keystrokes for (15 - 5) / (3 + 2).",
            worksheet_expected_keys=["1", "5", "enter", "5", "minus", "3", "enter", "2", "plus", "divide"],
            worksheet_answer="2. Keystrokes: [1][5] [ENTER] [5] [-] [3] [ENTER] [2] [+] [÷]",
        ),
        practice_problems=[
            {"prompt": "Traverse the tree for (4 + 3) * (10 - 6). Write keystrokes.", "keys": "[4] [ENTER] [3] [+] [1][0] [ENTER] [6] [-] [×]", "ans": "28"},
            {"prompt": "Solve (20 - 4) / (2 * 4) using postorder sequence.", "keys": "[2][0] [ENTER] [4] [-] [2] [ENTER] [4] [×] [÷]", "ans": "2"},
            {"prompt": "Explain why (a + b) * c requires no parentheses in RPN.", "keys": "Operand order and operator placement specify the execution tree directly.", "ans": "a b + c *"},
            {"prompt": "Evaluate 5 + (3 * 4) on RPN. Which operation goes first?", "keys": "Multiply 3 and 4 first: [3] [ENTER] [4] [×] [5] [+]", "ans": "17"},
        ]
    ),

    # =========================================================================
    # UNIT 8: COORDINATE LAB & DISTANCE PIPELINE (GRADES 7 - 8)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_8_coordinate_lab",
        unit_number=8,
        title="Coordinate Lab: Pythagorean Distance Pipeline",
        grades="Grades 7–8",
        curricula_tags=["Big Ideas Math (Grade 8)", "Singapore Math (Dimensions 8)"],
        standards=["CCSS.MATH.8.G.B.7", "CCSS.MATH.8.G.B.8", "CCSS.MATH.8.EE.A.2"],
        manipulative="Coordinate Lab Stage (Gridfinity 4x4) + 4 Locator Pegs",
        student_guide_title="Cartesian Distance Pipeline Rules",
        student_guide_rules=[
            "The 10x10 pegboard covers coordinates (0,0) to (9,9) at 12 mm pitch.",
            "Horizontal Run Δx = |x2 - x1|; Vertical Rise Δy = |y2 - y1|.",
            "Pythagorean Theorem: Distance d = sqrt(Δx² + Δy²).",
            "Stack pipeline: calculate Δx², calculate Δy², add them [+], and press [√𝑥]!"
        ],
        calculator_shortcut="x1 [ENTER] x2 [-] [x²]   y1 [ENTER] y2 [-] [x²]   [+] [√𝑥]",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Big Ideas Math",
            grade_unit="Grade 8, Chapter 7",
            chapter="Real Numbers & The Pythagorean Theorem",
            title="The Distance Formula: A(1, 2) to B(4, 6)",
            standard="CCSS.MATH.8.G.B.8",
            manipulative="Coordinate Lab (4x4 Gridfinity)",
            objective="Measure coordinate offsets on a 2D grid and execute the Euclidean distance pipeline on the RPN stack.",
            key_tokens=["1", "enter", "4", "minus", "yellow_𝑥²", "2", "enter", "6", "minus", "yellow_𝑥²", "plus", "sqrt_x"],
            manipulative_setup="Place Peg A into socket (1, 2). Place Peg B into socket (4, 6).",
            prediction_step="Run = 4 - 1 = 3 units. Rise = 6 - 2 = 4 units. Predict: 3-4-5 right triangle -> Distance = 5 units (60 mm).",
            calculator_flow=[
                ("1", "1", "x1 = 1"),
                ("enter", "1", "Duplicate x1"),
                ("4", "4", "x2 = 4"),
                ("minus", "-3", "Run Δx = -3"),
                ("yellow_x_squared", "9", "Δx² = 9 in register X"),
                ("2", "2", "y1 = 2 (9 lifts to Y automatically!)"),
                ("enter", "2", "Duplicate y1"),
                ("6", "6", "y2 = 6"),
                ("minus", "-4", "Rise Δy = -4"),
                ("yellow_x_squared", "16", "Δy² = 16 in X (9 remains in Y)"),
                ("plus", "25", "Sum of squares: 9 + 16 = 25 in X"),
                ("sqrt_x", "5", "Square root: Distance = 5!"),
            ],
            explanation="The RPN stack retains Δx² in register Y while Δy² is calculated in register X. No memory keys required.",
            worksheet_problem="Place pegs at (2, 1) and (6, 4). Run the distance pipeline on your calculator. What is the distance?",
            worksheet_expected_keys=["2", "enter", "6", "minus", "yellow_𝑥²", "1", "enter", "4", "minus", "yellow_𝑥²", "plus", "sqrt_x"],
            worksheet_answer="5. Keystrokes: [2] [ENTER] [6] [-] [x²] [1] [ENTER] [4] [-] [x²] [+] [√𝑥]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Singapore Math",
            grade_unit="Dimensions 8, Chapter 9",
            chapter="Coordinate Geometry & Slope",
            title="Slope, Collinearity & Linear Rate of Change",
            standard="CCSS.MATH.8.EE.B.5",
            manipulative="Coordinate Lab (4x4 Gridfinity)",
            objective="Calculate the slope (rise / run) of a line segment connecting two points using register swap.",
            key_tokens=["6", "enter", "2", "minus", "4", "enter", "1", "minus", "divide"],
            manipulative_setup="Keep pegs at (1, 2) and (4, 6). Model the slope triangle with a straight edge.",
            prediction_step="Rise = 6 - 2 = 4. Run = 4 - 1 = 3. Slope m = 4 / 3 = 1.333...",
            calculator_flow=[
                ("6 ENTER 2 -", "4", "Vertical Rise Δy in Y"),
                ("4 ENTER 1 -", "3", "Horizontal Run Δx in X"),
                ("x_swap_y", "4", "Swap so Rise is in Y, Run is in X"),
                ("divide", "1.333", "Slope m = Rise / Run = 4/3!"),
            ],
            explanation="Slope is rise divided by run. The [x⇄y] key swaps the order of operands in registers X and Y instantly.",
            worksheet_problem="Find the slope between (1, 1) and (5, 9). Is the slope an integer?",
            worksheet_expected_keys=["9", "enter", "1", "minus", "5", "enter", "1", "minus", "divide"],
            worksheet_answer="Slope m = 2. Keystrokes: [9] [ENTER] [1] [-] [5] [ENTER] [1] [-] [÷]",
        ),
        practice_problems=[
            {"prompt": "Distance from (1, 2) to (4, 6). What is Δx² and Δy²?", "keys": "Δx²=9, Δy²=16, dist=5", "ans": "5"},
            {"prompt": "Distance from (2, 1) to (7, 13). (Run=5, Rise=12).", "keys": "[5] [x²] [1][2] [x²] [+] [√𝑥]", "ans": "13 (5-12-13 triangle)"},
            {"prompt": "Explain why negative coordinate differences do not affect the distance.", "keys": "Squaring a negative difference produces a positive area.", "ans": "(-d)² = d²"},
            {"prompt": "Find distance from (0, 0) to (3, 3) to 2 decimal places.", "keys": "[3] [x²] [3] [x²] [+] [√𝑥]", "ans": "4.24 (√18)"},
        ]
    ),

    # =========================================================================
    # UNIT 9: TRIGONOMETRY, VECTORS & POLAR COORDINATES (GRADES 9 - 11)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_9_trigonometry_vectors",
        unit_number=9,
        title="Trigonometry, Vectors & Polar/Rectangular Coordinates",
        grades="Grades 9–11",
        curricula_tags=["Big Ideas Math (Geometry / Precalculus)", "Singapore Math (Additional Math)"],
        standards=["CCSS.MATH.HSG.SRT.C.8", "CCSS.MATH.HSN.VM.A.1", "CCSS.MATH.HSN.VM.A.3"],
        manipulative="Coordinate Lab Stage (Gridfinity 4x4) + Locator Pegs (Vector Triangles)",
        student_guide_title="Vector Decomposition & Polar Conversion Rules",
        student_guide_rules=[
            "A 2D vector v = <x, y> has horizontal run x in Y and vertical rise y in X.",
            "Rectangular to Polar [yellow] [▸θ_r]: Converts (x, y) into angle θ (in X) and magnitude r (in Y).",
            "Trig functions [sin], [cos], [tan] operate on the angle in register X.",
            "To swap between angle and magnitude after conversion, press [x⇄y]!"
        ],
        calculator_shortcut="[RUN x] [ENTER] [RISE y] [yellow] [▸θ_r] -> Angle in X, Magnitude in Y",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Big Ideas Math",
            grade_unit="Geometry / Precalculus",
            chapter="Right Triangle Trigonometry & Vectors",
            title="Vector Magnitude & Direction: Cartesian to Polar",
            standard="CCSS.MATH.HSN.VM.A.1",
            manipulative="Coordinate Lab (4x4 Gridfinity)",
            objective="Decompose 2D vectors into horizontal and vertical components and convert to polar coordinates (r, θ).",
            key_tokens=["4", "enter", "3", "yellow_▸θ_r", "x_swap_y"],
            manipulative_setup="Place a peg at origin (0, 0) and a peg at (4, 3). Place a third peg at (4, 0) to form a right triangle.",
            prediction_step="Run = 4, Rise = 3. Predict magnitude: r = sqrt(4² + 3²) = 5. Predict angle: arctan(3/4) ≈ 36.87°.",
            calculator_flow=[
                ("4", "4", "Enter horizontal component x = 4"),
                ("enter", "4", "4 lifted to register Y"),
                ("3", "3", "Enter vertical component y = 3 in X"),
                ("yellow_▸θ_r", "36.87", "Rectangular to Polar! Screen displays angle θ = 36.87°"),
                ("x_swap_y", "5.00", "Swap registers: Y displays vector magnitude r = 5.00!"),
            ],
            explanation="The calculator's built-in polar conversion executes both the Pythagorean magnitude and arctangent angle in a single microcode step.",
            worksheet_problem="A surveyor walks 60 m East and 80 m North. Find the straight-line displacement magnitude and heading.",
            worksheet_expected_keys=["6", "0", "enter", "8", "0", "yellow_▸θ_r", "x_swap_y"],
            worksheet_answer="Displacement: 100 m, Heading: 53.13°. Keystrokes: [6][0] [ENTER] [8][0] [yellow] [▸θ_r] [x⇄y]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Big Ideas Math",
            grade_unit="Precalculus, Chapter 6",
            chapter="Vector Addition & Resultant Forces",
            title="2D Vector Addition: Resultant Forces",
            standard="CCSS.MATH.HSN.VM.A.3",
            manipulative="Coordinate Lab (4x4 Gridfinity)",
            objective="Add non-collinear 2D vectors by accumulating orthogonal components on the RPN stack.",
            key_tokens=["3", "enter", "1", "plus", "2", "enter", "5", "plus", "yellow_▸θ_r", "x_swap_y"],
            manipulative_setup="Model two force vectors: F1 = <3, 2> and F2 = <1, 5>.",
            prediction_step="Add components: x_net = 3 + 1 = 4; y_net = 2 + 5 = 7. Magnitude r = sqrt(4² + 7²) = sqrt(65) ≈ 8.06.",
            calculator_flow=[
                ("3 ENTER 1 +", "4", "Net horizontal force x_net = 4 in Y"),
                ("2 ENTER 5 +", "7", "Net vertical force y_net = 7 in X"),
                ("yellow_▸θ_r", "60.26", "Resultant angle θ = 60.26°"),
                ("x_swap_y", "8.06", "Resultant force magnitude r = 8.06!"),
            ],
            explanation="Vectors add component-wise. Stack registers permit component accumulation followed immediately by polar resolution.",
            worksheet_problem="Two cables pull on a post: Vector A is <5, 2> and Vector B is <-2, 4>. Find the resultant vector magnitude.",
            worksheet_expected_keys=["5", "enter", "2", "plus_minus", "plus", "2", "enter", "4", "plus", "yellow_▸θ_r", "x_swap_y"],
            worksheet_answer="Magnitude: 6.71. Resultant: <3, 6>.",
        ),
        practice_problems=[
            {"prompt": "Find magnitude and angle for vector <12, 5>.", "keys": "[1][2] [ENTER] [5] [yellow] [▸θ_r]", "ans": "θ = 22.62°, r = 13"},
            {"prompt": "Find the hypotenuse of a right triangle with legs 7 and 24.", "keys": "[7] [ENTER] [2][4] [yellow] [▸θ_r] [x⇄y]", "ans": "25"},
            {"prompt": "Calculate sin(30°) on the calculator.", "keys": "[3][0] [sin]", "ans": "0.5"},
            {"prompt": "A vector has magnitude 10 at angle 45°. What are its x and y components?", "keys": "[1][0] [ENTER] [4][5] [toRectangular]", "ans": "x = 7.07, y = 7.07"},
        ]
    ),

    # =========================================================================
    # UNIT 10: EXPONENTIAL GROWTH, TVM & LOGARITHMS (GRADES 10 - 12)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_10_exponential_growth",
        unit_number=10,
        title="Exponential Growth, Compound Interest & Logarithms",
        grades="Grades 10–12",
        curricula_tags=["Big Ideas Math (Algebra 2 Ch 6)", "High School Financial Mathematics"],
        standards=["CCSS.MATH.HSF.LE.A.1", "CCSS.MATH.HSF.LE.A.4", "CCSS.MATH.HSF.BF.B.5"],
        manipulative="Stack Stage (Gridfinity 3x3) + Fraction Towers (Powers of 2: 12, 24, 48, 96 mm)",
        student_guide_title="Exponentials, Continuous Compounding & Doubling Time",
        student_guide_rules=[
            "Exponential growth formula: A = P * e^(r*t) for continuous growth, or A = P * (1 + r/n)^(n*t).",
            "Natural exponential [eˣ] raises Euler's constant e to power X.",
            "Natural logarithm [LN] inverts exponential growth: ln(eˣ) = x.",
            "Doubling time formula: t = ln(2) / r. Stack evaluates ln(2) without rounding loss."
        ],
        calculator_shortcut="[r] [ENTER] [t] [*] [eˣ] [P] [*] = [ACCUMULATED AMOUNT A]",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="Big Ideas Math",
            grade_unit="Algebra 2, Chapter 6",
            chapter="Exponential & Logarithmic Functions",
            title="Continuous Compounding & Euler's Constant e",
            standard="CCSS.MATH.HSF.LE.A.4",
            manipulative="Stack Stage (3x3 Gridfinity)",
            objective="Model continuous exponential accumulation and compound interest using the natural exponential function [eˣ].",
            key_tokens=["0", "dot", "0", "7", "enter", "1", "0", "times", "𝑒ˣ", "1", "0", "0", "0", "times"],
            manipulative_setup="Place Fraction Blocks on the Stack Stage representing exponential doubling: 12 mm, 24 mm, 48 mm, 96 mm.",
            prediction_step="Invest $1,000 at 7% continuous interest for 10 years: A = 1000 * e^(0.07 * 10) = 1000 * e^0.7. Will it double? (e^0.7 ≈ 2.01).",
            calculator_flow=[
                ("0.07", "0.07", "Rate r = 0.07"),
                ("enter", "0.07", "Rate in Y"),
                ("10", "10", "Time t = 10 in X"),
                ("times", "0.7", "Exponent r * t = 0.70"),
                ("𝑒ˣ", "2.0138", "e^0.70 = 2.01375 (Growth factor: more than doubled!)"),
                ("1000", "1000", "Principal P = 1000 (growth factor lifts to Y)"),
                ("times", "2013.75", "Total accumulated amount A = $2,013.75!"),
            ],
            explanation="The RPN stack computes nested transcedentals from innermost exponent out to outer multiplier without parenthesis keys.",
            worksheet_problem="A bacteria culture starts at 500 and triples every hour. Use [yˣ] to calculate population after 4 hours.",
            worksheet_expected_keys=["3", "enter", "4", "y_to_x", "5", "0", "0", "times"],
            worksheet_answer="40,500 bacteria. Keystrokes: [3] [ENTER] [4] [yˣ] [5][0][0] [×]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="Big Ideas Math",
            grade_unit="Algebra 2 / Precalculus",
            chapter="Logarithms & Inverting Exponentials",
            title="Solving for Time: Doubling Time & Natural Log [LN]",
            standard="CCSS.MATH.HSF.BF.B.5",
            manipulative="Stack Stage (3x3 Gridfinity)",
            objective="Solve for time in exponential equations using the natural logarithm [LN] on the RPN stack.",
            key_tokens=["2", "ln", "0", "dot", "0", "5", "divide"],
            manipulative_setup="Configure stack registers: target multiplier in Y, growth rate in X.",
            prediction_step="At 5% growth (r = 0.05), doubling time is t = ln(2) / 0.05 ≈ 0.69315 / 0.05 ≈ 13.86 years.",
            calculator_flow=[
                ("2", "2", "Doubling target factor 2"),
                ("ln", "0.6931", "Natural log ln(2) = 0.693147... in X"),
                ("0.05", "0.05", "Rate r = 0.05 (ln(2) lifts to Y)"),
                ("divide", "13.86", "t = ln(2) / r = 13.86 years!"),
            ],
            explanation="The natural log [LN] is the exact inverse of [eˣ]. RPN preserves full floating point precision during the division.",
            worksheet_problem="A radioactive isotope has decay constant k = 0.035. Find its half-life: t = ln(2) / k.",
            worksheet_expected_keys=["2", "ln", "0", "dot", "0", "3", "5", "divide"],
            worksheet_answer="19.80 years. Keystrokes: [2] [LN] [0][.][0][3][5] [÷]",
        ),
        practice_problems=[
            {"prompt": "Calculate e^2 on the calculator to 4 decimal places.", "keys": "[2] [eˣ]", "ans": "7.3891"},
            {"prompt": "Calculate doubling time for an investment growing at 8% continuous interest.", "keys": "[2] [LN] [0][.][0][8] [÷]", "ans": "8.66 years"},
            {"prompt": "Compute 10^3.5 using [yellow] [10ˣ].", "keys": "[3][.][5] [yellow] [10ˣ]", "ans": "3162.28"},
            {"prompt": "Evaluate log10(500) using [yellow] [LOG].", "keys": "[5][0][0] [yellow] [LOG]", "ans": "2.6990"},
        ]
    ),

    # =========================================================================
    # UNIT 11: COMBINATORICS & PROBABILITY (GRADES 11 - 12 / AP)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_11_combinatorics_probability",
        unit_number=11,
        title="Combinatorics, Probability & Series Accumulation",
        grades="Grades 11–12 / AP",
        curricula_tags=["AP Statistics (Unit 4: Probability)", "Discrete Mathematics", "Singapore Math (H2)"],
        standards=["CCSS.MATH.HSS.CP.B.9", "CCSS.MATH.HSA.SSE.B.4"],
        manipulative="Expression Tree (Branching Outcomes) + Stack Stage",
        student_guide_title="Combinations, Permutations & Stack Factorials",
        student_guide_rules=[
            "Factorial [yellow] [x!] multiplies n * (n-1) * ... * 1.",
            "Permutations (order matters): nPr = n! / (n - r)!.",
            "Combinations (subsets/groups): nCr = n! / (r! * (n - r)!).",
            "Stack accumulation: [Σ+] accumulates data points for instant mean and standard deviation."
        ],
        calculator_shortcut="[n] [yellow] [x!]   [r] [yellow] [x!] [÷]   [n - r] [yellow] [x!] [÷] = nCr",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="AP Statistics",
            grade_unit="AP Statistics, Unit 4",
            chapter="Probability, Random Variables & Combinatorics",
            title="Combinations vs. Permutations: Subsets & Order",
            standard="CCSS.MATH.HSS.CP.B.9",
            manipulative="Expression Tree (4x3 Gridfinity)",
            objective="Calculate permutations and combinations by evaluating factorials across the 4-register stack.",
            key_tokens=["8", "yellow_𝑥!", "3", "yellow_𝑥!", "divide", "5", "yellow_𝑥!", "divide"],
            manipulative_setup="Place 8 distinct tokens in top wells. Model choosing 3 tokens without replacement.",
            prediction_step="How many ways to choose a committee of 3 from 8 candidates? 8C3 = 8! / (3! * 5!) = 40320 / (6 * 120) = 56.",
            calculator_flow=[
                ("8", "8", "Total candidates n = 8"),
                ("yellow_x!", "40320", "8! = 40,320 in register X"),
                ("3", "3", "Subset r = 3 (40320 lifts to Y)"),
                ("yellow_x!", "6", "3! = 6 in X"),
                ("divide", "6720", "40320 / 6 = 6720 in X"),
                ("5", "5", "Remaining n - r = 5 (6720 lifts to Y)"),
                ("yellow_x!", "120", "5! = 120 in X"),
                ("divide", "56", "6720 / 120 = 56 combinations!"),
            ],
            explanation="The RPN stack handles multi-step factorial simplification effortlessly, preventing arithmetic overflow.",
            worksheet_problem="A lottery draws 4 winning numbers from a pool of 10. How many combinations? Calculate 10C4.",
            worksheet_expected_keys=["1", "0", "yellow_𝑥!", "4", "yellow_𝑥!", "divide", "6", "yellow_𝑥!", "divide"],
            worksheet_answer="210 combinations. Keystrokes: [1][0] [x!] [4] [x!] [÷] [6] [x!] [÷]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="AP Statistics",
            grade_unit="AP Statistics, Unit 1",
            chapter="One-Variable Data Analysis & Summations",
            title="Statistical Accumulation: Mean & Variance with [Σ+]",
            standard="CCSS.MATH.HSS.ID.A.2",
            manipulative="Coordinate Lab (4x4 Gridfinity)",
            objective="Accumulate discrete data sets into the hardware statistical registers and compute sample statistics.",
            key_tokens=["4", "sigma_plus", "6", "sigma_plus", "7", "sigma_plus", "8", "sigma_plus", "1", "0", "sigma_plus"],
            manipulative_setup="Place 5 pegs along the x-axis representing quiz scores: 4, 6, 7, 8, 10.",
            prediction_step="Sum = 4 + 6 + 7 + 8 + 10 = 35. Sample size n = 5. Mean x̄ = 35 / 5 = 7.0.",
            calculator_flow=[
                ("4 sigma_plus", "1", "First score entered: sample size n = 1"),
                ("6 sigma_plus", "2", "Second score: n = 2"),
                ("7 sigma_plus", "3", "Third score: n = 3"),
                ("8 sigma_plus", "4", "Fourth score: n = 4"),
                ("10 sigma_plus", "5", "Fifth score: n = 5 total data points"),
            ],
            explanation="The [Σ+] key accumulates sum(x), sum(x²), and count n into dedicated background statistical registers.",
            worksheet_problem="Accumulate data points 12, 15, 18, 21 using [Σ+]. What is the sample count n and mean?",
            worksheet_expected_keys=["1", "2", "sigma_plus", "1", "5", "sigma_plus", "1", "8", "sigma_plus", "2", "1", "sigma_plus"],
            worksheet_answer="Count n = 4, Mean x̄ = 16.5.",
        ),
        practice_problems=[
            {"prompt": "Calculate 6! (6 factorial) on the calculator.", "keys": "[6] [yellow] [x!]", "ans": "720"},
            {"prompt": "How many ways can 5 runners finish 1st, 2nd, and 3rd? (5P3 = 5! / 2!).", "keys": "[5] [yellow] [x!] [2] [yellow] [x!] [÷]", "ans": "60"},
            {"prompt": "Calculate 7C2 (combinations of 2 from 7).", "keys": "[7] [yellow] [x!] [2] [yellow] [x!] [÷] [5] [yellow] [x!] [÷]", "ans": "21"},
            {"prompt": "Accumulate 5 and 15 with [Σ+]. What is the mean?", "keys": "[5] [Σ+] [1][5] [Σ+]", "ans": "Mean = 10"},
        ]
    ),

    # =========================================================================
    # UNIT 12: DIGITAL LOGIC, BASE CONVERSIONS & ARCHITECTURE (GRADES 9 - 12 / AP CS)
    # =========================================================================
    CurriculumUnit(
        unit_id="unit_12_digital_logic_bases",
        unit_number=12,
        title="Digital Logic, Base Conversions & Computer Architecture",
        grades="Grades 9–12 / AP CS",
        curricula_tags=["AP Computer Science Principles (Big Idea 2)", "AP Computer Science A", "Digital Electronics"],
        standards=["CCSS.MATH.PRACTICE.MP5", "CCSS.MATH.HSA.SSE.A.1"],
        manipulative="Ten-Frame Stage (acting as an 8-bit byte register: bit 7 to 0) + Stack Stage",
        student_guide_title="Number Bases & Bitwise Logic Gates",
        student_guide_rules=[
            "Binary (Base 2): digits 0 and 1. Hexadecimal (Base 16): digits 0-9 and A-F.",
            "Press [yellow] [BASE] to cycle between DEC (decimal), HEX (hexadecimal), OCT (octal), and BIN (binary).",
            "Bitwise AND: result bit is 1 only if BOTH bits are 1 (used for masking and subnets).",
            "Bitwise OR: result bit is 1 if EITHER bit is 1. Bitwise XOR: result bit is 1 if bits DIFFER."
        ],
        calculator_shortcut="[DECIMAL VALUE] [yellow] [BASE] -> Cycles to HEX, BIN, OCT",
        primary_lesson=LessonPlan(
            lesson_type="Primary Core",
            curriculum="AP Computer Science Principles",
            grade_unit="AP CSP, Big Idea 2",
            chapter="Data Representation & Binary Number Systems",
            title="Number Representation: Decimal to Binary and Hexadecimal",
            standard="CCSS.MATH.PRACTICE.MP5",
            manipulative="Ten-Frame Stage (4x2 Gridfinity)",
            objective="Represent integers physically as bit registers and computationally convert between bases with [yellow] [BASE].",
            key_tokens=["1", "1", "yellow_base"],
            manipulative_setup="Use the 8 wells of the Ten-Frame as an 8-bit byte. Place pegs in wells for active '1' bits, leave empty for '0'.",
            prediction_step="Place pegs at positions 0, 1, and 3: binary 00001011_2 = 8 + 2 + 1 = 11_10. Predict hex value: 0B_16.",
            calculator_flow=[
                ("11", "11", "Enter decimal integer 11 in DEC mode"),
                ("yellow_base", "HEX 0B", "Press [yellow] [BASE]: screen displays Hexadecimal 0B!"),
                ("yellow_base", "BIN 1011", "Press [yellow] [BASE]: screen displays Binary 1011!"),
                ("yellow_base", "OCT 13", "Press [yellow] [BASE]: screen displays Octal 13!"),
                ("yellow_base", "DEC 11", "Press [yellow] [BASE]: returns to Decimal 11"),
            ],
            explanation="Computer memory stores identical bit patterns; base conversions alter only the human visual representation.",
            worksheet_problem="Enter decimal 255. Use [yellow] [BASE] to convert to HEX and BIN. What is the binary pattern?",
            worksheet_expected_keys=["2", "5", "5", "yellow_base"],
            worksheet_answer="HEX: FF, BIN: 11111111 (8 ones). Keystrokes: [2][5][5] [yellow] [BASE]",
        ),
        followup_lesson=LessonPlan(
            lesson_type="Follow-Up Extension",
            curriculum="AP Computer Science Principles",
            grade_unit="AP CSP, Big Idea 2",
            chapter="Boolean Logic & Bitwise Operations",
            title="Bitwise Logic: AND Masking & Network Subnets",
            standard="CCSS.MATH.PRACTICE.MP5",
            manipulative="Ten-Frame Stage (4x2 Gridfinity)",
            objective="Perform bitwise logic operations on integer operands to understand hardware gate logic and masking.",
            key_tokens=["1", "2", "enter", "1", "0", "and"],
            manipulative_setup="Row 1 holds byte A (1100 = 12). Row 2 holds mask B (1010 = 10).",
            prediction_step="Bitwise AND: bit 3 (1 & 1 = 1), bit 2 (1 & 0 = 0), bit 1 (0 & 1 = 0), bit 0 (0 & 0 = 0). Result: 1000_2 = 8_10.",
            calculator_flow=[
                ("12", "12", "Enter operand A = 12 (binary 1100)"),
                ("enter", "12", "12 lifted to register Y"),
                ("10", "10", "Enter operand B = 10 (binary 1010) in X"),
                ("and", "8", "Bitwise AND evaluates 1100 & 1010 = 1000 (8 decimal)!"),
            ],
            explanation="Bitwise AND masks bits, clearing unwanted bits to zero. This is the exact operation used in IPv4 subnet masking.",
            worksheet_problem="Calculate bitwise OR for 12 (1100) and 3 (0011). Predict the binary and decimal result.",
            worksheet_expected_keys=["1", "2", "enter", "3", "or"],
            worksheet_answer="Binary: 1111, Decimal: 15. Keystrokes: [1][2] [ENTER] [3] [OR]",
        ),
        practice_problems=[
            {"prompt": "Convert decimal 42 to binary using [yellow] [BASE].", "keys": "[4][2] [yellow] [BASE]", "ans": "101010 (32 + 8 + 2)"},
            {"prompt": "Convert hexadecimal 2A to decimal.", "keys": "In HEX mode: [2][A] -> switch to DEC", "ans": "42"},
            {"prompt": "Evaluate bitwise AND: 15 (1111) AND 7 (0111).", "keys": "[1][5] [ENTER] [7] [AND]", "ans": "7 (0111)"},
            {"prompt": "Evaluate bitwise XOR: 12 (1100) XOR 10 (1010).", "keys": "[1][2] [ENTER] [1][0] [XOR]", "ans": "6 (0110)"},
        ]
    ),
]


CURRICULA_LESSONS: List[LessonPlan] = [u.primary_lesson for u in CURRICULUM_UNITS]


@dataclass
class CurriculumCrossReference:
    curriculum: str         # "Singapore Math", "Bridges in Mathematics", "Big Ideas Math", "AP Math / CS"
    grade: str              # "Kindergarten", "Grade 1", "Grade 2", etc.
    textbook_reference: str # e.g. "Ch 2, Lesson 2.3", "Unit 3, Mod 1, Session 2", "Section 7.5"
    lesson_title: str       # "Making Number Bonds to 10"
    standard: str           # "CCSS.MATH.1.OA.C.6"
    manipulative: str       # "Number Bond Stage (3x2)"
    keystroke_preview: str  # "[PART 1] [ENTER] [PART 2] [+]"
    unit_number: int        # 1 to 12
    page_core: int          # exact page in guide
    page_ext: int           # exact page in guide
    page_worksheet: int     # exact page in guide


CURRICULUM_CROSS_REFERENCES: List[CurriculumCrossReference] = [
    # =========================================================================
    # 1. SINGAPORE MATH (Dimensions Math PK–8 & Additional Math)
    # =========================================================================
    # Dimensions Math Pre-K & Kindergarten (KA / KB)
    CurriculumCrossReference("Singapore Math", "Pre-K", "Dimensions PK Book A, Ch 2, Lesson 2.1", "Counting to 5 with Concrete Items", "CCSS.MATH.K.CC.B.4", "Ten-Frame Stage (4x2)", "[1] [ENTER] [1] [+]", 1, 5, 6, 7),
    CurriculumCrossReference("Singapore Math", "Pre-K", "Dimensions PK Book B, Ch 4, Lesson 4.2", "Comparing Quantities: More or Less", "CCSS.MATH.K.CC.C.6", "Ten-Frame Stage (4x2)", "[5] [ENTER] [2] [-]", 1, 5, 6, 7),
    CurriculumCrossReference("Singapore Math", "Kindergarten", "Dimensions KA, Ch 1, Lesson 1.2", "One-to-One Counting & Frames", "CCSS.MATH.K.CC.B.4", "Ten-Frame Stage (4x2)", "[1] [ENTER] [1] [+]", 1, 5, 6, 7),
    CurriculumCrossReference("Singapore Math", "Kindergarten", "Dimensions KA, Ch 2, Lesson 2.3", "Zero and Empty Sets", "CCSS.MATH.K.CC.A.3", "Ten-Frame Stage (4x2)", "[0] / [C]", 1, 5, 6, 7),
    CurriculumCrossReference("Singapore Math", "Kindergarten", "Dimensions KA, Ch 4, Lesson 4.1", "Number Bonds of 5", "CCSS.MATH.K.OA.A.3", "Number Bond Stage (3x2)", "[3] [ENTER] [2] [+]", 2, 8, 9, 10),
    CurriculumCrossReference("Singapore Math", "Kindergarten", "Dimensions KB, Ch 7, Lesson 7.2", "Addition within 10 on the Stack", "CCSS.MATH.K.OA.A.1", "Number Bond Stage (3x2)", "[4] [ENTER] [3] [+]", 2, 8, 9, 10),
    CurriculumCrossReference("Singapore Math", "Kindergarten", "Dimensions KB, Ch 8, Lesson 8.1", "Subtraction as Missing Part", "CCSS.MATH.K.OA.A.2", "Number Bond Stage (3x2)", "[1][0] [ENTER] [4] [-]", 2, 8, 9, 10),
    # Dimensions Math 1A / 1B
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 1, Lesson 1.3", "Counting & Comparing Numbers to 10", "CCSS.MATH.1.NBT.A.1", "Ten-Frame Stage (4x2)", "[1] [ENTER] [1] [+]", 1, 5, 6, 7),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 2, Lesson 2.1", "Making Number Bonds to 6 and 8", "CCSS.MATH.1.OA.C.6", "Number Bond Stage (3x2)", "[5] [ENTER] [3] [+]", 2, 8, 9, 10),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 2, Lesson 2.2", "Making Number Bonds to 10", "CCSS.MATH.1.OA.C.6", "Number Bond Stage (3x2)", "[7] [ENTER] [3] [+]", 2, 8, 9, 10),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 2, Lesson 2.4", "Decomposing Numbers & Missing Parts", "CCSS.MATH.1.OA.B.4", "Number Bond Stage (3x2)", "[1][0] [ENTER] [6] [-]", 2, 8, 9, 10),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 3, Lesson 3.1", "Addition as Part-Part-Whole", "CCSS.MATH.1.OA.C.6", "Number Bond Stage (3x2)", "[PART 1] [ENTER] [PART 2] [+]", 2, 8, 9, 10),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 4, Lesson 4.2", "Subtraction as Comparing Sets", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "[LARGE] [ENTER] [SMALL] [-]", 1, 5, 6, 7),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 7, Lesson 7.1", "Ten-Frames & Place Value (11-20)", "CCSS.MATH.1.NBT.B.2", "Ten-Frame Stage (4x2)", "[1][0] [ENTER] [N] [+]", 3, 11, 12, 13),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 8, Lesson 8.1", "Making 10 to Add", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "[1][0] [ENTER] [N] [-]", 3, 11, 12, 13),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1A, Ch 8, Lesson 8.3", "Bridging Through 10", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "[8] [ENTER] [2] [+] [3] [+]", 3, 11, 12, 13),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1B, Ch 12, Lesson 12.1", "Multiplication as Equal Groups", "CCSS.MATH.1.OA.A.1", "Number Rack (4x2)", "[N] [ENTER] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Singapore Math", "Grade 1", "Dimensions 1B, Ch 14, Lesson 14.1", "Halves & Fourths (Equal Shares)", "CCSS.MATH.1.G.A.3", "Fraction Studio (4x2)", "[. 1 . 2] / [. 1 . 4]", 6, 20, 21, 22),
    # Dimensions Math 2A / 2B
    CurriculumCrossReference("Singapore Math", "Grade 2", "Dimensions 2A, Ch 2, Lesson 2.2", "Mental Addition with Number Bonds", "CCSS.MATH.2.OA.B.2", "Number Bond Stage (3x2)", "[P1] [ENTER] [P2] [+]", 2, 8, 9, 10),
    CurriculumCrossReference("Singapore Math", "Grade 2", "Dimensions 2A, Ch 4, Lesson 4.1", "Doubles & Multiplying by 2", "CCSS.MATH.2.OA.C.4", "Number Rack (4x2)", "[N] [ENTER] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Singapore Math", "Grade 2", "Dimensions 2B, Ch 6, Lesson 6.3", "Near-Doubles Strategies (Doubles + 1)", "CCSS.MATH.2.OA.B.2", "Number Rack (4x2)", "[N] [ENTER] [+] [1] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Singapore Math", "Grade 2", "Dimensions 2B, Ch 7, Lesson 7.1", "Unit Fractions (Halves, Thirds, Fourths)", "CCSS.MATH.2.G.A.3", "Fraction Studio (4x2)", "Compare 48mm / 32mm / 24mm", 6, 20, 21, 22),
    # Dimensions Math 3A / 3B
    CurriculumCrossReference("Singapore Math", "Grade 3", "Dimensions 3A, Ch 2, Lesson 2.4", "Multi-Digit Addition on Stack", "CCSS.MATH.3.NBT.A.2", "Stack Stage (3x3)", "[A] [ENTER] [B] [+]", 5, 17, 18, 19),
    CurriculumCrossReference("Singapore Math", "Grade 3", "Dimensions 3A, Ch 3, Lesson 3.5", "Four Operations & Word Problems", "CCSS.MATH.3.OA.D.8", "Stack Stage (3x3)", "[A] [ENTER] [B] [OP1] [C] [OP2]", 5, 17, 18, 19),
    CurriculumCrossReference("Singapore Math", "Grade 3", "Dimensions 3B, Ch 6, Lesson 6.2", "Equivalent Fractions on Blocks", "CCSS.MATH.3.NF.A.3", "Fraction Studio (4x2)", "2/4 height = 1/2 height", 6, 20, 21, 22),
    CurriculumCrossReference("Singapore Math", "Grade 3", "Dimensions 3B, Ch 6, Lesson 6.4", "Comparing Fractions to 1 Whole", "CCSS.MATH.3.NF.A.3", "Fraction Studio (4x2)", "Tower sum vs 96mm Whole", 6, 20, 21, 22),
    # Dimensions Math 4A / 4B
    CurriculumCrossReference("Singapore Math", "Grade 4", "Dimensions 4A, Ch 3, Lesson 3.3", "Multi-Step Mixed Operations", "CCSS.MATH.4.OA.A.3", "Stack Stage (3x3)", "[8] [ENTER] [3] [-] [2] [×]", 5, 17, 18, 19),
    CurriculumCrossReference("Singapore Math", "Grade 4", "Dimensions 4A, Ch 3, Lesson 3.6", "Order of Operations & Auto-Lift", "CCSS.MATH.4.OA.A.3", "Stack Stage (3x3)", "Result lifts to Y automatically", 5, 17, 18, 19),
    CurriculumCrossReference("Singapore Math", "Grade 4", "Dimensions 4A, Ch 5, Lesson 5.1", "Mixed Numbers & Fraction Towers", "CCSS.MATH.4.NF.B.3", "Fraction Studio (4x2)", "[2 . 1 . 2] = 2 1/2", 6, 20, 21, 22),
    CurriculumCrossReference("Singapore Math", "Grade 4", "Dimensions 4A, Ch 5, Lesson 5.4", "Adding Mixed Fractions", "CCSS.MATH.4.NF.B.3", "Fraction Studio (4x2)", "[. 3 . 4] [ENTER] [2 . 1 . 2] [+]", 6, 20, 21, 22),
    CurriculumCrossReference("Singapore Math", "Grade 4", "Dimensions 4B, Ch 6, Lesson 6.2", "Fractions to Decimals Conversion", "CCSS.MATH.4.NF.C.6", "Fraction Studio (4x2)", "[. 3 . 4] -> displays 0.75", 6, 20, 21, 22),
    # Dimensions Math 5A / 5B
    CurriculumCrossReference("Singapore Math", "Grade 5", "Dimensions 5A, Ch 1, Lesson 1.4", "Expressions Without Parentheses", "CCSS.MATH.5.OA.A.1", "Expression Tree (4x3)", "Postorder Left-Right-Op", 7, 23, 24, 25),
    CurriculumCrossReference("Singapore Math", "Grade 5", "Dimensions 5A, Ch 2, Lesson 2.3", "Unlike Denominators Addition", "CCSS.MATH.5.NF.A.1", "Fraction Studio (4x2)", "Common base comparison", 6, 20, 21, 22),
    CurriculumCrossReference("Singapore Math", "Grade 5", "Dimensions 5A, Ch 3, Lesson 3.2", "Fraction Multiplication & Scaling", "CCSS.MATH.5.NF.B.4", "Fraction Studio (4x2)", "[. 3 . 4] [ENTER] [. 2 . 3] [×]", 6, 20, 21, 22),
    CurriculumCrossReference("Singapore Math", "Grade 5", "Dimensions 5A, Ch 3, Lesson 3.5", "Dividing Fractions with Reciprocal [¹/𝑥]", "CCSS.MATH.5.NF.B.7", "Fraction Studio (4x2)", "[¹/𝑥] inverts divisor", 6, 20, 21, 22),
    CurriculumCrossReference("Singapore Math", "Grade 5", "Dimensions 5B, Ch 8, Lesson 8.3", "Coordinate Graphing & Ordered Pairs", "CCSS.MATH.5.G.A.1", "Coordinate Lab (4x4)", "Locate (x, y) with pegs", 8, 26, 27, 28),
    # Dimensions Math 6A / 6B
    CurriculumCrossReference("Singapore Math", "Grade 6", "Dimensions 6A, Ch 1, Lesson 1.2", "Negative Integers on Stack", "CCSS.MATH.6.NS.C.5", "Stack Stage (3x3)", "[+/-] toggles sign in X", 5, 17, 18, 19),
    CurriculumCrossReference("Singapore Math", "Grade 6", "Dimensions 6A, Ch 3, Lesson 3.1", "Syntax Trees & Algebraic Expressions", "CCSS.MATH.6.EE.A.2", "Expression Tree (4x3)", "(a + b) * (c - d)", 7, 23, 24, 25),
    CurriculumCrossReference("Singapore Math", "Grade 6", "Dimensions 6A, Ch 3, Lesson 3.3", "Postorder Traversal Evaluation", "CCSS.MATH.6.EE.A.2", "Expression Tree (4x3)", "a b + c d - *", 7, 23, 24, 25),
    CurriculumCrossReference("Singapore Math", "Grade 6", "Dimensions 6B, Ch 7, Lesson 7.2", "Distance in the Coordinate Plane", "CCSS.MATH.6.NS.C.8", "Coordinate Lab (4x4)", "Δx and Δy run/rise", 8, 26, 27, 28),
    # Dimensions Math 7A / 8A / Additional Math
    CurriculumCrossReference("Singapore Math", "Grade 7", "Dimensions 7A, Ch 3, Lesson 3.2", "Linear Expressions & Register Depth", "CCSS.MATH.7.EE.A.1", "Expression Tree (4x3)", "Depth management on stack", 7, 23, 24, 25),
    CurriculumCrossReference("Singapore Math", "Grade 8", "Dimensions 8A, Ch 7, Lesson 7.3", "The Pythagorean Theorem on Grid", "CCSS.MATH.8.G.B.7", "Coordinate Lab (4x4)", "Δx² + Δy² = d²", 8, 26, 27, 28),
    CurriculumCrossReference("Singapore Math", "Grade 8", "Dimensions 8A, Ch 7, Lesson 7.5", "Euclidean Distance Pipeline", "CCSS.MATH.8.G.B.8", "Coordinate Lab (4x4)", "[x1] [ENTER] [x2] [-] [x²]...", 8, 26, 27, 28),
    CurriculumCrossReference("Singapore Math", "Grade 8", "Dimensions 8B, Ch 9, Lesson 9.2", "Slope & Rate of Change", "CCSS.MATH.8.EE.B.5", "Coordinate Lab (4x4)", "Rise in Y, Run in X, [÷]", 8, 26, 27, 28),
    CurriculumCrossReference("Singapore Math", "High School", "Add. Math, Ch 10, Lesson 10.1", "Right Triangle Trigonometric Ratios", "CCSS.MATH.HSG.SRT.C.8", "Coordinate Lab (4x4)", "[sin], [cos], [tan]", 9, 29, 30, 31),
    CurriculumCrossReference("Singapore Math", "High School", "Add. Math, Ch 10, Lesson 10.3", "Vectors & Polar Coordinates", "CCSS.MATH.HSN.VM.A.1", "Coordinate Lab (4x4)", "[RUN] [ENTER] [RISE] [▸θ_r]", 9, 29, 30, 31),

    # =========================================================================
    # 2. BRIDGES IN MATHEMATICS (The Math Learning Center)
    # =========================================================================
    # Kindergarten
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 1, Mod 1, Session 1", "Welcome to Math: Counting Objects", "CCSS.MATH.K.CC.B.4", "Ten-Frame Stage (4x2)", "1 peg = 1 count", 1, 5, 6, 7),
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 1, Mod 1, Session 2", "Counting & Five-Frames", "CCSS.MATH.K.CC.B.4", "Ten-Frame Stage (4x2)", "Top row = 5", 1, 5, 6, 7),
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 1, Mod 2, Session 1", "Ten-Frames & Counting On", "CCSS.MATH.K.CC.B.5", "Ten-Frame Stage (4x2)", "[1] [ENTER] [1] [+]", 1, 5, 6, 7),
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 1, Mod 2, Session 3", "Zero & The Empty Ten-Frame", "CCSS.MATH.K.CC.A.3", "Ten-Frame Stage (4x2)", "[0] / [C]", 1, 5, 6, 7),
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 1, Mod 3, Session 2", "The Step Counter: Adding One More", "CCSS.MATH.K.OA.A.1", "Ten-Frame Stage (4x2)", "[1] [ENTER] [1] [+] [1] [+]", 1, 5, 6, 7),
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 2, Mod 1, Session 2", "Comparing Sets: Which Has More?", "CCSS.MATH.K.CC.C.6", "Ten-Frame Stage (4x2)", "[5] [ENTER] [2] [-]", 1, 5, 6, 7),
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 2, Mod 2, Session 3", "Number Bonds to 5", "CCSS.MATH.K.OA.A.3", "Number Bond Stage (3x2)", "Part-Part-Whole 5", 2, 8, 9, 10),
    CurriculumCrossReference("Bridges in Mathematics", "Kindergarten", "Unit 4, Mod 2, Session 1", "Part-Part-Whole Addition", "CCSS.MATH.K.OA.A.2", "Number Bond Stage (3x2)", "[P1] [ENTER] [P2] [+]", 2, 8, 9, 10),
    # Grade 1
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 1, Mod 2, Session 3", "Ten-Frames & Subitizing", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "Instant recognition of 7", 3, 11, 12, 13),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 2, Mod 1, Session 2", "Combinations to Ten", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "[1][0] [ENTER] [N] [-]", 3, 11, 12, 13),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 2, Mod 1, Session 4", "Finding the Missing Addend", "CCSS.MATH.1.OA.B.4", "Number Bond Stage (3x2)", "[WHOLE] [ENTER] [P1] [-]", 2, 8, 9, 10),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 2, Mod 3, Session 3", "Making 10 Addition Strategies", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "Bridging 8 + 5 = 10 + 3", 3, 11, 12, 13),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 3, Mod 1, Session 1", "Introducing the Number Rack", "CCSS.MATH.1.OA.C.6", "Number Rack (4x2)", "5 red + 5 white beads", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 3, Mod 1, Session 2", "Double Flips on the Number Rack", "CCSS.MATH.1.OA.C.6", "Number Rack (4x2)", "[6] [ENTER] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 3, Mod 1, Session 3", "Doubles Plus or Minus One", "CCSS.MATH.1.OA.C.6", "Number Rack (4x2)", "[6] [ENTER] [+] [1] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 3, Mod 2, Session 1", "5-Structure on the Rack", "CCSS.MATH.1.OA.C.6", "Number Rack (4x2)", "Subitizing 5 groups", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 6, Mod 1, Session 2", "Two-Row Rack Comparisons", "CCSS.MATH.1.OA.A.1", "Number Rack (4x2)", "Difference between rows", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 1", "Unit 7, Mod 1, Session 3", "Place Value: Tens & Ones", "CCSS.MATH.1.NBT.B.2", "Ten-Frame Stage (4x2)", "10 + N on the stack", 3, 11, 12, 13),
    # Grade 2
    CurriculumCrossReference("Bridges in Mathematics", "Grade 2", "Unit 1, Mod 1, Session 2", "Number Rack Fact Fluency", "CCSS.MATH.2.OA.B.2", "Number Rack (4x2)", "[N] [ENTER] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 2", "Unit 1, Mod 1, Session 4", "Near-Doubles Fact Strategies", "CCSS.MATH.2.OA.B.2", "Number Rack (4x2)", "[N] [ENTER] [+] [1] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 2", "Unit 1, Mod 2, Session 1", "Combinations to 20", "CCSS.MATH.2.OA.B.2", "Number Rack (4x2)", "Dual row combinations", 4, 14, 15, 16),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 2", "Unit 3, Mod 2, Session 4", "Two-Digit Subtraction on Stack", "CCSS.MATH.2.NBT.B.5", "Stack Stage (3x3)", "[Y] [ENTER] [X] [-]", 5, 17, 18, 19),
    # Grade 3
    CurriculumCrossReference("Bridges in Mathematics", "Grade 3", "Unit 1, Mod 2, Session 3", "Multi-Step Addition & Subtraction", "CCSS.MATH.3.OA.D.8", "Stack Stage (3x3)", "Chained operations on stack", 5, 17, 18, 19),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 3", "Unit 2, Mod 1, Session 2", "Multiplication Arrays & Groups", "CCSS.MATH.3.OA.A.1", "Stack Stage (3x3)", "[ROWS] [ENTER] [COLS] [×]", 5, 17, 18, 19),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 3", "Unit 4, Mod 1, Session 2", "Unit Fractions: Equal Shares", "CCSS.MATH.3.NF.A.1", "Fraction Studio (4x2)", "Proportional tower blocks", 6, 20, 21, 22),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 3", "Unit 4, Mod 2, Session 3", "Comparing Fractions to One Whole", "CCSS.MATH.3.NF.A.3", "Fraction Studio (4x2)", "Blocks vs 96mm Whole", 6, 20, 21, 22),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 3", "Unit 7, Mod 1, Session 2", "Equivalent Fractions on Blocks", "CCSS.MATH.3.NF.A.3", "Fraction Studio (4x2)", "Equal height towers", 6, 20, 21, 22),
    # Grade 4
    CurriculumCrossReference("Bridges in Mathematics", "Grade 4", "Unit 1, Mod 1, Session 3", "Multi-Step Word Problems", "CCSS.MATH.4.OA.A.3", "Stack Stage (3x3)", "[15] [ENTER] [6] [-] [3] [÷]", 5, 17, 18, 19),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 4", "Unit 2, Mod 2, Session 4", "Order of Operations & Lift", "CCSS.MATH.4.OA.A.3", "Stack Stage (3x3)", "Auto-lift pushes to Y", 5, 17, 18, 19),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 4", "Unit 3, Mod 1, Session 2", "Comparing Fractions with Blocks", "CCSS.MATH.4.NF.A.2", "Fraction Studio (4x2)", "Tower height comparisons", 6, 20, 21, 22),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 4", "Unit 3, Mod 2, Session 1", "Adding Fractions with Like Bases", "CCSS.MATH.4.NF.B.3", "Fraction Studio (4x2)", "[. 1 . 4] [ENTER] [. 2 . 4] [+]", 6, 20, 21, 22),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 4", "Unit 3, Mod 3, Session 2", "Mixed Numbers & Two-Dot Entry", "CCSS.MATH.4.NF.B.3", "Fraction Studio (4x2)", "[2 . 1 . 2] = 2 1/2", 6, 20, 21, 22),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 4", "Unit 6, Mod 1, Session 3", "Fraction Multiplication as Scaling", "CCSS.MATH.4.NF.B.4", "Fraction Studio (4x2)", "Height scaling factor", 6, 20, 21, 22),
    # Grade 5
    CurriculumCrossReference("Bridges in Mathematics", "Grade 5", "Unit 1, Mod 1, Session 2", "Numerical Expressions & Trees", "CCSS.MATH.5.OA.A.1", "Expression Tree (4x3)", "Binary syntax trees", 7, 23, 24, 25),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 5", "Unit 1, Mod 2, Session 3", "Expressions Without Parentheses", "CCSS.MATH.5.OA.A.1", "Expression Tree (4x3)", "Postorder traversal", 7, 23, 24, 25),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 5", "Unit 2, Mod 1, Session 2", "Adding Fractions with Unlike Bases", "CCSS.MATH.5.NF.A.1", "Fraction Studio (4x2)", "[. 3 . 4] [ENTER] [. 1 . 2] [+]", 6, 20, 21, 22),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 5", "Unit 5, Mod 1, Session 3", "Multiplying Fractions & Reciprocals", "CCSS.MATH.5.NF.B.4", "Fraction Studio (4x2)", "[¹/𝑥] reciprocal operator", 6, 20, 21, 22),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 5", "Unit 6, Mod 1, Session 1", "The Coordinate Plane: Points & Pegs", "CCSS.MATH.5.G.A.1", "Coordinate Lab (4x4)", "Locate (x, y) with pegs", 8, 26, 27, 28),
    CurriculumCrossReference("Bridges in Mathematics", "Grade 5", "Unit 6, Mod 2, Session 2", "Distance Between Grid Points", "CCSS.MATH.5.G.A.2", "Coordinate Lab (4x4)", "Horizontal run & vertical rise", 8, 26, 27, 28),

    # =========================================================================
    # 3. BIG IDEAS MATH & AP STANDARDS
    # =========================================================================
    # Kindergarten
    CurriculumCrossReference("Big Ideas Math", "Kindergarten", "Chapter 1, Section 1.2", "Count and Write 1 to 5", "CCSS.MATH.K.CC.B.4", "Ten-Frame Stage (4x2)", "[1] [ENTER] [1] [+]", 1, 5, 6, 7),
    CurriculumCrossReference("Big Ideas Math", "Kindergarten", "Chapter 3, Section 3.1", "Model and Count 6 to 10", "CCSS.MATH.K.CC.B.5", "Ten-Frame Stage (4x2)", "5 top + N bottom", 1, 5, 6, 7),
    CurriculumCrossReference("Big Ideas Math", "Kindergarten", "Chapter 5, Section 5.1", "Number Bonds to 10 on the Frame", "CCSS.MATH.K.OA.A.3", "Number Bond Stage (3x2)", "Part 1 in Y, Part 2 in X", 2, 8, 9, 10),
    CurriculumCrossReference("Big Ideas Math", "Kindergarten", "Chapter 7, Section 7.2", "Represent Addition as Putting Together", "CCSS.MATH.K.OA.A.1", "Number Bond Stage (3x2)", "[P1] [ENTER] [P2] [+]", 2, 8, 9, 10),
    # Grade 1
    CurriculumCrossReference("Big Ideas Math", "Grade 1", "Chapter 1, Section 1.4", "Part-Part-Whole Addition", "CCSS.MATH.1.OA.C.6", "Number Bond Stage (3x2)", "[4] [ENTER] [3] [+]", 2, 8, 9, 10),
    CurriculumCrossReference("Big Ideas Math", "Grade 1", "Chapter 2, Section 2.3", "Think Addition to Subtract", "CCSS.MATH.1.OA.B.4", "Number Bond Stage (3x2)", "[1][0] [ENTER] [6] [-]", 2, 8, 9, 10),
    CurriculumCrossReference("Big Ideas Math", "Grade 1", "Chapter 3, Section 3.1", "Doubles Strategies with ENTER", "CCSS.MATH.1.OA.C.6", "Number Rack (4x2)", "[6] [ENTER] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Big Ideas Math", "Grade 1", "Chapter 3, Section 3.2", "Doubles Plus 1 & Doubles Minus 1", "CCSS.MATH.1.OA.C.6", "Number Rack (4x2)", "[6] [ENTER] [+] [1] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Big Ideas Math", "Grade 1", "Chapter 3, Section 3.4", "Make a 10 to Add on Ten-Frame", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "[1][0] [ENTER] [7] [-]", 3, 11, 12, 13),
    CurriculumCrossReference("Big Ideas Math", "Grade 1", "Chapter 4, Section 4.2", "Use 10 to Subtract", "CCSS.MATH.1.OA.C.6", "Ten-Frame Stage (4x2)", "Bridging through 10", 3, 11, 12, 13),
    # Grade 2
    CurriculumCrossReference("Big Ideas Math", "Grade 2", "Chapter 1, Section 1.2", "Mental Math: Doubles & Near-Doubles", "CCSS.MATH.2.OA.B.2", "Number Rack (4x2)", "[N] [ENTER] [+]", 4, 14, 15, 16),
    CurriculumCrossReference("Big Ideas Math", "Grade 2", "Chapter 1, Section 1.4", "Make a Ten Addition Strategies", "CCSS.MATH.2.OA.B.2", "Ten-Frame Stage (4x2)", "Complements on frame", 3, 11, 12, 13),
    CurriculumCrossReference("Big Ideas Math", "Grade 2", "Chapter 3, Section 3.3", "Two-Digit Addition with Lift", "CCSS.MATH.2.NBT.B.5", "Stack Stage (3x3)", "Register lift on entry", 5, 17, 18, 19),
    # Grade 3
    CurriculumCrossReference("Big Ideas Math", "Grade 3", "Chapter 1, Section 1.3", "Multiplication as Repeated Addition", "CCSS.MATH.3.OA.A.1", "Stack Stage (3x3)", "[N] [ENTER] [+] [+]...", 5, 17, 18, 19),
    CurriculumCrossReference("Big Ideas Math", "Grade 3", "Chapter 8, Section 8.2", "Equal Parts & Unit Fractions", "CCSS.MATH.3.NF.A.1", "Fraction Studio (4x2)", "Block heights compare to 1", 6, 20, 21, 22),
    CurriculumCrossReference("Big Ideas Math", "Grade 3", "Chapter 8, Section 8.5", "Equivalent Fractions on Blocks", "CCSS.MATH.3.NF.A.3", "Fraction Studio (4x2)", "Equal tower heights", 6, 20, 21, 22),
    # Grade 4
    CurriculumCrossReference("Big Ideas Math", "Grade 4", "Chapter 3, Section 3.4", "Solve Multi-Step Word Problems", "CCSS.MATH.4.OA.A.3", "Stack Stage (3x3)", "[15] [ENTER] [6] [-] [3] [÷]", 5, 17, 18, 19),
    CurriculumCrossReference("Big Ideas Math", "Grade 4", "Chapter 3, Section 3.5", "Order of Operations Without Parens", "CCSS.MATH.4.OA.A.3", "Stack Stage (3x3)", "Auto-lift retains Y operand", 5, 17, 18, 19),
    CurriculumCrossReference("Big Ideas Math", "Grade 4", "Chapter 8, Section 8.3", "Add & Subtract Common Fractions", "CCSS.MATH.4.NF.B.3", "Fraction Studio (4x2)", "[. 1 . 4] [ENTER] [. 2 . 4] [+]", 6, 20, 21, 22),
    CurriculumCrossReference("Big Ideas Math", "Grade 4", "Chapter 8, Section 8.6", "Mixed Numbers: Two-Dot Entry", "CCSS.MATH.4.NF.B.3", "Fraction Studio (4x2)", "[2 . 1 . 2] = 2 1/2", 6, 20, 21, 22),
    # Grade 5
    CurriculumCrossReference("Big Ideas Math", "Grade 5", "Chapter 5, Section 5.2", "Add Fractions with Unlike Denominators", "CCSS.MATH.5.NF.A.1", "Fraction Studio (4x2)", "Common tower heights", 6, 20, 21, 22),
    CurriculumCrossReference("Big Ideas Math", "Grade 5", "Chapter 6, Section 6.2", "Multiply Fractions & Height Scaling", "CCSS.MATH.5.NF.B.4", "Fraction Studio (4x2)", "[. 3 . 4] [ENTER] [. 2 . 3] [×]", 6, 20, 21, 22),
    CurriculumCrossReference("Big Ideas Math", "Grade 5", "Chapter 6, Section 6.5", "Divide Fractions with Reciprocals", "CCSS.MATH.5.NF.B.7", "Fraction Studio (4x2)", "[¹/𝑥] inverts divisor", 6, 20, 21, 22),
    CurriculumCrossReference("Big Ideas Math", "Grade 5", "Chapter 12, Section 12.1", "Graphing Points on Coordinate Plane", "CCSS.MATH.5.G.A.1", "Coordinate Lab (4x4)", "Locate (x, y) with pegs", 8, 26, 27, 28),
    # Grade 6
    CurriculumCrossReference("Big Ideas Math", "Grade 6", "Chapter 1, Section 1.3", "Order of Operations & Syntax Trees", "CCSS.MATH.6.EE.A.2", "Expression Tree (4x3)", "Left-Right-Operator", 7, 23, 24, 25),
    CurriculumCrossReference("Big Ideas Math", "Grade 6", "Chapter 3, Section 3.2", "Writing Algebraic Expressions as Trees", "CCSS.MATH.6.EE.A.2", "Expression Tree (4x3)", "(a + b) * (c - d)", 7, 23, 24, 25),
    CurriculumCrossReference("Big Ideas Math", "Grade 6", "Chapter 3, Section 3.3", "Postorder Traversal Evaluation", "CCSS.MATH.6.EE.A.2", "Expression Tree (4x3)", "a b + c d - *", 7, 23, 24, 25),
    CurriculumCrossReference("Big Ideas Math", "Grade 6", "Chapter 6, Section 6.5", "Distance in the Coordinate Plane", "CCSS.MATH.6.NS.C.8", "Coordinate Lab (4x4)", "Δx and Δy run/rise", 8, 26, 27, 28),
    # Grade 7 & 8
    CurriculumCrossReference("Big Ideas Math", "Grade 7", "Chapter 1, Section 1.2", "Adding & Subtracting Rational Numbers", "CCSS.MATH.7.NS.A.1", "Stack Stage (3x3)", "Signed rational numbers", 5, 17, 18, 19),
    CurriculumCrossReference("Big Ideas Math", "Grade 7", "Chapter 3, Section 3.2", "Simplifying Multi-Operator Expressions", "CCSS.MATH.7.EE.A.1", "Expression Tree (4x3)", "Nested expressions", 7, 23, 24, 25),
    CurriculumCrossReference("Big Ideas Math", "Grade 8", "Chapter 4, Section 4.2", "Slope of a Line (Rise / Run)", "CCSS.MATH.8.EE.B.5", "Coordinate Lab (4x4)", "Rise in Y, Run in X, [÷]", 8, 26, 27, 28),
    CurriculumCrossReference("Big Ideas Math", "Grade 8", "Chapter 7, Section 7.3", "The Pythagorean Theorem", "CCSS.MATH.8.G.B.7", "Coordinate Lab (4x4)", "Δx² + Δy² = d²", 8, 26, 27, 28),
    CurriculumCrossReference("Big Ideas Math", "Grade 8", "Chapter 7, Section 7.5", "The Distance Formula Pipeline", "CCSS.MATH.8.G.B.8", "Coordinate Lab (4x4)", "[x1] [ENTER] [x2] [-] [x²]...", 8, 26, 27, 28),
    # High School Geometry
    CurriculumCrossReference("Big Ideas Math", "High School", "Geometry, Ch 9, Section 9.1", "Pythagorean Theorem & Run/Rise", "CCSS.MATH.HSG.SRT.C.8", "Coordinate Lab (4x4)", "Δx² + Δy² on pegboard", 8, 26, 27, 28),
    CurriculumCrossReference("Big Ideas Math", "High School", "Geometry, Ch 9, Section 9.4", "Tangent, Sine & Cosine Ratios", "CCSS.MATH.HSG.SRT.C.8", "Coordinate Lab (4x4)", "[sin], [cos], [tan]", 9, 29, 30, 31),
    CurriculumCrossReference("Big Ideas Math", "High School", "Geometry, Ch 9, Section 9.6", "Vectors in the Coordinate Plane", "CCSS.MATH.HSN.VM.A.1", "Coordinate Lab (4x4)", "Vector <x, y> run/rise", 9, 29, 30, 31),
    CurriculumCrossReference("Big Ideas Math", "High School", "Geometry, Ch 9, Section 9.7", "Polar Coordinates & Conversion", "CCSS.MATH.HSN.VM.A.1", "Coordinate Lab (4x4)", "[RUN] [ENTER] [RISE] [▸θ_r]", 9, 29, 30, 31),
    # High School Algebra 2 & Precalculus
    CurriculumCrossReference("Big Ideas Math", "High School", "Algebra 2, Ch 6, Section 6.1", "Exponential Growth Models", "CCSS.MATH.HSF.LE.A.1", "Stack Stage (3x3)", "Doubling tower heights", 10, 32, 33, 34),
    CurriculumCrossReference("Big Ideas Math", "High School", "Algebra 2, Ch 6, Section 6.2", "The Natural Base e & Compounding", "CCSS.MATH.HSF.LE.A.4", "Stack Stage (3x3)", "[r] [ENTER] [t] [×] [eˣ] [P] [×]", 10, 32, 33, 34),
    CurriculumCrossReference("Big Ideas Math", "High School", "Algebra 2, Ch 6, Section 6.3", "Logarithms as Inverse Functions", "CCSS.MATH.HSF.BF.B.5", "Stack Stage (3x3)", "[LN] inverts [eˣ]", 10, 32, 33, 34),
    CurriculumCrossReference("Big Ideas Math", "High School", "Algebra 2, Ch 6, Section 6.6", "Solving Doubling Time with [LN]", "CCSS.MATH.HSF.BF.B.5", "Stack Stage (3x3)", "t = ln(2) / r", 10, 32, 33, 34),
    CurriculumCrossReference("Big Ideas Math", "High School", "Precalculus, Ch 6, Section 6.1", "2D Vector Components & Magnitude", "CCSS.MATH.HSN.VM.A.1", "Coordinate Lab (4x4)", "[RUN] [ENTER] [RISE] [▸θ_r]", 9, 29, 30, 31),
    CurriculumCrossReference("Big Ideas Math", "High School", "Precalculus, Ch 6, Section 6.3", "Vector Addition & Resultants", "CCSS.MATH.HSN.VM.A.3", "Coordinate Lab (4x4)", "Component accumulation", 9, 29, 30, 31),
    # AP Statistics
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP Statistics, Unit 1, Topic 1.4", "Summary Statistics & [Σ+] Accumulation", "CCSS.MATH.HSS.ID.A.2", "Coordinate Lab (4x4)", "[Σ+] accumulates mean/std", 11, 35, 36, 37),
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP Statistics, Unit 4, Topic 4.1", "Counting Principles & Permutations", "CCSS.MATH.HSS.CP.B.9", "Expression Tree (4x3)", "nPr = n! / (n - r)!", 11, 35, 36, 37),
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP Statistics, Unit 4, Topic 4.2", "Combinations & Stack Factorials", "CCSS.MATH.HSS.CP.B.9", "Expression Tree (4x3)", "nCr via [yellow] [x!]", 11, 35, 36, 37),
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP Statistics, Unit 4, Topic 4.5", "Binomial Probability on the Stack", "CCSS.MATH.HSS.CP.B.9", "Stack Stage (3x3)", "Full precision binomial PDF", 11, 35, 36, 37),
    # AP Computer Science Principles
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP CSP, Big Idea 2, Topic 2.1", "Binary Number System & Bit Registers", "CCSS.MATH.PRACTICE.MP5", "Ten-Frame Stage (4x2)", "8-bit register pegs (0/1)", 12, 38, 39, 40),
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP CSP, Big Idea 2, Topic 2.2", "Hexadecimal Base Conversions", "CCSS.MATH.PRACTICE.MP5", "Stack Stage (3x3)", "[yellow] [BASE] cycles DEC/HEX", 12, 38, 39, 40),
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP CSP, Big Idea 2, Topic 2.3", "Boolean Logic: AND, OR, XOR Gates", "CCSS.MATH.PRACTICE.MP5", "Ten-Frame Stage (4x2)", "Truth tables with pegs", 12, 38, 39, 40),
    CurriculumCrossReference("AP Math / CS", "High School / AP", "AP CSP, Big Idea 2, Topic 2.4", "Bitmasking & Subnet Calculations", "CCSS.MATH.PRACTICE.MP5", "Stack Stage (3x3)", "192 AND 240 bitmasking", 12, 38, 39, 40),
]


def get_all_units():
    return CURRICULUM_UNITS


def get_unit_by_id(uid: str):
    for u in CURRICULUM_UNITS:
        if u.unit_id == uid:
            return u
    return None


def get_cross_references_by_curriculum(curr_name: str) -> List[CurriculumCrossReference]:
    return [cr for cr in CURRICULUM_CROSS_REFERENCES if cr.curriculum.lower() in curr_name.lower() or curr_name.lower() in cr.curriculum.lower()]


@dataclass
class ProficiencyProblem:
    index: int
    prompt: str
    expected_answer: str
    max_stack_depth: int
    keystrokes: List[str]
    hint: str


@dataclass
class ProficiencyTrial:
    trial_id: str
    unit_number: Optional[int]          # 1..12 or None for cumulative
    title: str
    subtitle: str
    stage_name: str
    max_stack_depth: int                # 1, 2, or 4
    time_limit_minutes: int             # 5, 10, 15, or 20 min
    problems: List[ProficiencyProblem]


PROFICIENCY_TRIALS: List[ProficiencyTrial] = [
    # -------------------------------------------------------------------------
    # Unit 1 Trial (Pre-K – K)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_1",
        unit_number=1,
        title="Unit 1 Time Trial: Step Counter & Accumulator Sprint",
        subtitle="Foundations of Counting, Cardinality & The One-More Step Counter",
        stage_name="Ten-Frame Stage (4x2)",
        max_stack_depth=1,
        time_limit_minutes=5,
        problems=[
            ProficiencyProblem(1, "1 + 1 + 1 (Count 3 steps)", "3", 1, ["1", "ENTER", "1", "+", "1", "+"], "Single register accumulator"),
            ProficiencyProblem(2, "5 + 1 + 1 (Start at 5, step 2)", "7", 1, ["5", "ENTER", "1", "+", "1", "+"], "Accumulate in X"),
            ProficiencyProblem(3, "Step count 4 items: start 0, step +1", "4", 1, ["1", "ENTER", "+", "+", "+"], "Repeat + key"),
            ProficiencyProblem(4, "Count 8 items with auto-lift", "8", 1, ["1", "ENTER", "+", "+", "+", "+", "+", "+", "+"], "Continuous + entry"),
            ProficiencyProblem(5, "Count down: start 6, step -1, step -1", "4", 1, ["6", "ENTER", "1", "-", "1", "-"], "Subtract step"),
            ProficiencyProblem(6, "Clear and count: C then 1+1+1+1+1", "5", 1, ["C", "1", "ENTER", "+", "+", "+", "+"], "Clear before count"),
            ProficiencyProblem(7, "Count by 2s: 2 + 2 + 2", "6", 1, ["2", "ENTER", "2", "+", "2", "+"], "Skip count by 2"),
            ProficiencyProblem(8, "Step count to ten: 7 + 1 + 1 + 1", "10", 1, ["7", "ENTER", "1", "+", "1", "+", "1", "+"], "Reach upper frame"),
            ProficiencyProblem(9, "Zero set: 0 + 9", "9", 1, ["0", "ENTER", "9", "+"], "Identity of zero"),
            ProficiencyProblem(10, "Count back from 10: 10 - 1 - 1 - 1", "7", 1, ["10", "ENTER", "1", "-", "1", "-", "1", "-"], "Decrement from 10"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 2 Trial (Grades K–1)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_2",
        unit_number=2,
        title="Unit 2 Time Trial: Part-Part-Whole & Stack Addition",
        subtitle="Number Bonds to 10 & 20 via Stack Registers Y and X",
        stage_name="Number Bond Stage (3x2)",
        max_stack_depth=2,
        time_limit_minutes=5,
        problems=[
            ProficiencyProblem(1, "Part 4, Part 3 -> Whole?", "7", 2, ["4", "ENTER", "3", "+"], "Y=4, X=3, [+] combines"),
            ProficiencyProblem(2, "Part 5, Part 5 -> Whole?", "10", 2, ["5", "ENTER", "5", "+"], "Ten bond"),
            ProficiencyProblem(3, "Whole 9, Part 6 -> Missing Part?", "3", 2, ["9", "ENTER", "6", "-"], "Decompose whole 9"),
            ProficiencyProblem(4, "Whole 10, Part 4 -> Missing Part?", "6", 2, ["10", "ENTER", "4", "-"], "Decompose whole 10"),
            ProficiencyProblem(5, "Part 8, Part 7 -> Whole?", "15", 2, ["8", "ENTER", "7", "+"], "Sum past ten"),
            ProficiencyProblem(6, "Whole 14, Part 8 -> Missing Part?", "6", 2, ["14", "ENTER", "8", "-"], "Decompose 14"),
            ProficiencyProblem(7, "Part 6, Part 7 -> Whole?", "13", 2, ["6", "ENTER", "7", "+"], "Part combination"),
            ProficiencyProblem(8, "Whole 18, Part 9 -> Missing Part?", "9", 2, ["18", "ENTER", "9", "-"], "Double decomposition"),
            ProficiencyProblem(9, "Part 12, Part 8 -> Whole?", "20", 2, ["12", "ENTER", "8", "+"], "Full twenty bond"),
            ProficiencyProblem(10, "Whole 25, Part 11 -> Missing Part?", "14", 2, ["25", "ENTER", "11", "-"], "Two-digit decompose"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 3 Trial (Grade 1)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_3",
        unit_number=3,
        title="Unit 3 Time Trial: Ten-Frames & Complements to 10",
        subtitle="5-Structure, Complements & Bridging Through 10",
        stage_name="Ten-Frame Stage (4x2)",
        max_stack_depth=2,
        time_limit_minutes=5,
        problems=[
            ProficiencyProblem(1, "Complement of 7 to 10", "3", 2, ["10", "ENTER", "7", "-"], "10 in Y, 7 in X"),
            ProficiencyProblem(2, "Complement of 4 to 10", "6", 2, ["10", "ENTER", "4", "-"], "10 in Y, 4 in X"),
            ProficiencyProblem(3, "Bridge: 8 + 5 = 8 + 2 + 3", "13", 2, ["8", "ENTER", "2", "+", "3", "+"], "Bridge through 10"),
            ProficiencyProblem(4, "Bridge: 9 + 6 = 9 + 1 + 5", "15", 2, ["9", "ENTER", "1", "+", "5", "+"], "Bridge through 10"),
            ProficiencyProblem(5, "Bridge: 7 + 6 = 7 + 3 + 3", "13", 2, ["7", "ENTER", "3", "+", "3", "+"], "Bridge through 10"),
            ProficiencyProblem(6, "Complement of 1 to 10", "9", 2, ["10", "ENTER", "1", "-"], "10 in Y, 1 in X"),
            ProficiencyProblem(7, "Double frame: 20 - 7", "13", 2, ["20", "ENTER", "7", "-"], "Subtract across 2 frames"),
            ProficiencyProblem(8, "Bridge: 8 + 7 = 8 + 2 + 5", "15", 2, ["8", "ENTER", "2", "+", "5", "+"], "Bridge through 10"),
            ProficiencyProblem(9, "Place value: 10 + 6", "16", 2, ["10", "ENTER", "6", "+"], "Teen number formation"),
            ProficiencyProblem(10, "Frame difference: 10 - 2", "8", 2, ["10", "ENTER", "2", "-"], "Ten complement"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 4 Trial (Grades 1–2)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_4",
        unit_number=4,
        title="Unit 4 Time Trial: Number Racks, Doubles & Groups",
        subtitle="5-Structure, Automatic Lift Duplication & Early Multiplication",
        stage_name="Number Rack (4x2)",
        max_stack_depth=2,
        time_limit_minutes=5,
        problems=[
            ProficiencyProblem(1, "Double 6: 6 ENTER +", "12", 2, ["6", "ENTER", "+"], "ENTER duplicates to Y"),
            ProficiencyProblem(2, "Double 8: 8 ENTER +", "16", 2, ["8", "ENTER", "+"], "ENTER duplicates to Y"),
            ProficiencyProblem(3, "Near-Double: 7 + 8", "15", 2, ["7", "ENTER", "+", "1", "+"], "Double 7 plus 1"),
            ProficiencyProblem(4, "Near-Double: 6 + 7", "13", 2, ["6", "ENTER", "+", "1", "+"], "Double 6 plus 1"),
            ProficiencyProblem(5, "Double 9: 9 ENTER +", "18", 2, ["9", "ENTER", "+"], "ENTER duplicates to Y"),
            ProficiencyProblem(6, "Near-Double: 8 + 9", "17", 2, ["8", "ENTER", "+", "1", "+"], "Double 8 plus 1"),
            ProficiencyProblem(7, "Equal groups: 3 groups of 4", "12", 2, ["4", "ENTER", "3", "×"], "Multiply group size"),
            ProficiencyProblem(8, "Equal groups: 4 groups of 5", "20", 2, ["5", "ENTER", "4", "×"], "Multiply group size"),
            ProficiencyProblem(9, "Double 12: 12 ENTER +", "24", 2, ["12", "ENTER", "+"], "ENTER duplicates to Y"),
            ProficiencyProblem(10, "Near-Double: 9 + 10", "19", 2, ["9", "ENTER", "+", "1", "+"], "Double 9 plus 1"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Cumulative Trial C1 (Primary Fundamentals: Units 1–4)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_cum_1",
        unit_number=None,
        title="Cumulative Trial C1: Primary Stack Fundamentals Championship",
        subtitle="Comprehensive Time Trial across Units 1–4 (Max Stack Depth 2)",
        stage_name="Gridfinity 4x4 Primary Desk Dock",
        max_stack_depth=2,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "Step count 7 items from 1", "7", 1, ["1", "ENTER", "+", "+", "+", "+", "+", "+"], "Accumulate in X"),
            ProficiencyProblem(2, "Number bond: 9 and 7 -> Whole?", "16", 2, ["9", "ENTER", "7", "+"], "Y=9, X=7"),
            ProficiencyProblem(3, "Decompose: Whole 17, Part 8", "9", 2, ["17", "ENTER", "8", "-"], "17 in Y, 8 in X"),
            ProficiencyProblem(4, "Complement of 3 to 10", "7", 2, ["10", "ENTER", "3", "-"], "Ten complement"),
            ProficiencyProblem(5, "Double 14: 14 ENTER +", "28", 2, ["14", "ENTER", "+"], "Duplicate to Y"),
            ProficiencyProblem(6, "Near-double: 11 + 12", "23", 2, ["11", "ENTER", "+", "1", "+"], "Double 11 plus 1"),
            ProficiencyProblem(7, "Bridge through 10: 9 + 8", "17", 2, ["9", "ENTER", "1", "+", "7", "+"], "Bridge with frame"),
            ProficiencyProblem(8, "Equal groups: 6 groups of 5", "30", 2, ["5", "ENTER", "6", "×"], "5 in Y, 6 in X"),
            ProficiencyProblem(9, "Decompose: Whole 30, Part 12", "18", 2, ["30", "ENTER", "12", "-"], "Missing part"),
            ProficiencyProblem(10, "Combined: Double 8 then add 5", "21", 2, ["8", "ENTER", "+", "5", "+"], "Chained operations"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 5 Trial (Grades 3–4)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_5",
        unit_number=5,
        title="Unit 5 Time Trial: 4-Register Stack & Four Operations",
        subtitle="T-Z-Y-X Flow, Automatic Lift & Parenthesis-Free Arithmetic",
        stage_name="Stack Stage (3x3)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "(18 - 6) × 3", "36", 4, ["18", "ENTER", "6", "-", "3", "×"], "Auto-lift pushes 12 to Y"),
            ProficiencyProblem(2, "(24 + 16) ÷ 8", "5", 4, ["24", "ENTER", "16", "+", "8", "÷"], "Sum in Y, divide by 8"),
            ProficiencyProblem(3, "45 ÷ (12 - 3)", "5", 4, ["45", "ENTER", "12", "ENTER", "3", "-", "÷"], "Push 45 to Y, sub in X"),
            ProficiencyProblem(4, "(15 × 4) + (18 ÷ 2)", "69", 4, ["15", "ENTER", "4", "×", "18", "ENTER", "2", "÷", "+"], "Two branch accumulation"),
            ProficiencyProblem(5, "(50 - 14) ÷ (3 + 6)", "4", 4, ["50", "ENTER", "14", "-", "3", "ENTER", "6", "+", "÷"], "Stack holds numerator in Y"),
            ProficiencyProblem(6, "12 × 5 - 8 × 4", "28", 4, ["12", "ENTER", "5", "×", "8", "ENTER", "4", "×", "-"], "Two branch subtraction"),
            ProficiencyProblem(7, "((20 - 8) × 4) ÷ 6", "8", 4, ["20", "ENTER", "8", "-", "4", "×", "6", "÷"], "Chained pipeline"),
            ProficiencyProblem(8, "72 ÷ (4 + 5) × 3", "24", 4, ["72", "ENTER", "4", "ENTER", "5", "+", "÷", "3", "×"], "Parenthesis-free stack"),
            ProficiencyProblem(9, "100 - (16 × 5 - 12)", "32", 4, ["100", "ENTER", "16", "ENTER", "5", "×", "12", "-", "-"], "Deep stack evaluate"),
            ProficiencyProblem(10, "(8 + 4) × (9 - 3) ÷ 12", "6", 4, ["8", "ENTER", "4", "+", "9", "ENTER", "3", "-", "×", "12", "÷"], "Multi-step evaluate"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 6 Trial (Grades 4–5)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_6",
        unit_number=6,
        title="Unit 6 Time Trial: Fraction Studio & Mixed Numbers",
        subtitle="Two-Dot Notation, Reciprocals & Height Equivalence",
        stage_name="Fraction Studio (4x2)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "1/2 + 1/4 (Two-dot entry)", "0.75", 4, [".1.2", "ENTER", ".1.4", "+"], "Decimal equivalent 0.75"),
            ProficiencyProblem(2, "3/4 - 1/2", "0.25", 4, [".3.4", "ENTER", ".1.2", "-"], "Decimal equivalent 0.25"),
            ProficiencyProblem(3, "Mixed: 2 1/2 + 1 1/4", "3.75", 4, ["2.1.2", "ENTER", "1.1.4", "+"], "Mixed number addition"),
            ProficiencyProblem(4, "Reciprocal of 4/5: .4.5 [1/x]", "1.25", 4, [".4.5", "1/x"], "Reciprocal key"),
            ProficiencyProblem(5, "3/8 + 1/4", "0.625", 4, [".3.8", "ENTER", ".1.4", "+"], "Three eighths plus fourth"),
            ProficiencyProblem(6, "2/3 × 3/4", "0.5", 4, [".2.3", "ENTER", ".3.4", "×"], "Fraction multiplication"),
            ProficiencyProblem(7, "3/4 ÷ 1/2", "1.5", 4, [".3.4", "ENTER", ".1.2", "÷"], "Fraction division"),
            ProficiencyProblem(8, "1 1/2 × 4", "6", 4, ["1.1.2", "ENTER", "4", "×"], "Mixed scaling"),
            ProficiencyProblem(9, "5 - 2 3/4", "2.25", 4, ["5", "ENTER", "2.3.4", "-"], "Subtract mixed number"),
            ProficiencyProblem(10, "(1/3 + 1/6) × 12", "6", 4, [".1.3", "ENTER", ".1.6", "+", "12", "×"], "Combined fraction pipeline"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 7 Trial (Grades 5–6)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_7",
        unit_number=7,
        title="Unit 7 Time Trial: Expression Trees & Postorder Traversal",
        subtitle="Binary Syntax Trees, Postorder Traversal & Parenthesis Elimination",
        stage_name="Expression Tree (4x3)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "(8 + 2) × (9 - 4)", "50", 4, ["8", "ENTER", "2", "+", "9", "ENTER", "4", "-", "×"], "Left-Right-Multiply"),
            ProficiencyProblem(2, "((14 - 6) × 3) + (24 ÷ 4)", "30", 4, ["14", "ENTER", "6", "-", "3", "×", "24", "ENTER", "4", "÷", "+"], "Two subtree combine"),
            ProficiencyProblem(3, "(30 - (4 × 5)) × (12 ÷ (2 + 4))", "20", 4, ["30", "ENTER", "4", "ENTER", "5", "×", "-", "12", "ENTER", "2", "ENTER", "4", "+", "÷", "×"], "Deep nested subtrees"),
            ProficiencyProblem(4, "(5 + 3) × (8 - 2) ÷ (6 - 2)", "12", 4, ["5", "ENTER", "3", "+", "8", "ENTER", "2", "-", "×", "6", "ENTER", "2", "-", "÷"], "Three branch traversal"),
            ProficiencyProblem(5, "((18 ÷ 3) + 4) × ((15 - 7) ÷ 2)", "40", 4, ["18", "ENTER", "3", "÷", "4", "+", "15", "ENTER", "7", "-", "2", "÷", "×"], "Postorder multiplication"),
            ProficiencyProblem(6, "(10 + 5 × 2) ÷ (12 - 2 × 4)", "5", 4, ["10", "ENTER", "5", "ENTER", "2", "×", "+", "12", "ENTER", "2", "ENTER", "4", "×", "-", "÷"], "Eliminating PEMDAS ambiguity"),
            ProficiencyProblem(7, "(25 - 5 × 3) × (4 + 6 ÷ 2)", "70", 4, ["25", "ENTER", "5", "ENTER", "3", "×", "-", "4", "ENTER", "6", "ENTER", "2", "÷", "+", "×"], "Nested tree traversal"),
            ProficiencyProblem(8, "((7 + 3) × 4 - 8) ÷ 4", "8", 4, ["7", "ENTER", "3", "+", "4", "×", "8", "-", "4", "÷"], "Chained operations"),
            ProficiencyProblem(9, "(48 ÷ (2 + 6)) × (15 - 3 × 3)", "36", 4, ["48", "ENTER", "2", "ENTER", "6", "+", "÷", "15", "ENTER", "3", "ENTER", "3", "×", "-", "×"], "Tree sub-expression"),
            ProficiencyProblem(10, "(16 - (4 + 2)) × (18 ÷ (3 × 2))", "30", 4, ["16", "ENTER", "4", "ENTER", "2", "+", "-", "18", "ENTER", "3", "ENTER", "2", "×", "÷", "×"], "Stack tree depth 4"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 8 Trial (Grades 7–8)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_8",
        unit_number=8,
        title="Unit 8 Time Trial: Coordinate Lab & Pythagorean Distance",
        subtitle="Cartesian Pegboards, Euclidean Distance Pipeline & Slope",
        stage_name="Coordinate Lab (4x4)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "Δx = 3, Δy = 4 -> Distance d", "5", 4, ["3", "x²", "4", "x²", "+", "√𝑥"], "Pythagorean triple (3,4,5)"),
            ProficiencyProblem(2, "Δx = 6, Δy = 8 -> Distance d", "10", 4, ["6", "x²", "8", "x²", "+", "√𝑥"], "Scaled triple (6,8,10)"),
            ProficiencyProblem(3, "Δx = 5, Δy = 12 -> Distance d", "13", 4, ["5", "x²", "12", "x²", "+", "√𝑥"], "Pythagorean triple (5,12,13)"),
            ProficiencyProblem(4, "P1(1, 2) to P2(4, 6) -> Distance", "5", 4, ["4", "ENTER", "1", "-", "x²", "6", "ENTER", "2", "-", "x²", "+", "√𝑥"], "Full distance formula"),
            ProficiencyProblem(5, "P1(2, 3) to P2(8, 11) -> Distance", "10", 4, ["8", "ENTER", "2", "-", "x²", "11", "ENTER", "3", "-", "x²", "+", "√𝑥"], "Full distance formula"),
            ProficiencyProblem(6, "Slope m: Rise 12, Run 4", "3", 4, ["12", "ENTER", "4", "÷"], "Rise in Y, Run in X"),
            ProficiencyProblem(7, "Slope m: P1(2, 5) to P2(6, 17)", "3", 4, ["17", "ENTER", "5", "-", "6", "ENTER", "2", "-", "÷"], "Δy ÷ Δx"),
            ProficiencyProblem(8, "Hypotenuse: legs 9 and 12", "15", 4, ["9", "x²", "12", "x²", "+", "√𝑥"], "Leg accumulation"),
            ProficiencyProblem(9, "Δx = 8, Δy = 15 -> Distance d", "17", 4, ["8", "x²", "15", "x²", "+", "√𝑥"], "Triple (8,15,17)"),
            ProficiencyProblem(10, "P1(0, 0) to P2(7, 24) -> Distance", "25", 4, ["7", "x²", "24", "x²", "+", "√𝑥"], "Triple (7,24,25)"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Cumulative Trial C2 (Intermediate Mastery: Units 1–8)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_cum_2",
        unit_number=None,
        title="Cumulative Trial C2: Intermediate Stack Mastery Championship",
        subtitle="Comprehensive Time Trial across Units 1–8 (Max Stack Depth 4)",
        stage_name="Stack Stage & Expression Tree Hub",
        max_stack_depth=4,
        time_limit_minutes=15,
        problems=[
            ProficiencyProblem(1, "(32 - 14) × 5 ÷ 6", "15", 4, ["32", "ENTER", "14", "-", "5", "×", "6", "÷"], "Auto-lift chaining"),
            ProficiencyProblem(2, "3/4 + 1/2 × 1/4 (order of ops)", "0.875", 4, [".1.2", "ENTER", ".1.4", "×", ".3.4", "+"], "Fractions on stack"),
            ProficiencyProblem(3, "Distance: P1(3, 4) to P2(9, 12)", "10", 4, ["9", "ENTER", "3", "-", "x²", "12", "ENTER", "4", "-", "x²", "+", "√𝑥"], "Pythagorean distance"),
            ProficiencyProblem(4, "Mixed: 3 1/2 - 1 3/4", "1.75", 4, ["3.1.2", "ENTER", "1.3.4", "-"], "Two-dot fraction subtraction"),
            ProficiencyProblem(5, "Expression tree: ((15+5)×(8-3))÷10", "10", 4, ["15", "ENTER", "5", "+", "8", "ENTER", "3", "-", "×", "10", "÷"], "Tree postorder"),
            ProficiencyProblem(6, "Double 18 then sub 9", "27", 4, ["18", "ENTER", "+", "9", "-"], "Duplicate to Y"),
            ProficiencyProblem(7, "Slope: P1(-1, -2) to P2(3, 10)", "3", 4, ["10", "ENTER", "2", "+/-", "-", "3", "ENTER", "1", "+/-", "-", "÷"], "Negative coordinates"),
            ProficiencyProblem(8, "Four operations: 80 - 15 × 4 + 12", "32", 4, ["80", "ENTER", "15", "ENTER", "4", "×", "-", "12", "+"], "RPN stack evaluation"),
            ProficiencyProblem(9, "Reciprocal sum: 1/(1/4 + 1/6)", "2.4", 4, [".1.4", "ENTER", ".1.6", "+", "1/x"], "Reciprocal pipeline"),
            ProficiencyProblem(10, "Distance from origin to (12, 16)", "20", 4, ["12", "x²", "16", "x²", "+", "√𝑥"], "Radial distance"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 9 Trial (Grades 9–11)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_9",
        unit_number=9,
        title="Unit 9 Time Trial: Trigonometry, Vectors & Polar Pipeline",
        subtitle="Right Triangles, Polar Conversions & Vector Decomposition",
        stage_name="Coordinate Lab (4x4)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "sin(30°)", "0.5", 4, ["30", "SIN"], "Basic sine ratio"),
            ProficiencyProblem(2, "cos(60°)", "0.5", 4, ["60", "COS"], "Basic cosine ratio"),
            ProficiencyProblem(3, "tan(45°)", "1", 4, ["45", "TAN"], "Tangent ratio"),
            ProficiencyProblem(4, "Hypotenuse 10, angle 30° -> Opposite (y)", "5", 4, ["10", "ENTER", "30", "SIN", "×"], "Opposite = h × sin(θ)"),
            ProficiencyProblem(5, "Adjacent (x): Hypotenuse 12, angle 60°", "6", 4, ["12", "ENTER", "60", "COS", "×"], "Adjacent = h × cos(θ)"),
            ProficiencyProblem(6, "Polar to Rect: r=10, θ=0° -> x", "10", 4, ["10", "ENTER", "0", "yellow", "▸y,x"], "Polar conversion key"),
            ProficiencyProblem(7, "Rect to Polar: x=3, y=4 -> magnitude r", "5", 4, ["3", "ENTER", "4", "yellow", "▸θ,r"], "Vector magnitude"),
            ProficiencyProblem(8, "Rect to Polar: x=5, y=12 -> magnitude r", "13", 4, ["5", "ENTER", "12", "yellow", "▸θ,r"], "Vector magnitude"),
            ProficiencyProblem(9, "Vector magnitude: components 8 and 6", "10", 4, ["8", "ENTER", "6", "yellow", "▸θ,r"], "Polar magnitude"),
            ProficiencyProblem(10, "asin(0.5) in degrees", "30", 4, [".5", "yellow", "ASIN"], "Inverse sine"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 10 Trial (Grades 10–12)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_10",
        unit_number=10,
        title="Unit 10 Time Trial: Exponential Growth & Logarithms",
        subtitle="Natural Base e, Continuous Compounding & Doubling Time",
        stage_name="Stack Stage (3x3)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "2^5 (Power key)", "32", 4, ["2", "ENTER", "5", "yˣ"], "y to power x"),
            ProficiencyProblem(2, "3^4 (Power key)", "81", 4, ["3", "ENTER", "4", "yˣ"], "y to power x"),
            ProficiencyProblem(3, "ln(e)", "1", 4, ["1", "eˣ", "LN"], "Natural log inverse"),
            ProficiencyProblem(4, "e^0", "1", 4, ["0", "eˣ"], "Base e exponent"),
            ProficiencyProblem(5, "log10(1000)", "3", 4, ["1000", "yellow", "LOG"], "Common log"),
            ProficiencyProblem(6, "Compound: 1000 × (1.05)^2", "1102.5", 4, ["1000", "ENTER", "1.05", "ENTER", "2", "yˣ", "×"], "Annual compounding"),
            ProficiencyProblem(7, "Doubling time: ln(2) ÷ 0.07", "9.9021", 4, ["2", "LN", ".07", "÷"], "Continuous doubling rule"),
            ProficiencyProblem(8, "Half-life: 100 × (0.5)^3", "12.5", 4, ["100", "ENTER", ".5", "ENTER", "3", "yˣ", "×"], "Decay model"),
            ProficiencyProblem(9, "Continuous: 500 × e^(0.04 × 5)", "610.7014", 4, [".04", "ENTER", "5", "×", "eˣ", "500", "×"], "P e^(rt) formula"),
            ProficiencyProblem(10, "2^10", "1024", 4, ["2", "ENTER", "10", "yˣ"], "Powers of two"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 11 Trial (Grades 11–12 / AP)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_11",
        unit_number=11,
        title="Unit 11 Time Trial: Combinatorics, Stats & Probability",
        subtitle="Factorials, Permutations, Combinations & [Σ+] Accumulation",
        stage_name="Coordinate Lab (4x4)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "5! (Factorial)", "120", 4, ["5", "yellow", "x!"], "x factorial key"),
            ProficiencyProblem(2, "6! (Factorial)", "720", 4, ["6", "yellow", "x!"], "x factorial key"),
            ProficiencyProblem(3, "Permutations P(5, 2) = 5! / 3!", "20", 4, ["5", "yellow", "x!", "3", "yellow", "x!", "÷"], "Stack permutation"),
            ProficiencyProblem(4, "Permutations P(6, 3) = 6! / 3!", "120", 4, ["6", "yellow", "x!", "3", "yellow", "x!", "÷"], "Stack permutation"),
            ProficiencyProblem(5, "Combinations C(5, 2) = 5! / (2! × 3!)", "10", 4, ["5", "yellow", "x!", "2", "yellow", "x!", "3", "yellow", "x!", "×", "÷"], "n choose r"),
            ProficiencyProblem(6, "Combinations C(6, 2) = 6! / (2! × 4!)", "15", 4, ["6", "yellow", "x!", "2", "yellow", "x!", "4", "yellow", "x!", "×", "÷"], "n choose r"),
            ProficiencyProblem(7, "Combinations C(7, 3) = 7! / (3! × 4!)", "35", 4, ["7", "yellow", "x!", "3", "yellow", "x!", "4", "yellow", "x!", "×", "÷"], "n choose r"),
            ProficiencyProblem(8, "Series sum 1+2+3+4+5 via [Σ+]", "15", 4, ["1", "Σ+", "2", "Σ+", "3", "Σ+", "4", "Σ+", "5", "Σ+"], "Statistical summation"),
            ProficiencyProblem(9, "4! (Factorial)", "24", 4, ["4", "yellow", "x!"], "x factorial key"),
            ProficiencyProblem(10, "Probability: 1 ÷ C(6, 2)", "0.0667", 4, ["6", "yellow", "x!", "2", "yellow", "x!", "4", "yellow", "x!", "×", "÷", "1/x"], "Reciprocal combination"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Unit 12 Trial (Grades 9–12 / AP CS)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_12",
        unit_number=12,
        title="Unit 12 Time Trial: Digital Logic, Base Conversions & CS",
        subtitle="HEX/DEC/OCT/BIN Radix Modes & Bitwise AND, OR, XOR Operations",
        stage_name="Ten-Frame Stage (4x2)",
        max_stack_depth=4,
        time_limit_minutes=10,
        problems=[
            ProficiencyProblem(1, "DEC 255 to HEX", "FF", 4, ["255", "yellow", "BASE", "HEX"], "Radix mode cycle"),
            ProficiencyProblem(2, "HEX 10 to DEC", "16", 4, ["HEX", "10", "yellow", "BASE", "DEC"], "Hex to decimal"),
            ProficiencyProblem(3, "DEC 15 to BIN", "1111", 4, ["15", "yellow", "BASE", "BIN"], "Dec to binary"),
            ProficiencyProblem(4, "BIN 1010 to DEC", "10", 4, ["BIN", "1010", "yellow", "BASE", "DEC"], "Bin to decimal"),
            ProficiencyProblem(5, "Bitwise AND: 12 AND 10", "8", 4, ["12", "ENTER", "10", "AND"], "1100 AND 1010 = 1000"),
            ProficiencyProblem(6, "Bitwise OR: 12 OR 10", "14", 4, ["12", "ENTER", "10", "OR"], "1100 OR 1010 = 1110"),
            ProficiencyProblem(7, "Bitwise XOR: 12 XOR 10", "6", 4, ["12", "ENTER", "10", "XOR"], "1100 XOR 1010 = 0110"),
            ProficiencyProblem(8, "HEX 20 to DEC", "32", 4, ["HEX", "20", "yellow", "BASE", "DEC"], "Hex 20 is 32"),
            ProficiencyProblem(9, "DEC 64 to OCT", "100", 4, ["64", "yellow", "BASE", "OCT"], "Dec 64 is octal 100"),
            ProficiencyProblem(10, "Bitwise AND: 255 AND 15", "15", 4, ["255", "ENTER", "15", "AND"], "Low nybble mask"),
        ]
    ),
    # -------------------------------------------------------------------------
    # Cumulative Trial C3 (Master All-Level Championship: Units 1–12)
    # -------------------------------------------------------------------------
    ProficiencyTrial(
        trial_id="trial_cum_3",
        unit_number=None,
        title="Cumulative Trial C3: Grand RPN Invitational Championship",
        subtitle="Master UIL-Style Time Trial across Units 1–12 (Complete Architecture)",
        stage_name="Master Gridfinity Classroom Ecosystem",
        max_stack_depth=4,
        time_limit_minutes=20,
        problems=[
            ProficiencyProblem(1, "Compound pipeline: 250 × (1 + .06/12)^24", "281.79", 4, [".06", "ENTER", "12", "÷", "1", "+", "24", "yˣ", "250", "×"], "TVM compounding"),
            ProficiencyProblem(2, "Pythagorean distance: P1(-3, 5) to P2(5, -10)", "17", 4, ["5", "ENTER", "3", "+/-", "-", "x²", "10", "+/-", "ENTER", "5", "-", "x²", "+", "√𝑥"], "Coordinate lab triple"),
            ProficiencyProblem(3, "Polar vector: 12 cos(45°) + 5 sin(45°)", "12.0208", 4, ["12", "ENTER", "45", "COS", "×", "5", "ENTER", "45", "SIN", "×", "+"], "Vector projection"),
            ProficiencyProblem(4, "Fractions: 3 1/3 ÷ 1 1/4 + 2/5", "3.0667", 4, ["3.1.3", "ENTER", "1.1.4", "÷", ".2.5", "+"], "Mixed operations"),
            ProficiencyProblem(5, "Combinations: C(8, 3) = 8! / (3! × 5!)", "56", 4, ["8", "yellow", "x!", "3", "yellow", "x!", "5", "yellow", "x!", "×", "÷"], "Lottery combination"),
            ProficiencyProblem(6, "Exponential: 1500 × e^(0.05 × 10)", "2473.08", 4, [".05", "ENTER", "10", "×", "eˣ", "1500", "×"], "Continuous growth"),
            ProficiencyProblem(7, "Postorder tree: ((35-7)×4)÷(14+2)", "7", 4, ["35", "ENTER", "7", "-", "4", "×", "14", "ENTER", "2", "+", "÷"], "Parenthesis elimination"),
            ProficiencyProblem(8, "Bitmasking: 192 AND 240 (Subnet mask)", "192", 4, ["192", "ENTER", "240", "AND"], "Network bitwise logic"),
            ProficiencyProblem(9, "Double & near-double sum: (6 ENTER +) + (8 ENTER + 1 +)", "29", 4, ["6", "ENTER", "+", "8", "ENTER", "+", "1", "+", "+"], "Stack auto-lift chain"),
            ProficiencyProblem(10, "Radix conversion: DEC 4095 to HEX", "FFF", 4, ["4095", "yellow", "BASE", "HEX"], "Maximum 12-bit hex"),
        ]
    ),
]


def get_all_trials() -> List[ProficiencyTrial]:
    return PROFICIENCY_TRIALS



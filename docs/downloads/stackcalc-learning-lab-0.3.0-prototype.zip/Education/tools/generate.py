"""Generate outlined, 1:1 SVGs and independent OpenSCAD manufacturing sources.

Revision 0.3.0:
- OpenSCAD models include debossed inset text (0.6 mm depth)
- Gridfinity baseplate and modular tray plugs
- Fast single-operation FDM printing (PLA/PETG) without laser engraving
"""
import argparse
import html
import json
import math
from pathlib import Path

import reportlab
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.transformPen import TransformPen

from catalog import catalog, manifest, laser_setups, INK, TEAL, PAPER, REVISION

FONT_DIR = Path(reportlab.__file__).parent / "fonts"


class Lettering:
    def __init__(self):
        self.fonts = {b: TTFont(FONT_DIR / ("VeraBd.ttf" if b else "Vera.ttf")) for b in (False, True)}

    def outline(self, label):
        font = self.fonts[label["bold"]]
        glyphs, cmap = font.getGlyphSet(), font.getBestCmap()
        scale = label["size"] / font["head"].unitsPerEm
        names = [cmap.get(ord(c), cmap.get(ord(" "))) for c in label["text"]]
        width = sum(glyphs[n].width for n in names) * scale
        x = label["x"] - (width / 2 if label["align"] == "center" else 0)
        origin, paths, bounds = x, [], []
        for name in names:
            pen = SVGPathPen(glyphs, ntos=lambda v: f"{v:.5f}".rstrip("0").rstrip(".") if v else "0")
            glyphs[name].draw(TransformPen(pen, (scale, 0, 0, -scale, x, label["y"])))
            bp = BoundsPen(glyphs)
            glyphs[name].draw(bp)
            if bp.bounds:
                a, b, c, d = bp.bounds
                bounds.append((x + a * scale, label["y"] - d * scale, x + c * scale, label["y"] - b * scale))
            if pen.getCommands():
                paths.append(f'<path d="{pen.getCommands()}"/>')
            x += glyphs[name].width * scale
        return "".join(paths), bounds, (origin, width)


def shape_svg(s, fill="none", stroke="none", width=0.1):
    common = f'fill="{fill}" stroke="{stroke}" stroke-width="{width}"'
    if s["kind"] == "circle":
        return f'<circle cx="{s["x"]}" cy="{s["y"]}" r="{s["r"]}" {common}/>'
    return f'<rect x="{s["x"]}" y="{s["y"]}" width="{s["w"]}" height="{s["h"]}" rx="{s["r"]}" {common}/>'


def svg(p, content, description):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{p.width}mm" height="{p.height}mm" '
            f'viewBox="0 0 {p.width} {p.height}"><title>{html.escape(p.title)}</title>'
            f'<desc>{html.escape(description)}</desc>{content}</svg>\n')


def write_changed(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.read_text() != content:
        path.write_text(content)


def scad_shape(s, height):
    if s["kind"] == "circle":
        return f'translate([{s["x"]},{height-s["y"]}]) circle(r={s["r"]});'
    return (f'translate([{s["x"]},{height-s["y"]-s["h"]}]) '
            f'offset(r={s["r"]}) translate([{s["r"]},{s["r"]}]) '
            f'square([{s["w"]-2*s["r"]},{s["h"]-2*s["r"]}]);')


def scad(p):
    def esc(text):
        return text.replace('\\', '\\\\').replace('"', '\\"')

    # 1. Fraction blocks: 45 pieces across 9 vertical towers with sacrificial tear-off supports
    if p.id == "fraction_blocks":
        towers = []
        for gy in range(3):
            for gx in range(3):
                d = 1 + gx + gy * 3
                cx = 0.25 + 41.5 / 2.0 + gx * 42.0
                cy = p.height - (0.25 + 41.5 / 2.0 + gy * 42.0)
                towers.append(f'fraction_tower({cx:.2f}, {cy:.2f}, {d});')
        return f'''// StackCalc Learning Lab {REVISION} / {p.id}
// 45 Stackable Fraction Blocks across 9 Vertical Towers with Sacrificial Tear-Off Supports.
// Single-plate 3x3 print layout ({p.width} x {p.height} mm).
$fn = 16;
base_height = {p.thickness};
inset_depth = {p.inset_depth};

module rounded_square(dim, r=2, h=1) {{
    linear_extrude(h) offset(r) offset(-r) square([dim[0], dim[1]], center=true);
}}
module gridfinity_base() {{
    hull() {{
        rounded_square([35.6, 35.6], r=1.6, h=0.8);
        translate([0,0,2.0]) rounded_square([40.4, 40.4], r=3.2, h=0.8);
    }}
    translate([0,0,2.0]) rounded_square([41.5, 41.5], r=3.75, h=1.0);
}}
module block_stacking_socket() {{
    hull() {{
        translate([0,0,-0.01]) rounded_square([36.0, 36.0], r=1.8, h=0.8);
        translate([0,0,1.8]) rounded_square([40.5, 40.5], r=3.3, h=0.6);
    }}
    translate([0,0,1.8]) rounded_square([40.5, 40.5], r=3.3, h=1.3);
}}

module bottom_hollow_core(h) {{
    ch = h - 4.5;
    if (ch >= 4.0) {{
        roof_h = min(ch * 0.4, 7.0);
        body_h = ch - roof_h;
        translate([0, 0, -0.01]) {{
            hull() {{
                rounded_square([30.0, 30.0], r=2.0, h=body_h);
                translate([0, 0, body_h])
                    rounded_square([4.0, 4.0], r=1.0, h=roof_h);
            }}
        }}
    }}
}}

module single_block(h, label) {{
    difference() {{
        union() {{
            gridfinity_base();
            translate([0,0,3.0 - 0.01]) rounded_square([41.5, 41.5], r=3.75, h=h-3.0+0.01);
        }}
        translate([0,0,h-3.0]) block_stacking_socket();
        bottom_hollow_core(h);
        translate([0,0,h-3.0-0.6]) linear_extrude(0.61)
            text(label, size=5.5, font="Liberation Sans:style=Bold", halign="center", valign="center");
        if (h >= 14) {{
            translate([0, -41.5/2 + 0.6, 3.0 + (h - 3.0)/2])
                rotate([90, 0, 0])
                    linear_extrude(0.61)
                        text(label, size=min((h-4)*0.45, 7.5), font="Liberation Sans:style=Bold", halign="center", valign="center");
        }}
    }}
}}

// Sacrificial support structure rooted firmly on the lower block's socket floor (z = h - 3.0)
// and outer rim (z = h), eliminating floating overhangs entirely.
module inter_block_support(h) {{
    union() {{
        // 4 vertical pillars rooted directly on the socket floor at z = h - 3.0
        for (sx = [-13, 13]) {{
            for (sy = [-13, 13]) {{
                translate([sx, sy, h - 3.0 - 0.01]) {{
                    cylinder(r1=1.2, r2=2.4, h=0.6);
                    translate([0, 0, 0.6])
                        cylinder(r=2.4, h=2.41);
                }}
            }}
        }}
        // Perimeter release platform at z = h resting on the 4 pillars
        difference() {{
            translate([0, 0, h - 0.01])
                rounded_square([36.0, 36.0], r=2.0, h=0.42);
            translate([0, 0, h - 0.02])
                rounded_square([29.0, 29.0], r=1.8, h=0.45);
        }}

        // 4 corner bridge tabs resting directly on the solid outer rim of the lower block
        for (a = [45, 135, 225, 315]) {{
            rotate([0, 0, a]) {{
                translate([17.0, 0, h - 0.01])
                    rounded_square([8.0, 3.0], r=0.8, h=0.42);
            }}
        }}
    }}
}}

module fraction_tower(cx, cy, d) {{
    h = 84.0 / d;
    label = (d == 1) ? "1" : str("1/", d);
    t_gap = 0.4;
    translate([cx, cy, 0]) {{
        union() {{
            for (k = [0 : d - 1]) {{
                zk = k * (h + t_gap);
                translate([0, 0, zk]) single_block(h, label);
                if (k < d - 1) {{
                    translate([0, 0, zk])
                        inter_block_support(h);
                }}
            }}
        }}
    }}
}}

{"\n".join(towers)}
'''

    # 2. Ten-frame mini-blocks: Quarter-width (21 mm) stackable mini-blocks
    if p.id == "ten_frame_dots":
        dots = []
        for s, l in zip(p.bodies, p.labels):
            cx = s["x"] + s["w"] / 2.0
            cy = p.height - s["y"] - s["h"] / 2.0
            dots.append(f'miniblock({cx:.2f}, {cy:.2f}, {p.thickness:.2f}, "{esc(l["text"])}");')
        return f'''// StackCalc Learning Lab {REVISION} / {p.id}
// Quarter-width (21 mm) Gridfinity mini-blocks.
$fn = 16;
base_height = {p.thickness};
inset_depth = {p.inset_depth};

module rounded_square(dim, r=2, h=1) {{
    linear_extrude(h) offset(r) offset(-r) square([dim[0], dim[1]], center=true);
}}
module miniblock_base() {{
    hull() {{
        rounded_square([17.0, 17.0], r=0.8, h=0.5);
        translate([0,0,0.8]) rounded_square([19.5, 19.5], r=1.6, h=0.5);
    }}
    translate([0,0,1.0]) rounded_square([20.5, 20.5], r=1.8, h=0.85);
}}
module miniblock_stacking_socket() {{
    hull() {{
        rounded_square([17.4, 17.4], r=0.9, h=0.5);
        translate([0,0,0.8]) rounded_square([19.8, 19.8], r=1.6, h=0.5);
    }}
    translate([0,0,0.8]) rounded_square([19.8, 19.8], r=1.6, h=1.05);
}}
module miniblock(cx, cy, h, label) {{
    translate([cx, cy, 0]) {{
        difference() {{
            union() {{
                miniblock_base();
                translate([0,0,1.8 - 0.01]) rounded_square([20.5, 20.5], r=1.8, h=h-1.8+0.01);
            }}
            translate([0,0,h-1.8]) miniblock_stacking_socket();
            translate([0,0,h-1.8-0.6]) linear_extrude(0.61)
                text(label, size=5, font="Liberation Sans:style=Bold", halign="center", valign="center");
        }}
    }}
}}

{"\n".join(dots)}
'''

    # 3. Fraction bin: 3x3 Gridfinity 12U bin with stacking lip & wall height guides
    if p.is_fraction_bin:
        floor_h = 2.4
        lip_h = 4.4
        gf_plugs = []
        for gx in range(p.gridfinity_x):
            for gy in range(p.gridfinity_y):
                cx = (p.width / 2.0) + (gx - (p.gridfinity_x - 1) / 2.0) * 42.0
                cy = (p.height / 2.0) + (gy - (p.gridfinity_y - 1) / 2.0) * 42.0
                gf_plugs.append(f'translate([{cx:.2f}, {cy:.2f}, -3.0]) gridfinity_unit_base();')

        floor_sockets = []
        for gx in range(p.gridfinity_x):
            for gy in range(p.gridfinity_y):
                cx = (p.width / 2.0) + (gx - (p.gridfinity_x - 1) / 2.0) * 42.0
                cy = (p.height / 2.0) + (gy - (p.gridfinity_y - 1) / 2.0) * 42.0
                floor_sockets.append(f'translate([{cx:.2f}, {cy:.2f}, {floor_h - 2.4:.2f}]) block_stacking_socket();')

        return f'''// StackCalc Learning Lab {REVISION} / {p.id}
// 3x3 Gridfinity Fraction Bin with Upper Stacking Lip & Wall Height Guides.
// Enables infinite vertical stacking of multiple bins.
$fn = 16;
tray_w = {p.width};
tray_h = {p.height};
bin_h = {p.thickness};
floor_h = {floor_h};
lip_h = {lip_h};

module rounded_square(dim, r=2, h=1) {{
    linear_extrude(h) offset(r) offset(-r) square([dim[0], dim[1]], center=true);
}}
module gridfinity_unit_base() {{
    hull() {{
        rounded_square([35.6, 35.6], r=1.6, h=0.8);
        translate([0,0,2.0]) rounded_square([40.4, 40.4], r=3.2, h=0.8);
    }}
    translate([0,0,2.0]) rounded_square([41.5, 41.5], r=3.75, h=1.0);
}}
module block_stacking_socket() {{
    hull() {{
        translate([0,0,-0.01]) rounded_square([36.0, 36.0], r=1.8, h=0.8);
        translate([0,0,1.8]) rounded_square([40.5, 40.5], r=3.3, h=0.6);
    }}
    translate([0,0,1.8]) rounded_square([40.5, 40.5], r=3.3, h=1.3);
}}

module stacking_lip(w, h, lh=4.4) {{
    difference() {{
        hull() {{
            rounded_square([w - 1.6, h - 1.6], r=2.95, h=0.8);
            translate([0, 0, 0.8]) rounded_square([w - 0.4, h - 0.4], r=3.55, h=lh - 1.6);
            translate([0, 0, lh - 0.8]) rounded_square([w - 1.6, h - 1.6], r=2.95, h=0.8);
        }}
        translate([0, 0, -0.01])
            rounded_square([w - 5.6, h - 5.6], r=2.0, h=lh + 0.02);
    }}
}}

difference() {{
    union() {{
        // Main bin body
        translate([tray_w/2, tray_h/2, 0])
            rounded_square([tray_w, tray_h], r=3.75, h=bin_h);
        // Upper Gridfinity stacking lip (enables stacking another bin on top)
        translate([tray_w/2, tray_h/2, bin_h - 0.01])
            stacking_lip(tray_w, tray_h, lip_h + 0.01);
        // Underside Gridfinity plugs
        {"".join(gf_plugs)}
    }}
    // Main inner cavity for the 9 towers
    translate([tray_w/2, tray_h/2, floor_h])
        rounded_square([tray_w - 5.6, tray_h - 5.6], r=2.0, h=bin_h - floor_h + lip_h + 1.0);

    // Floor Gridfinity sockets (9 sockets, 3x3) recessed into floor
    {"".join(floor_sockets)}

    // Front wall debossed fraction height guides
    // Heights above floor (floor_h = {floor_h}):
    // 1/9: 9.33, 1/8: 10.5, 1/7: 12.0, 1/6: 14.0, 1/5: 16.8, 1/4: 21.0, 1/3: 28.0, 1/2: 42.0, 1/1: 84.0
    for (pair = [[9.33, "1/9"], [10.5, "1/8"], [12.0, "1/7"], [14.0, "1/6"], [16.8, "1/5"], [21.0, "1/4"], [28.0, "1/3"], [42.0, "1/2"], [84.0, "1"]]) {{
        gz = floor_h + pair[0];
        if (gz <= bin_h) {{
            translate([tray_w/2, 0.3, gz])
                cube([tray_w - 10, 0.7, 0.6], center=true);
            translate([14, 0.6, gz])
                rotate([90, 0, 0])
                    linear_extrude(0.65)
                        text(pair[1], size=3.0, font="Liberation Sans:style=Bold", halign="center", valign="center");
        }}
    }}
}}
'''

    # Standard parts:
    bodies = "\n".join(f'linear_extrude(base_height/{s.get("height_divisor",1)}) ' + scad_shape(s, p.height) for s in p.bodies)
    pockets = "\n".join(scad_shape(s, p.height) for s in p.pockets)
    bosses = "\n".join(f'translate([{s["x"]},{p.height-s["y"]},base_height-0.01]) cylinder(r={s["r"]},h={s["height"]}+0.01);' for s in p.bosses)

    # Inset debossed text & lines:
    insets = []
    for l in p.labels:
        halign = l.get("align", "left")
        insets.append(f'translate([{l["x"]}, {p.height - l["y"]}]) text("{esc(l["text"])}", size={l["size"]}, font="Liberation Sans:style=Bold", halign="{halign}", valign="center");')
    for line in p.lines:
        w = line["width"]
        insets.append(f'hull() {{ translate([{line["x1"]}, {p.height - line["y1"]}]) circle(r={w/2}); translate([{line["x2"]}, {p.height - line["y2"]}]) circle(r={w/2}); }}')
    insets_code = "\n".join(insets)

    # Gridfinity base / plugs:
    gf_code = ""
    if p.gridfinity_x > 0 and not p.is_baseplate:
        # Underside Gridfinity plugs centered exactly within [0, p.width] x [0, p.height]
        plugs = []
        for gx in range(p.gridfinity_x):
            for gy in range(p.gridfinity_y):
                cx = (p.width / 2.0) + (gx - (p.gridfinity_x - 1) / 2.0) * 42.0
                cy = (p.height / 2.0) + (gy - (p.gridfinity_y - 1) / 2.0) * 42.0
                plugs.append(f'translate([{cx}, {cy}, -3.0]) gridfinity_unit_base();')
        gf_code = f'''
module gridfinity_unit_base() {{
    hull() {{
        rounded_square([35.6, 35.6], r=1.6, h=0.8);
        translate([0,0,2.0]) rounded_square([40.4, 40.4], r=3.2, h=0.8);
    }}
    translate([0,0,2.0]) rounded_square([41.5, 41.5], r=3.75, h=1.0);
}}
module rounded_square(dim, r=2, h=1) {{
    linear_extrude(h) offset(r) offset(-r) square([dim[0], dim[1]], center=true);
}}
module gridfinity_plugs() {{
    {"".join(plugs)}
}}
'''
    elif p.is_baseplate:
        # Baseplate sockets centered exactly within [0, p.width] x [0, p.height]
        sockets = []
        for gx in range(p.gridfinity_x):
            for gy in range(p.gridfinity_y):
                cx = (p.width / 2.0) + (gx - (p.gridfinity_x - 1) / 2.0) * 42.0
                cy = (p.height / 2.0) + (gy - (p.gridfinity_y - 1) / 2.0) * 42.0
                sockets.append(f'translate([{cx}, {cy}, base_height - 3.8]) gridfinity_socket();')
        gf_code = f'''
module gridfinity_socket() {{
    hull() {{
        translate([0,0,-0.01]) rounded_square([36.0, 36.0], r=1.8, h=0.8);
        translate([0,0,2.0]) rounded_square([40.8, 40.8], r=3.4, h=0.8);
    }}
    translate([0,0,2.0]) rounded_square([42.0, 42.0], r=4.0, h=2.0);
}}
module rounded_square(dim, r=2, h=1) {{
    linear_extrude(h) offset(r) offset(-r) square([dim[0], dim[1]], center=true);
}}
module baseplate_sockets() {{
    {"".join(sockets)}
}}
'''

    top_sockets_code = ""
    if p.has_top_sockets:
        # Reversible tray: 8 Gridfinity sockets on top
        top_sockets = []
        for gx in range(p.gridfinity_x):
            for gy in range(p.gridfinity_y):
                cx = (p.width / 2.0) + (gx - (p.gridfinity_x - 1) / 2.0) * 42.0
                cy = (p.height / 2.0) + (gy - (p.gridfinity_y - 1) / 2.0) * 42.0
                top_sockets.append(f'translate([{cx}, {cy}, base_height - 3.8]) gridfinity_socket();')
        top_sockets_code = f'''
module gridfinity_socket() {{
    hull() {{
        translate([0,0,-0.01]) rounded_square([36.0, 36.0], r=1.8, h=0.8);
        translate([0,0,2.0]) rounded_square([40.8, 40.8], r=3.4, h=0.8);
    }}
    translate([0,0,2.0]) rounded_square([42.0, 42.0], r=4.0, h=2.0);
}}
module top_sockets() {{
    {"".join(top_sockets)}
}}
'''
    elif p.is_ten_frame_tray:
        # Double Ten-Frame tray: 20 Quarter-width sockets on top (Frame 1 & Frame 2)
        ox = p.width / 2.0
        oy = p.height / 2.0
        col_pitch = 22.0
        row_pitch = 16.0
        mini_sockets = []
        for row in range(4):
            for col in range(5):
                cx = ox + (col - 2.0) * col_pitch
                cy = oy + (row - 1.5) * row_pitch
                mini_sockets.append(f'translate([{cx}, {cy}, base_height - 1.8]) miniblock_socket();')
        top_sockets_code = f'''
module miniblock_socket() {{
    hull() {{
        rounded_square([17.4, 17.4], r=0.9, h=0.5);
        translate([0,0,0.8]) rounded_square([19.9, 19.9], r=1.7, h=0.5);
    }}
    translate([0,0,1.0]) rounded_square([20.8, 20.8], r=1.9, h=1.0);
}}
module top_sockets() {{
    {"".join(mini_sockets)}
}}
'''

    if p.is_baseplate:
        diff_code = f'''
difference() {{
    solids();
    baseplate_sockets();
    translate([0,0,base_height-inset_depth]) linear_extrude(inset_depth+0.05) insets();
}}
'''
    elif p.has_top_sockets or p.is_ten_frame_tray:
        diff_code = f'''
difference() {{
    union() {{
        solids();
        gridfinity_plugs();
    }}
    top_sockets();
    {"translate([0,0,base_height-inset_depth]) linear_extrude(inset_depth+0.05) insets();" if (p.labels or p.lines) else ""}
}}
'''
    else:
        diff_code = f'''
difference() {{
    union() {{
        solids();
        {"gridfinity_plugs();" if (p.gridfinity_x > 0 and not p.is_baseplate) else ""}
    }}
    {"translate([0,0,base_height-pocket_depth]) linear_extrude(pocket_depth+0.02) pockets();" if p.pockets else ""}
    {"translate([0,0,base_height-inset_depth]) linear_extrude(inset_depth+0.05) insets();" if (p.labels or p.lines) else ""}
}}
'''

    return f'''// StackCalc Learning Lab {REVISION} / {p.id}
// Generated by tools/generate.py. Dimensions live in tools/catalog.py.
// Debossed inset text (0.6 mm depth) for fast single-operation FDM printing (PLA/PETG).
base_height = {p.thickness};
pocket_depth = {p.pocket_depth};
inset_depth = {p.inset_depth};
$fn = 16;

module solids() {{ {bodies} }}
module pockets() {{ {pockets} }}
module insets() {{ {insets_code} }}
{gf_code}
{top_sockets_code}
{diff_code}
{bosses}
'''


def engrave_segments(line, pockets, clearance=0.15):
    """Clip planar strokes clear of recesses, without SVG clipping masks."""
    x, y = line["x1"], line["y1"]
    dx, dy = line["x2"] - x, line["y2"] - y
    intervals = [(0.0, 1.0)]
    for s in pockets:
        margin = clearance + line["width"] / 2
        if s["kind"] == "circle":
            a = dx * dx + dy * dy
            if not a:
                return []
            b = 2 * ((x - s["x"]) * dx + (y - s["y"]) * dy)
            c = (x - s["x"]) ** 2 + (y - s["y"]) ** 2 - (s["r"] + margin) ** 2
            discriminant = b * b - 4 * a * c
            if discriminant <= 0:
                continue
            lo = (-b - math.sqrt(discriminant)) / (2 * a)
            hi = (-b + math.sqrt(discriminant)) / (2 * a)
        else:
            lo, hi = 0.0, 1.0
            for origin, delta, start, end in [(x, dx, s["x"] - margin, s["x"] + s["w"] + margin),
                                              (y, dy, s["y"] - margin, s["y"] + s["h"] + margin)]:
                if delta == 0:
                    if not start <= origin <= end:
                        lo, hi = 1.0, 0.0
                        break
                else:
                    t0, t1 = sorted(((start - origin) / delta, (end - origin) / delta))
                    lo, hi = max(lo, t0), min(hi, t1)
            if lo >= hi:
                continue
        remaining = []
        for a, b in intervals:
            if hi <= a or lo >= b:
                remaining.append((a, b))
                continue
            if a < lo:
                remaining.append((a, lo))
            if hi < b:
                remaining.append((hi, b))
        intervals = remaining
    return [(x + a * dx, y + a * dy, x + b * dx, y + b * dy) for a, b in intervals if b - a > 1e-8]


def generate(out):
    lettering = Lettering()
    for p in catalog():
        marks = []
        by_height = {}
        for label in p.labels:
            paths, bounds, _ = lettering.outline(label)
            for x0, y0, x1, y1 in bounds:
                if min(x0, y0) < -1 or x1 > p.width + 1 or y1 > p.height + 1:
                    raise ValueError(f"Lettering exceeds {p.id}: {label['text']}")
            mark = f'<g aria-label="{html.escape(label["text"], quote=True)}">{paths}</g>'
            marks.append(mark)
            by_height.setdefault(label["surface_z"], []).append(mark)
        for line in p.lines:
            for x1, y1, x2, y2 in engrave_segments(line, p.pockets):
                marks.append(f'<path d="M {x1:g} {y1:g} L {x2:g} {y2:g}" stroke="black" stroke-width="{line["width"]}" fill="none"/>')
        mark_group = '<g id="ENGRAVE" fill="black">' + "".join(marks) + "</g>"
        cut_group = '<g id="CUT">' + "".join(shape_svg(s, stroke="#ff0000") for s in p.bodies) + "</g>"
        guide_group = '<g id="POCKET_GUIDE">' + "".join(shape_svg(s, stroke="#0000ff", width=0.2) for s in p.pockets) + "</g>"
        if len(by_height) <= 1:
            write_changed(out / "svg" / f"{p.id}-engrave.svg", svg(p, mark_group, "Black filled outlines: 1:1 mm registration."))
        if len(by_height) > 1:
            for setup in laser_setups(p):
                z = setup["surface_z_mm"]
                group = '<g id="ENGRAVE" fill="black">' + "".join(by_height[z]) + "</g>"
                write_changed(out / setup["file"], svg(p, group, f"Top surface Z={z:g} mm. Preserve full layout origin."))
        write_changed(out / "svg" / f"{p.id}-cut.svg", svg(p, cut_group, "Red vector outlines: nominal outer cuts."))
        write_changed(out / "svg" / f"{p.id}-pocket-guide.svg", svg(p, guide_group, "Blue pocket guide."))
        preview = ("".join(shape_svg(s, fill=PAPER, stroke=INK, width=0.2) for s in p.bodies)
                   + mark_group + "".join(shape_svg(s, fill="#dce9e5", stroke=TEAL, width=0.2) for s in p.pockets)
                   + "".join(f'<circle cx="{s["x"]}" cy="{s["y"]}" r="{s["r"]}" fill="{TEAL}"/>' for s in p.bosses))
        write_changed(out / "preview" / f"{p.id}.svg", svg(p, preview, "Top view preview."))
        write_changed(out / "scad" / f"{p.id}.scad", scad(p))
    write_changed(out / "manifest.json", json.dumps(manifest(), indent=2) + "\n")
    cards = []
    for p in catalog():
        cards.append(f'<article><img src="{p.id}.svg" alt="{html.escape(p.title)}"><h2>{html.escape(p.title)}</h2><p>{p.width} x {p.height} mm</p><p>{html.escape(p.notes)}</p></article>')
    write_changed(out / "preview" / "index.html", f'''<!doctype html><meta charset="utf-8"><title>StackCalc Learning Lab</title>
<style>body{{margin:48px;background:#f6f3ea;color:#173d43;font:16px system-ui}}h1{{font-size:48px;letter-spacing:-2px}}main{{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:24px}}article{{background:white;padding:24px;border-radius:12px}}img{{width:100%;height:310px;object-fit:contain}}h2{{font-size:20px}}p{{line-height:1.5}}header{{max-width:800px;margin-bottom:36px}}</style>
<header><p>STACKCALC / LEARNING LAB / COLLECTION 01</p><h1>Make the math tangible.</h1><p>Modular Gridfinity manipulative system with inset debossed text. Standard 42 mm pitch.</p><p>Revision {REVISION} / FDM-Ready PLA/PETG / Storage box doubles as workspace.</p></header><main>''' + "".join(cards) + "</main>")
    print(f"Generated {len(catalog())} parts: outlined SVG, parametric SCAD, previews and manifest.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path("build"))
    generate(parser.parse_args().out)

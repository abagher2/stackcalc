import unittest
from fractions import Fraction
from pathlib import Path

from catalog import catalog, UNIT_HEIGHT, BLOCK_SIDE, laser_setups
from lessons import EXAMPLES, trace, number
from generate import engrave_segments
from curricula import CURRICULA_LESSONS, PROFICIENCY_TRIALS
from keycaps import KEYCAPS_DIR, sanitize_filename


class LessonTests(unittest.TestCase):
    def test_laser_strokes_stop_before_recess_edges(self):
        line = dict(x1=0, y1=0, x2=20, y2=0, width=0.4)
        segments = engrave_segments(line, [dict(kind="circle", x=10, y=0, r=2)])
        self.assertEqual(len(segments), 2)
        self.assertAlmostEqual(segments[0][2], 7.65)
        self.assertAlmostEqual(segments[1][0], 12.35)

    def test_published_answers(self):
        for title, sequence, answer in EXAMPLES:
            with self.subTest(title=title):
                self.assertEqual(trace(sequence)[-1][1][0], answer)
        for sequence, answer in [(".1.2 ENTER .1.4 +", Fraction(3, 4)),
                                ("6 ENTER 1 + 9 ENTER 5 - *", 28),
                                ("2 ENTER 5 - x^2 1 ENTER 5 - x^2 + sqrt", 5)]:
            self.assertEqual(trace(sequence)[-1][1][0], answer)

    def test_four_register_states_and_t_repeat(self):
        states = trace("3 ENTER 8 ENTER 4 ENTER 1 + - *")
        self.assertEqual(states[6][1], (1, 4, 8, 3))
        self.assertEqual(states[7][1], (5, 8, 3, 3))
        self.assertEqual(states[8][1], (3, 3, 3, 3))
        self.assertEqual(states[9][1], (9, 3, 3, 3))

    def test_enter_and_automatic_lift_are_distinct(self):
        states = trace("8 ENTER 3 - 2 *")
        self.assertEqual(states[1][1], (8, 8, 0, 0))
        self.assertEqual(states[2][1], (3, 8, 0, 0))
        self.assertEqual(states[4][1], (2, 5, 0, 0))
        self.assertEqual(states[-1][1][0], 10)

    def test_fraction_blocks_preserve_proportional_heights_and_fit(self):
        parts = {p.id: p for p in catalog()}
        blocks = parts["fraction_blocks"]
        self.assertEqual(len(blocks.bodies), 9)
        total_pieces = sum(b.get("pieces", 1) for b in blocks.bodies)
        self.assertEqual(total_pieces, 45)
        families = {}
        for b in blocks.bodies:
            self.assertEqual((b["w"], b["h"]), (BLOCK_SIDE, BLOCK_SIDE))
            d = b["height_divisor"]
            pieces = b.get("pieces", 1)
            self.assertEqual(pieces, d)
            families[d] = [UNIT_HEIGHT / d] * pieces
        self.assertEqual(sorted(families.keys()), [1, 2, 3, 4, 5, 6, 7, 8, 9])
        for n, heights in families.items():
            self.assertEqual(len(heights), n)
            self.assertAlmostEqual(sum(heights), UNIT_HEIGHT)
        self.assertTrue(parts["fraction_tray"].is_fraction_bin)
        self.assertEqual(parts["fraction_tray"].gridfinity_x, 3)
        self.assertEqual(parts["fraction_tray"].gridfinity_y, 3)
        tray = parts["ten_frame_tray"]
        self.assertEqual(len(tray.pockets), 20)
        dots = parts["ten_frame_dots"]
        self.assertEqual(len(dots.bodies), 20)
        self.assertEqual((dots.bodies[0]["w"], dots.bodies[0]["h"]), (20.5, 20.5))
        self.assertEqual(dots.thickness, 7.0)
        self.assertEqual(number(".3.4"), Fraction(3, 4))
        with self.assertRaises(ZeroDivisionError):
            number(".3.0")

    def test_parts_stay_inside_nominal_print_bed(self):
        for p in catalog():
            self.assertLessEqual(max(p.width, p.height), 210)
            for s in p.bodies + p.pockets:
                if s["kind"] == "circle":
                    box = (s["x"] - s["r"], s["y"] - s["r"], s["x"] + s["r"], s["y"] + s["r"])
                else:
                    box = (s["x"], s["y"], s["x"] + s["w"], s["y"] + s["h"])
                self.assertGreaterEqual(min(box[:2]), -1.0, p.id)
                self.assertLessEqual(box[2], p.width + 1.0, p.id)
                self.assertLessEqual(box[3], p.height + 1.0, p.id)

    def test_curricula_lessons_structure(self):
        self.assertGreaterEqual(len(CURRICULA_LESSONS), 6)
        curricula_names = {lp.curriculum for lp in CURRICULA_LESSONS}
        self.assertIn("Singapore Math", curricula_names)
        self.assertIn("Big Ideas Math", curricula_names)
        self.assertIn("Bridges in Mathematics", curricula_names)
        for lp in CURRICULA_LESSONS:
            self.assertTrue(lp.standard.startswith("CCSS.MATH"))
            self.assertTrue(len(lp.key_tokens) > 0)
            self.assertTrue(len(lp.calculator_flow) > 0)

    def test_keycaps_exist(self):
        required_keys = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "ENTER", "+", "-", "times", "divide", "sqrt_x"]
        for k in required_keys:
            fname = sanitize_filename(k) + ".png"
            path = KEYCAPS_DIR / fname
            self.assertTrue(path.exists(), f"Missing keycap {fname}")

    def test_proficiency_trials_structure(self):
        self.assertEqual(len(PROFICIENCY_TRIALS), 15)
        for tr in PROFICIENCY_TRIALS:
            self.assertEqual(len(tr.problems), 10)
            self.assertIn(tr.max_stack_depth, (1, 2, 4))
            self.assertIn(tr.time_limit_minutes, (5, 10, 15, 20))
            for prob in tr.problems:
                self.assertTrue(len(prob.prompt) > 0)
                self.assertTrue(len(prob.expected_answer) > 0)
                self.assertTrue(len(prob.keystrokes) > 0)
                self.assertLessEqual(prob.max_stack_depth, tr.max_stack_depth)


if __name__ == "__main__":
    unittest.main()

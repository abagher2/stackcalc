# StackCalc Math Manipulatives STL Pack (v0.2.0)
Physical classroom math manipulatives for hands-on CRA geometric, fraction, and algebraic modeling.

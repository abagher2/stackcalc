// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
// StackCalc Learning Lab / unifix_cubes
// 24 Pure Gridfinity Interlocking Cubes (20.5 x 20.5 x 20.5 mm, quarter-size footprint).
// Support-Free Monolithic FDM Architecture:
// - Top (+Z): Standard 18mm Gridfinity miniblock female stacking socket (depth 1.85mm).
// - Bottom (-Z): Standard 18mm Gridfinity miniblock male base (h = 1.85mm).
// - Lateral Sides: 4 clean, flat planar faces with 1.8mm rounded edges for tactile handling.
// - Pure Tabletop Gridfinity: Vertically stacks into 1D sticks; horizontally docks into tray/lid grids.
$fn = 20;

module rounded_square(dim, r=1.5, h=1) {
    linear_extrude(h) offset(r=r) offset(delta=-r) square([dim[0], dim[1]], center=true);
}

// Standard 18mm Gridfinity Male Base (miniblock_base)
// Step at 18.4mm, total footprint 19.0 x 19.0 mm, h=1.85 mm
module miniblock_base() {
    hull() {
        rounded_square([17.0, 17.0], r=1.0, h=0.02);
        translate([0, 0, 0.70]) rounded_square([18.4, 18.4], r=1.4, h=0.02);
    }
    translate([0, 0, 0.70])
        rounded_square([18.4, 18.4], r=1.4, h=0.25);
    hull() {
        translate([0, 0, 0.95]) rounded_square([18.4, 18.4], r=1.4, h=0.02);
        translate([0, 0, 1.85]) rounded_square([19.0, 19.0], r=1.8, h=0.02);
    }
}

// Standard 18mm Gridfinity Female Stacking Socket (miniblock_stacking_socket)
// Slant 3D DFM: Step at 18.8mm (0.40mm clearance over 18.4mm male foot, concentric 0.10mm rim), depth=1.85 mm
module miniblock_stacking_socket() {
    hull() {
        translate([0, 0, -0.05]) rounded_square([17.5, 17.5], r=1.1, h=0.02);
        translate([0, 0, 0.70]) rounded_square([18.8, 18.8], r=1.7, h=0.02);
    }
    translate([0, 0, 0.70])
        rounded_square([18.8, 18.8], r=1.7, h=0.25);
    hull() {
        translate([0, 0, 0.95]) rounded_square([18.8, 18.8], r=1.7, h=0.02);
        translate([0, 0, 1.85 + 0.05]) rounded_square([18.8, 18.8], r=1.7, h=0.02);
    }
}

// Harmonized Monolithic Counting Tile: 19.0 x 19.0 x 8.85 mm (1/12 Fraction Tower, 7.0mm visible height / 1U Gridfinity)
// Stack of 3 = 21.0mm (1/4 fraction block = 1 unit cube); Stack of 12 = 84.0mm (1 whole tower).
// Gridfinity blocks do not snap — they stack and dock via gravity and precision 45° chamfers (0.40mm clearance).
// Four-Color Map Theorem Palette Allocation (per MATERIAL_AND_MARKING_SPEC.md & build_multicolor_3mf.py):
//   1. Sunlu White PLA 2.0+ / White PETG (#F5F5F3) -> Slant 3D Pure White
//   2. Red+Blue Dual Silk PLA (#2563EB)           -> Slant 3D Cobalt Blue
//   3. Red+Gold Dual Silk PLA (#BC2626)           -> Slant 3D Amber Yellow
//   4. Sunlu Blue-Gray PLA 2.0+ (#5B6579)         -> Slant 3D Slate Gray
// Total: 4 color plates x 36 tiles = 144 precision stacking tiles in 13U Gridfinity box.
tile_h_vis = 7.0;
tile_h = 1.85 + tile_h_vis; // 8.85mm

module counting_tile(cx, cy) {
    translate([cx, cy, 0]) {
        difference() {
            union() {
                // Bottom 18mm Gridfinity Male Base (z = 0 to 1.85mm)
                miniblock_base();

                // Main solid tile body (z = 1.85 to 8.85mm, 7.0mm visible tile)
                translate([0, 0, 1.85 - 0.01])
                    rounded_square([19.0, 19.0], r=1.8, h=tile_h - 1.85 + 0.01);
            }

            // Top Female 18mm Gridfinity Stacking Socket (z = 7.0 to 8.85mm)
            translate([0, 0, tile_h - 1.85])
                miniblock_stacking_socket();
        }
    }
}

// Backward-compatible alias
module snap_tile(cx, cy) {
    counting_tile(cx, cy);
}

// PRINT BED LAYOUT: Exactly 36 Clean Monolithic Tiles (6x6 Grid, 25mm Pitch = 1 Full Color Set)
for (row = [0:5]) {
    for (col = [0:5]) {
        counting_tile(12.5 + col * 25.0, 12.5 + row * 25.0);
    }
}

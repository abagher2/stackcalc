================================================================================
STACKCALC LEARNING LAB // COUNTING TILES & ARRAY STUDIO (TILE-01)
================================================================================
Open-Source 3D Printable STL & OpenSCAD Source Pack
Standard: Zack Freedman 42mm Gridfinity Ecosystem (13U Master Height)
Target Grades: K - 6 (One-to-one counting, cardinality, arrays, Four-Color Map Theorem)

CONTENTS:
1. unifix_cubes_parts.stl / unifix_cubes_parts.scad
   - 144 Harmonized Monolithic Counting Tiles (19.0 x 19.0 x 8.85 mm, 7.0mm visible 1U height).
   - Sliced across 4 color plates (36 tiles each):
     Plate 1: Archival White (Sunlu White PLA 2.0+ / White PETG #F5F5F3)
     Plate 2: Cobalt Blue (Red+Blue Dual Silk PLA #2563EB)
     Plate 3: Radiant Gold (Red+Gold Dual Silk PLA #BC2626)
     Plate 4: Slate Gray (Sunlu Blue-Gray PLA 2.0+ #5B6579)
   - Matches 1/12th Fraction Studio block (stack of 3 = 21mm, stack of 12 = 84mm).
   - Gravity docking with 45-degree chamfers and 0.40mm clearance (blocks do not snap or fatigue).

2. unifix_cubes_box.stl / unifix_cubes_box.scad
   - 3x1x13U Gridfinity Enclosure Box (125.5 x 42.0 x 91.0 mm body, 95.4mm with lip).
   - Front debossed instrument plaque: "COUNTING"
   - Rear button badge: "[NUM]"
   - Stackable lid with 12 miniblock docking grid.

PRINT SETTINGS:
- Layer Height: 0.20 mm Standard (0.12 mm for lid legends)
- Infill: 15% - 20% Gyroid
- Supports: NONE (100% Support-Free)
- Material: PLA 2.0+ or PETG

License: CERN Open Hardware License v2 - Strongly Reciprocal
Web: https://stackcalc.io/products/counting-tiles/
Etsy Store: https://www.etsy.com/shop/StackCalc
================================================================================

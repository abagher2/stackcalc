// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
include <lib/part_metadata.scad>

// ============================================================================
// Component Metadata Contract (Single Source of Truth)
// ============================================================================
PART_SKU = "UNIF-01";
PART_REV = "c601765";
PART_NAME = "Counting & Array Studio 3x1 Storage Enclosure";
PART_AMORTIZED_COST = 10.00;
PART_REPLACEMENT_PRICE = 15.00;

// StackCalc Learning Lab / counting_studio_box (formerly unifix_cubes_box)
// 3x1 Gridfinity Four-Color Counting Tile Holding Bin (125.5 x 42.0 x 91.0 mm / 13U).
// Complete 3-Piece Support-Free Assembly:
//   1. 3x1x13U Storage Enclosure Body with vertical side guide tracks.
//   2. Drop-Front Sliding Door with "COUNTING" title plaque and thumb pull.
//   3. Snapfinity Stackable Docking Lid with miniblock grid and NUM keycap badge.
// Holds 144 Gridfinity counting tiles (4 colors x 36 tiles) in a 6x2 grid across 12 vertical layers.
// Standard 100% Gridfinity Architecture:
//   - 3x1 standard Gridfinity base profile on underside (42.0mm pitch).
//   - Standard 4.4mm upper stacking lip for stacking additional bins.
//   - Drop-front door slides vertically up and out, exposing the front row
//     horizontally for 100% unobstructed loading of all 144 counting tiles.
//   - Interior base features 12 standardized 18mm Gridfinity miniblock sockets (6x2 grid).
//   - Snapfinity lid caps the top edge of the sliding front door, locking it shut.
// 100% support-free FDM printing directly at Z=0.

$fn = 16;
tray_w = 125.5;
tray_h = 42.0;
bin_h = 91.0; // 13U standard (91.0mm, matches Fraction Studio box), housing 144 tiles
lip_h = 4.4;
floor_h = 3.5;
door_h = bin_h - floor_h; // 87.5 mm

module unifix_box_body() {
    gridfinity_caddy_box_body(
        tray_w = tray_w,
        tray_h = tray_h,
        bin_h = bin_h,
        lip_h = lip_h,
        title = "COUNTING",
        badge_label = "NUM",
        badge_type = "unifix"
    );
}

module unifix_caddy() {
    column_caddy_chassis(
        tray_w = tray_w,
        tray_h = tray_h,
        bin_h = bin_h,
        caddy_h = 85.00,
        nx = 6,
        pitch_x = 20.14,
        pitch_y = 19.80,
        row0_y = 11.10,
        row1_y = 30.90,
        start_x = 12.40,
        title = "COUNTING"
    );
}

// Backward-compatible alias
module box_plate() {
    unifix_box_body();
}

module unifix_front_door() {
    unifix_caddy();
}

module unifix_lid_grid() {
    gridfinity_stackable_lid(
        nx = 3,
        ny = 1,
        miniblock_grid = true,
        detents = true,
        detent_sides = "ends",
        button_face = "NUM",
        button_sublabel = "",
        button_type = "unifix",
        row0_labels = [],
        row1_labels = [],
        drop_front = false
    );
}

// ----------------------------------------------------------------------------
// Manufacturing Plate Layout (All 3 pieces on 250x210 bed, zero supports)
// ----------------------------------------------------------------------------
show_box   = true;
show_caddy = true;
show_lid   = true;

if (show_box)
    translate([0, 0, 3.0])
        unifix_box_body();

if (show_caddy)
    // Sits flat on bed at Z=0 for high-speed, warp-free, support-free printing
    translate([0, 46.0, 0])
        unifix_caddy();

if (show_lid)
    translate([0, 144.0, 0])
        unifix_lid_grid();

// Project-local Space Mono, registered explicitly in OpenSCAD.
use <../../Shared/Fonts/SpaceMono-Regular.ttf>
use <../../Shared/Fonts/SpaceMono-Bold.ttf>
use <lib/typography.scad>
include <lib/design_library.scad>
// StackCalc Learning Lab / counting_studio_box (formerly unifix_cubes_box)
// 3x1 Gridfinity Four-Color Counting Tile Holding Bin (125.5 x 42.0 x 91.0 mm / 13U).
// Holds 144 Gridfinity counting tiles (4 colors x 36 tiles) in a 6x2 grid across 12 vertical layers.
// Matches the 13U master height of the Fraction Studio box for uniform shelf alignment.
// Pure standard Gridfinity bin with stackable upper lip.
// Interior base features 12 standardized 18mm Gridfinity miniblock sockets (6x2 grid).
// Gridfinity blocks stack and dock via gravity and 45° chamfers; they do not use friction snap detents.
// 100% self-supporting, zero-overhang geometry.
$fn = 16;
tray_w = 125.5;
tray_h = 42.0;
bin_h = 91.0; // 13U standard (91.0mm, matches Fraction Studio box), housing 144 tiles
lip_h = 4.4;
floor_h = 3.5;

module rounded_square(dim, r=2, h=1) {
    linear_extrude(h) offset(r=r) offset(delta=-r) square([dim[0], dim[1]], center=true);
}

module gridfinity_unit_base() {
    rounded_square([35.6, 35.6], r=1.6, h=0.8);
    translate([0, 0, 0.8])
        hull() {
            rounded_square([35.6, 35.6], r=1.6, h=0.02);
            translate([0, 0, 1.6]) rounded_square([40.4, 40.4], r=3.2, h=0.02);
        }
    translate([0, 0, 2.4])
        hull() {
            rounded_square([40.4, 40.4], r=3.2, h=0.02);
            translate([0, 0, 0.6]) rounded_square([41.5, 41.5], r=3.75, h=0.02);
        }
}

module stack_icon_2d(w=6.0, h=7.5) {
    bar_h = h * 0.18;
    gap = (h - 4 * bar_h) / 3.0;
    r = bar_h * 0.4;
    translate([-w/2 + w*0.08, -h/2 + 3 * (bar_h + gap)])
        offset(r=r) offset(delta=-r) square([w * 0.84, bar_h]);
    translate([-w/2, -h/2 + 2 * (bar_h + gap)])
        offset(r=r) offset(delta=-r) square([w, bar_h]);
    translate([-w/2, -h/2 + 1 * (bar_h + gap)])
        offset(r=r) offset(delta=-r) square([w, bar_h]);
    translate([-w/2, -h/2 + 0])
        offset(r=r) offset(delta=-r) square([w, bar_h]);
}

module miniblock_cavity_socket() {
    hull() {
        translate([0, 0, -0.05]) rounded_square([17.4, 17.4], r=1.1, h=0.02);
        translate([0, 0, 0.70]) rounded_square([18.8, 18.8], r=1.5, h=0.02);
    }
    translate([0, 0, 0.70])
        rounded_square([18.8, 18.8], r=1.5, h=0.25);
    hull() {
        translate([0, 0, 0.95]) rounded_square([18.8, 18.8], r=1.5, h=0.02);
        translate([0, 0, 1.85 + 0.05]) rounded_square([19.2, 19.2], r=1.6, h=0.02);
    }
}

row0_labels = ["T7", "T8", "T9", "T10", "T11", "T12"];
row1_labels = ["T1", "T2", "T3", "T4", "T5", "T6"];

module box_plate() {
difference() {
    union() {
        translate([tray_w/2, tray_h/2, 0])
            rounded_square([tray_w - 0.5, tray_h - 0.5], r=3.75, h=bin_h - 1.6);
            
        translate([tray_w/2, tray_h/2, bin_h - 1.6])
            hull() {
                rounded_square([tray_w - 0.5, tray_h - 0.5], r=3.75, h=0.2);
                translate([0, 0, 1.4]) rounded_square([tray_w, tray_h], r=3.75, h=0.2);
            }
            
        translate([tray_w/2, tray_h/2, bin_h])
            rounded_square([tray_w, tray_h], r=3.75, h=lip_h);

        translate([20.75, 21.00, -3.0]) gridfinity_unit_base();translate([62.75, 21.00, -3.0]) gridfinity_unit_base();translate([104.75, 21.00, -3.0]) gridfinity_unit_base();
        for (div_x = [42.0, 84.0]) {
            translate([div_x, tray_h / 2, -0.6])
                hull() {
                    cube([0.02, 41.5, 0.02], center=true);
                    translate([0, 0, 0.6]) cube([1.2, 41.5, 0.02], center=true);
                }
        }
    }
    
    // Main inner cavity: centered symmetrically at y = tray_h/2: 118.0 x 39.2 mm (flush with 6x2 block grid)
    translate([tray_w/2, tray_h/2, floor_h])
        rounded_square([118.0, 39.2], r=1.0, h=bin_h - floor_h + 0.1);

    // Standardized Snapfinity 1.20mm reinforced upper lip rebate with 0.35mm retention detent grooves
    gridfinity_box_lip_rebate(tray_w=tray_w, tray_h=tray_h, bin_h=bin_h, lip_h=lip_h, lip_wall_t=1.20, nx=3);

    // 12 Female miniblock sockets in 6x2 grid inside the bottom of the tray
    // Universal 19.60mm pitch aligned with blocks and trays across all kits
    for (col = [0:5]) {
        cx = 13.75 + col * 19.60;
        translate([cx, 11.20, floor_h - 1.85])
            miniblock_cavity_socket();

        translate([cx, 30.80, floor_h - 1.85])
            miniblock_cavity_socket();
    }

    // Front face recessed instrument plaque (isolates typography from zoned fuzzy skin)
    translate([tray_w/2, 0.25, bin_h / 2])
        rotate([90, 0, 0])
            box_instrument_plaque(title="COUNTING", w=76.0, h=12.0);

    // Architectural horizontal reveal parting lines for zoned fuzzy skin
    box_architectural_reveals(tray_w, tray_h, bin_h);

    // End wall architectural fluted grip louvers
    box_fluted_louvers(tray_w, tray_h, bin_h);

    // Rear wall lower-right calculator button badge
    box_back_button_badge(tray_w, tray_h, bin_h, type="unifix", label="NUM", sublabel="");

}

}

module miniblock_floor_socket() {
    hull() {
        translate([0, 0, -0.05]) rounded_square([17.4, 17.4], r=1.1, h=0.02);
        translate([0, 0, 0.70]) rounded_square([18.8, 18.8], r=1.5, h=0.02);
    }
    translate([0, 0, 0.70])
        rounded_square([18.8, 18.8], r=1.5, h=0.25);
    hull() {
        translate([0, 0, 0.95]) rounded_square([18.8, 18.8], r=1.5, h=0.02);
        translate([0, 0, 1.85 + 0.05]) rounded_square([20.4, 20.4], r=1.8, h=0.02);
    }
}

module unifix_lid_grid() {
    gridfinity_stackable_lid(
        nx = 3,
        ny = 1,
        miniblock_grid = true,
        detents = true,
        row0_labels = [],
        row1_labels = []
    );
}

translate([0, 0, 3.0]) box_plate();
translate([0, 48.0, 0]) unifix_lid_grid();


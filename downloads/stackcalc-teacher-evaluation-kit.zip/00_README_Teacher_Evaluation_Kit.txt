================================================================================
STACKCALC EDUCATIONAL EVALUATION KIT & DISTRICT REQUISITION BUNDLE
================================================================================

Welcome to the StackCalc Evaluation Kit. This bundle equips math coaches, STEM
department chairs, curriculum directors, and classroom teachers to evaluate
StackCalc Reverse Polish Notation (RPN) calculators, tactile manipulatives,
and classroom station labs.

CONTENTS OF THIS EVALUATION KIT:
--------------------------------------------------------------------------------
01_District_PO_Requisition_and_W9_Packet.pdf
    Official institutional requisition form, volume fleet pricing matrix, Net-30
    invoicing procedures, and 24-hour IRS Form W-9 onboarding SLA.

02_Teacher_Facilitation_Guide_and_Rubrics.pdf
    34-page master guide for station setup, 4-tier student mastery rubrics,
    and diagnostic remediation guides for common arithmetic misconceptions.

03_RPN_Math_Labs_Curriculum_Sample.pdf
    12-page sample instructional unit detailing the Concrete-Pictorial-Abstract (CPA)
    progression: fraction towers, base-10 regrouping, and introductory RPN stacks.

04_Singapore_Math_Station_Companion_FormA.pdf
    Publication-grade 2-page student station companion and teacher rubric for
    Singapore Dimensions Math (Grade 1 Number Bonds & Complements).

05_Bridges_Math_Station_Companion_FormA.pdf
    Publication-grade 2-page visual companion for Bridges in Mathematics
    (Grade 1 Addition & Fact Strategies).

06_Big_Ideas_Secondary_Station_Companion_FormA.pdf
    Publication-grade 2-page visual companion for Big Ideas Math
    (Grade 6 Numerical Expressions & Postfix Stack Tracing).

07_Texas_UIL_High_School_Exam_26A.pdf
    Full 70-problem official tournament sprint exam for High School Calculator
    Applications (UIL / TMSCA / TAPPS).

08_Texas_UIL_Official_Scoring_Key_26A.pdf
    Tournament-standard 4-column grading key with 3-significant-figure canonical
    answers and official acceptance intervals.

--------------------------------------------------------------------------------
ORDERING & EVALUATION ASSISTANCE:
Questions regarding classroom pilots, sample kits, or volume purchase orders?
Email: quotes@stackcalc.io
Web:   https://stackcalc.io/#school-po
Store: https://www.etsy.com/shop/StackCalc
================================================================================

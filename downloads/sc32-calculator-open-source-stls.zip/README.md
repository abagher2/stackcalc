# StackCalc SC-32 Mechanical Prototype (Rev 0.2.0)
Print specifications: 0.16mm layer height. Chassis/Faceplate: PETG or Matte PLA. Keypad: 95A TPU.

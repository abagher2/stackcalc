# Blueprint review and design decisions

Reviewed input: `rpn_educational_ecosystem_master_creative_product_blueprint.md`, supplied 2026-09-22. The document is design input; its embedded CAD and action-plan instructions were not treated as independent authorization to publish, spend, or contact anyone.

## Keep the product thesis; make the teaching precise

Physical representations, short reference cards and teacher-ready lessons form a coherent companion collection. Each item should connect **representation -> prediction -> calculator action -> explanation**. The first collection uses StackCalc branding and a restrained teal / warm-paper visual system. The product is the learning activity plus the object, not an engraved slogan alone.

## Corrections before engraving

| Blueprint statement | Decision used in this collection |
| --- | --- |
| ENTER is simply PUSH; signs are POP | Teach the four-register behavior: ENTER copies X upward and the next number replaces X. Binary arithmetic combines Y and X. New entry after arithmetic lifts the result. A generic pushdown stack is a separate abstraction. |
| T is overflow storage | T is the fourth register. A lift can lose its old value; binary stack drop repeats T. Four physical registers are always present. |
| Backspace is DROP | Do not engrave that claim. The local `backspace()` edits active entry and otherwise clears X; the separate `drop()` method is not the same action. Entry cancellation also has mode-dependent behavior. |
| Stronger ahead means ENTER; weaker/equal means operator | Remove this as a general parsing algorithm. Precedence is relative to pending operations. Associativity, unary functions, grouping and multiple pending operations need a real conversion method. Teach the expression tree first. `8 / 4 * 2` is evaluated left-to-right; treating all multiplication as an unconditional park rule fails. |
| Parentheses are calculator pause buttons | Parentheses express grouping in the written expression. The calculator sequence is derived from the expression structure and current entry state. |
| Distance is an 11-step / keystroke pipeline | Use four named stages: horizontal square, vertical square, add, root. The printed example has 12 action tokens when each coordinate entry counts once; physical key counts depend on digits, sign entry and shifted functions. |
| A dense all-in-one CR80 card | Split into three cards: stack, fractions, distance. Laser finishing keeps the printed card 1.4 mm thick overall. Case compatibility remains untested. |
| DFS channels enforce postorder | The supplied branching grooves cannot enforce postorder. This revision uses numbered wells and engraved branches, explicitly described as a guided activity. No captive traversal claim. |
| Dot fractions are native rational scalars | Retain the documented entry syntax, without claiming exact rational storage across every HP/StackCalc operation. A display fraction and exact symbolic arithmetic are different guarantees. |

Reference: [HP 32SII Owner's Manual](https://h10032.www1.hp.com/ctg/Manual/bpia5305.pdf), chapters 1-2 and appendix B. Live local source cross-check: `RPNCore/Sources/RPNCore/CalculatorEngine+Stack.swift`, including `digit`, `decimal`, `enter`, `backspace`, `rollDown`, `drop` and `duplicateX`. This work does not alter that source or certify its behavior across all modes. The repository already contained calculator and hardware edits during this review.

The arithmetic fixtures independently verify the printed answers, operand order and the selected four-register snapshots. They are not a test of the production Swift executable. Prototype lessons intentionally avoid mode-dependent backspace and swap-entry sequences.

## Revision 0.2.0 / upright fractions and laser finish

User review changed the fraction representation from horizontal length to vertical height. The 3 mm-thick bars have been replaced by upright blocks, and every STL now omits lettering relief. This makes stacked heights exact and leaves clean faces for laser marking. STL exports follow `scratch/stl/education`.

## Initial product choices

- Fraction tray: a horizontal `whole . numerator . denominator` path, a separate result well, and six equal-depth tower sockets. Blocks have a common 24 mm square footprint and proportional vertical heights of 96/n mm. Three whole blocks support the worked mixed-number example in adjacent towers. The numeral set is single-digit; paper liners support larger fields and mixed-number results.
- Stack board: added as the prerequisite to the blueprint's other items. Blank tiles avoid pretending values physically disappear after an operator.
- Tree board: one complete balanced binary tree, with removable operator and operand tokens. It teaches one structure; arbitrary deeper trees require an extension kit or paper sketch.
- Coordinate board: 10 points per axis means coordinates 0-9 and nine intervals, not ten unit intervals. Blind sockets and inverted, flat-headed pegs make the first prototype simple to print. Loose yarn replaces a tensioned elastic-band mechanism until strength is tested.
- Cards: shared scene data drives engraving and PDF diagrams. All manufacturing lettering is converted to paths. All printed solids have flat contact surfaces. Lettering is supplied only as laser artwork, with separate focus-height jobs for the fraction blocks.

## Next manipulatives

| Design | Next concrete prototype | Acceptance before expansion |
| --- | --- | --- |
| Infix framing slider | A two-piece adjustable reading window with a separate pending-operator strip. Provide a valid operator-stack procedure alongside it. | Track parentheses and equal-precedence left associativity; distinguish postfix output from physical ENTER presses; test aperture fit and rail clearance. Do not build the stronger/weaker slogan into the mechanism. |
| Algebra tiles | Unit square, x rectangle and x-squared square with consistent unit edges; laser-engraved + / - identifiers and a factoring frame. | Areas represent 1, x and x^2; signs remain readable without color. Demonstrate a specific factorization and identify the calculator's numeric check separately. |
| Distance accessories | A removable 3-4-5 triangle and calibrated hypotenuse strip aligned to the 12 mm pitch. | Endpoint distances are correct; accessory does not obscure coordinates or pull pegs out. |
| Classroom charts | Enlarged diagrams of the four-register snapshots and paired expression trees. | Readable at classroom distance; educator review and curriculum mapping completed. |

## Commercial questions held open

The blueprint's search-volume estimates, competitor assertions, market sizes, platform eligibility and honorarium estimates are unverified planning assumptions. They do not appear as marketing claims in the generated collection. No standards alignment or learning-outcome claim is certified by this prototype.

A sensible first offering is a free sample card/lesson, a fuller downloadable guide, and a physical kit containing the same objects used by the lessons. Selecting prices, license terms, teacher discount structure and channels needs a separate commercial decision. Before retail launch, finish physical proofs, educator review, packaging inventory and product-specific storefront work.

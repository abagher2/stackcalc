# StackCalc Learning Lab

Collection 01, revision 0.2.0. A standalone prototype manufacturing and teaching-resource build for the StackCalc ecosystem. Nothing in this directory changes the calculator, its existing hardware build, or the selling website.

## First collection

| Product | Generated parts | Teaching purpose |
| --- | --- | --- |
| Fraction studio | 192 x 151 mm tray, 26 upright fraction blocks, 30 numeral tiles | Connect a physical amount to whole / numerator / denominator entry |
| Stack stage | 158 x 164 mm four-register board and four blank value tiles | Distinguish ENTER, automatic lift and binary operations |
| Expression tree | 196 x 164 mm board and seven removable tokens | Read `(a + b) * (c - d)` in postorder |
| Coordinate lab | 176 x 192 mm board and four locator pegs | Measure a 3-4-5 triangle on a 10 x 10 point grid |
| Pocket lab | Three 85.60 x 53.98 mm cards | Stack, fractions and distance, with readable topic separation |
| Fit coupon | Three socket diameters for the common peg | Tune printer fit before making the full board |

There are **13 STL plates containing 79 separate solids**, 13 OpenSCAD sources, 44 manufacturing SVGs (including six focus-height engraving layouts), top-view previews, a catalog manifest, and four PDFs. Every plate fits within a nominal 210 x 210 mm area; allow additional printer margin for a brim. See `build/validation.json` for measured bounds and solid counts.

## Upright fraction geometry

Every fraction block has a 24 x 24 mm footprint. Heights are 96 mm (whole), 48 mm (half), 32 mm (third), 24 mm (quarter), 16 mm (sixth) and 12 mm (eighth). Two halves, three thirds or four quarters stack to the same height as a whole. Contact faces are flat with no embossed lettering, connectors or added spacers. Six 24.6 mm square tray sockets share a common floor.

Laser the top labels using the separate `fraction_blocks-engrave-z12.svg`, `-z16`, `-z24`, `-z32`, `-z48` and `-z96` jobs. Each uses the same full plate coordinate frame. The catalog manifest records the surface height for every engraving setup. Compare tall stacks from the same floor; show mixed numbers in adjacent towers, not a single multi-whole tower.

## Build

Requires Python 3.11+ and OpenSCAD with SVG import. Poppler's `pdftoppm` is needed only for PDF visual review. The current prototype was rendered with OpenSCAD 2026.08.31. No KiCad, Xcode or app build is needed.

```sh
cd Education
make setup
make -j4 all
make render-pdf
```

STLs default to the repository's `scratch/stl/education` directory. Override with `STL_DIR=/absolute/path` if needed. The ZIP contains sibling `Education/` and `scratch/stl/education/` directories; unpack it, then run make from `Education/`.

`make setup` creates a local `.venv`. If using an existing environment, pass `PYTHON=/absolute/path/to/python`. Override `OPENSCAD=/absolute/path/to/openscad` as needed. On macOS the Makefile detects the standard application location. In Codex, the installed OpenSCAD Qt runtime may require an approved execution outside the sandbox; an `Incompatible processor ... neon` failure here is a runtime issue, not a mesh diagnosis.

Individual targets: `svg`, `scad`, `stl`, `pdf`, `test`, `check`, `render-pdf`, `bundle`. `clean` removes this directory's `build/` and `output/` folders plus the named Education STLs in `STL_DIR`; it does not delete other hardware STLs. Successful generation preserves unchanged SVG/SCAD mtimes so STL builds are incremental. Failed renders cannot leave a reusable partial STL target.

## Outputs

| Path | Use |
| --- | --- |
| `build/preview/index.html` | Local product gallery; open in a browser |
| `build/svg/*-engrave.svg` | Black, outlined vector engraving artwork, 1:1 millimetres |
| `build/svg/*-cut.svg` | Red nominal outer perimeters, without kerf compensation |
| `build/svg/*-pocket-guide.svg` | Blue recess guides; never assume these are through-cuts |
| `build/scad/*.scad` | Generated CAD, with editable body height and pocket depth; no lettering geometry |
| `../scratch/stl/education/*.stl` | Flat-faced print geometry for subsequent laser engraving |
| `output/pdf/reference-cards-{letter,a4}.pdf` | Single-sided card sheets, two three-card sets per page |
| `output/pdf/teacher-booklet-{letter,a4}.pdf` | Eight-page guide with four investigations, worksheet and answers |
| `output/downloads/stackcalc-learning-lab-0.2.0-prototype.zip` | Complete source and output download, with checksums |

CAD is standalone solid geometry. Laser SVGs are separate finishing jobs; OpenSCAD does not import lettering. Python uses the Vera fonts distributed with ReportLab and embeds them in PDFs. Generate artwork from `tools/catalog.py`; edit `tools/documents.py` for lessons and layout, and `tools/lessons.py` for arithmetic examples. Do not hand-edit generated SVGs as the canonical design.

## Review and release boundaries

`make check` validates known arithmetic answers and register snapshots, proportional block heights and equal-height stacks, bed extents, font outlines, mesh watertightness / winding / separate-solid count, height and PDF page sizes. These checks do not certify printer performance or calculator runtime parity. Rasterize and visually inspect the PDFs after content changes.

The current PDFs are classroom printing masters, not commercial bleed or imposed press files. The ZIP is prepared locally; it has not been uploaded or listed for sale. A site integration can use the version and product dimensions in `build/manifest.json` plus the stable download names. Digital licensing, pricing, product photos, shipping, fulfillment and a site checkout are follow-on work.

See [DESIGN_REVIEW.md](DESIGN_REVIEW.md) for the blueprint corrections and next designs, and [MANUFACTURING.md](MANUFACTURING.md) for manufacturing instructions and physical acceptance checks.

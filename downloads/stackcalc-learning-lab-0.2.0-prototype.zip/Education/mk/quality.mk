.PHONY: check test render-pdf
test:
	$(PYTHON) -m unittest discover -s tools -p 'test_*.py' -v

check: stl pdf test
	$(PYTHON) tools/validate.py --stl-dir "$(STL_DIR)"

render-pdf: pdf
	@mkdir -p $(BUILD)/pdf-review
	@for file in $(PDFS); do "$(PDFTOPPM)" -r 100 -png "$$file" "$(BUILD)/pdf-review/$$(basename "$$file" .pdf)"; done

PARTS := fraction_tray fraction_blocks fraction_digits stack_board stack_tiles tree_board tree_tokens distance_board distance_pegs card_stack card_fractions card_distance fit_coupon
SCADS := $(addprefix $(BUILD)/scad/,$(addsuffix .scad,$(PARTS)))
STLS := $(addprefix $(STL_DIR)/,$(addsuffix .stl,$(PARTS)))
PDFS := $(PDF_DIR)/reference-cards-letter.pdf $(PDF_DIR)/reference-cards-a4.pdf $(PDF_DIR)/teacher-booklet-letter.pdf $(PDF_DIR)/teacher-booklet-a4.pdf

.PHONY: generate svg scad stl pdf bundle
generate:
	$(PYTHON) tools/generate.py --out $(BUILD)

svg scad: generate

# Recursive make starts only after generation, including on a clean parallel build.
# The generator preserves unchanged file mtimes, so meshes remain incremental.
stl: generate
	$(MAKE) $(STLS)

$(BUILD)/scad/%.scad:
	$(PYTHON) tools/generate.py --out $(BUILD)

$(STL_DIR)/%.stl: $(BUILD)/scad/%.scad
	@mkdir -p $(STL_DIR) $(BUILD)/logs
	"$(OPENSCAD)" --export-format binstl -o "$@" "$<" > "$(BUILD)/logs/$*.log" 2>&1 || { cat "$(BUILD)/logs/$*.log"; exit 1; }
	@echo 'Rendered $*'

$(BUILD)/svg/%-engrave.svg:
	$(PYTHON) tools/generate.py --out $(BUILD)

pdf: generate
	$(PYTHON) tools/documents.py --out $(PDF_DIR)

bundle: check
	$(PYTHON) tools/bundle.py --stl-dir "$(STL_DIR)"

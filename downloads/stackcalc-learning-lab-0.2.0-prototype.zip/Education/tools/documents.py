"""Original vector teacher resources; physical diagrams share the CAD catalog."""
import argparse
from pathlib import Path

from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.utils import simpleSplit
from reportlab.lib.units import mm

from catalog import catalog, INK, TEAL, GOLD, PAPER, REVISION, UNIT_HEIGHT
from generate import FONT_DIR
from lessons import trace

pdfmetrics.registerFont(TTFont("Lab",str(FONT_DIR/"Vera.ttf")))
pdfmetrics.registerFont(TTFont("LabBold",str(FONT_DIR/"VeraBd.ttf")))
PARTS={p.id:p for p in catalog()}


class Page:
    def __init__(self, c, size):
        self.c=c; self.w,self.h=[v/mm for v in size]

    def text(self,x,y,text,size=3.7,bold=False,color=INK):
        self.c.setFillColor(HexColor(color)); self.c.setFont("LabBold" if bold else "Lab",size*mm)
        self.c.drawString(x*mm,(self.h-y)*mm,text)

    def para(self,x,y,text,width=None,size=3.6,color=INK):
        lines=simpleSplit(text,"Lab",size*mm,(width or self.w-x-18)*mm)
        for line in lines:
            self.text(x,y,line,size,color=color); y+=size*1.55
        return y+3

    def rect(self,x,y,w,h,color=PAPER,stroke=None,r=0):
        self.c.setFillColor(HexColor(color))
        if stroke: self.c.setStrokeColor(HexColor(stroke))
        self.c.roundRect(x*mm,(self.h-y-h)*mm,w*mm,h*mm,r*mm,fill=1,stroke=bool(stroke))

    def line(self,x,y,x2,y2,color=TEAL,width=.25):
        self.c.setStrokeColor(HexColor(color)); self.c.setLineWidth(width*mm)
        self.c.line(x*mm,(self.h-y)*mm,x2*mm,(self.h-y2)*mm)

    def header(self,kicker,title,subtitle):
        self.text(18,18,"STACKCALC / LEARNING LAB",3,bold=True,color=TEAL)
        self.text(18,31,kicker.upper(),3,color=TEAL)
        self.text(18,45,title,8,bold=True)
        self.para(18,55,subtitle,size=3.6)
        self.line(18,68,self.w-18,68,color=GOLD,width=.8)

    def footer(self,number):
        self.line(18,self.h-16,self.w-18,self.h-16,color="#c3d3cd")
        self.text(18,self.h-10,f"COLLECTION 01 / PROTOTYPE {REVISION} / EDUCATOR REVIEW COPY",2.4)
        self.text(self.w-24,self.h-10,str(number),2.8,bold=True)

    def note(self,y,title,body):
        self.rect(18,y,self.w-36,26,color="#e5efeb",r=2)
        self.text(22,y+7,title,3.5,bold=True,color=TEAL)
        self.para(22,y+14,body,width=self.w-44,size=3.1)

    def diagram(self,id,x,y,width):
        p=PARTS[id]; scale=width/p.width
        c=self.c; c.saveState()
        c.translate(x*mm,(self.h-y)*mm); c.scale(scale*mm,-scale*mm)
        for shapes,fill in [(p.bodies,PAPER),(p.pockets,"#dce9e5")]:
            for s in shapes:
                c.setFillColor(HexColor(fill)); c.setStrokeColor(HexColor(TEAL)); c.setLineWidth(.2)
                if s["kind"]=="circle": c.circle(s["x"],s["y"],s["r"],fill=1,stroke=1)
                else: c.roundRect(s["x"],s["y"],s["w"],s["h"],s["r"],fill=1,stroke=1)
        # Draw branches and grid first; cover recessed regions afterwards.
        for l in p.lines:
            c.setStrokeColor(HexColor(TEAL)); c.setLineWidth(l["width"])
            c.line(l["x1"],l["y1"],l["x2"],l["y2"])
        for s in p.pockets:
            c.setFillColor(HexColor("#dce9e5")); c.setLineWidth(.2)
            if s["kind"]=="circle": c.circle(s["x"],s["y"],s["r"],fill=1,stroke=1)
            else: c.roundRect(s["x"],s["y"],s["w"],s["h"],s["r"],fill=1,stroke=1)
        for label in p.labels:
            c.saveState(); c.translate(label["x"],label["y"]); c.scale(1,-1)
            c.setFont("LabBold" if label["bold"] else "Lab",label["size"])
            c.setFillColor(HexColor(INK))
            (c.drawCentredString if label["align"]=="center" else c.drawString)(0,0,label["text"])
            c.restoreState()
        c.restoreState()


def document(path,size):
    c=canvas.Canvas(str(path),pagesize=size,invariant=1,pageCompression=1)
    c.setTitle("StackCalc Learning Lab - "+path.stem)
    c.setAuthor("StackCalc")
    c.setSubject("Prototype teaching resources for four-register RPN")
    return c


def cards(path,size):
    c=document(path,size); p=Page(c,size)
    p.text(17,18,"STACKCALC / POCKET LAB",6,bold=True)
    p.para(17,27,"Three single-sided cards. Two sets per sheet. Print at 100% / actual size.",size=3.2)
    gap=8; left=(p.w-2*85.6-gap)/2
    for row,id in enumerate(["card_stack","card_fractions","card_distance"]):
        for col in range(2):
            x,y=left+col*(85.6+gap),42+row*62
            p.diagram(id,x,y,85.6)
            for a,b,sx,sy in [(x,y,-1,-1),(x+85.6,y,1,-1),(x,y+53.98,-1,1),(x+85.6,y+53.98,1,1)]:
                p.line(a+sx*.7,b,a+sx*2.7,b,color=INK,width=.15)
                p.line(a,b+sy*.7,a,b+sy*2.7,color=INK,width=.15)
    p.line(18,237,68,237,color=INK,width=.4)
    p.line(18,235,18,239,color=INK); p.line(68,235,68,239,color=INK)
    p.text(73,238,"This line must measure 50 mm.",3)
    p.para(18,249,"Trim to the outlines: 85.60 x 53.98 mm. Keep rounded corners. Function labels describe actions; the physical shift-key sequence depends on the selected calculator layout.",size=3,width=p.w-36)
    p.footer(1); c.showPage(); c.save()


def booklet(path,size):
    c=document(path,size)
    def page(n,kicker,title,subtitle):
        p=Page(c,size); p.header(kicker,title,subtitle); p.footer(n); return p
    p=page(1,"Teacher field guide / grades 6-8","Make the math tangible.","Four short investigations connecting objects, mathematical expressions and a four-register RPN calculator.")
    for id,x,y,w in [("fraction_tray",18,81,83),("stack_board",116,81,66),("tree_board",18,160,83),("distance_board",118,157,70)]:
        p.diagram(id,x,y,w)
    p.text(18,238,"BUILD. PREDICT. PRESS. EXPLAIN.",4.5,bold=True,color=TEAL)
    p.para(18,247,"Use with StackCalc in four-register RPN mode. Suggested lessons: 15-25 minutes each, in pairs. Review copy: classroom timing and physical fit still need a pilot.",size=3.2)
    c.showPage()

    p=page(2,"Investigation 01 / stack stage","Where did the value go?","Goal: distinguish ENTER, number entry and arithmetic. Materials: stack board, four writable value tiles, calculator.")
    p.text(18,81,"Start with 8 ENTER 3 -",5,bold=True)
    p.para(18,91,"Begin with all four registers at zero. One learner presses keys; a partner updates the tiles. Read T, Z, Y, X from top to bottom. Include the zeros.")
    columns=[18,69,96,123,150]
    for x,label in zip(columns,["After action","T","Z","Y","X"]): p.text(x,115,label,3.4,bold=True)
    for i,(key,state) in enumerate(trace("8 ENTER 3 -")):
        y=126+i*10
        p.line(18,y+3,p.w-18,y+3,color="#c3d3cd")
        for x,value in zip(columns,[key,*reversed(state)]): p.text(x,y,str(value),4)
    p.text(18,172,"Now type 2, then press *.",4.5,bold=True)
    p.para(18,182,"Predict before pressing: the result 5 lifts to Y as 2 enters X. Multiplication leaves 10 in X. ENTER was unnecessary between the subtraction and the new number.")
    p.note(211,"Say it precisely","ENTER copies X up and disables the next entry lift. A binary operator combines Y and X; the answer appears in X.")
    p.para(18,247,"Teacher prompt: What would happen with 3 ENTER 8 -? Explain why subtraction and division must keep operand order.",size=3.2)
    c.showPage()

    p=page(3,"Investigation 02 / fraction studio","Build it. Name it. Enter it.","Goal: connect proportional height, fraction notation and dot entry. Materials: fraction tray, tower blocks, numeral tiles, calculator.")
    for i,n in enumerate([1,2,4,8]):
        x=18+i*27
        block_h=UNIT_HEIGHT/n*.7
        for j in range(n):
            y=150-(j+1)*block_h
            p.rect(x,y,19,block_h,color="#e5efeb",stroke=TEAL,r=.5)
            p.text(x+5,y+block_h/2+1,"1" if n==1 else f"1/{n}",2.8,bold=True)
        p.text(x,157,f"{n} block"+("s" if n>1 else ""),3)
    p.line(18,150-UNIT_HEIGHT*.7,123,150-UNIT_HEIGHT*.7,color=GOLD,width=.5)
    p.text(136,86,"Try 3/4",4.8,bold=True)
    p.para(136,96,"Stack three quarter-blocks beside one whole. Compare from the same floor. Name the numerator and denominator.",width=p.w-154,size=3.5)
    p.text(18,169,"1  Represent",4,bold=True)
    p.para(52,169,"Put 0, 3 and 4 into the whole, numerator and denominator wells. Leave the result well free.",size=3.5)
    p.text(18,190,"2  Enter",4,bold=True)
    p.para(52,190,"Type . 3 . 4, then ENTER. Show 2 1/2 as two whole towers and one half tower. Type 2 . 1 . 2, then +.",size=3.5)
    p.text(18,216,"3  Explain",4,bold=True)
    p.para(52,216,"Regroup: 3/4 + 2 1/2 = 3 1/4. The result may display 3.25 or a mixed fraction, depending on display mode.",size=3.5)
    p.para(18,247,"Transfer: show why 1/2 = 2/4 = 4/8. Equal stacks reach the same height. Typing a dot does not perform division.",size=3.2)
    c.showPage()

    p=page(4,"Investigation 03 / expression tree","Read the structure.","Goal: turn a grouped expression into an evaluation order. Materials: tree board and seven tokens, value tiles, calculator.")
    p.diagram("tree_board",18,78,112)
    p.text(138,85,"Left",5,bold=True,color=TEAL)
    p.text(138,96,"Right",5,bold=True,color=TEAL)
    p.text(138,107,"Operator",5,bold=True,color=TEAL)
    p.para(138,121,"Point to each well in numbered order. Speak the token after both its children.",width=p.w-156,size=3.4)
    p.text(18,183,"(3 + 2) * (8 - 4)",5,bold=True)
    p.para(18,194,"Set a=3, b=2, c=8, d=4. Read: 3 2 + 8 4 - *. On the calculator use: 3 ENTER 2 + 8 ENTER 4 - *. Result: 20.")
    p.note(217,"Postfix tokens are not a literal key list","ENTER separates consecutive number entries. After +, typing 8 automatically lifts the subtotal 5. Preserve the left/right operand order.")
    p.para(18,252,"Transfer: compare 3 * 8 - 4 + 1 with 3 * (8 - (4 + 1)). Sketch their different trees before calculating.",size=3.2)
    c.showPage()

    p=page(5,"Investigation 04 / coordinate lab","Measure the diagonal.","Goal: connect run, rise and the Pythagorean theorem. Materials: coordinate board, three pegs, loose yarn, calculator.")
    p.diagram("distance_board",18,78,105)
    p.text(133,85,"A = (1, 2)",4.5,bold=True)
    p.text(133,96,"B = (4, 6)",4.5,bold=True)
    p.para(133,111,"Place the third peg at (4, 2). Trace the horizontal, vertical and diagonal paths using loose yarn.",width=p.w-151,size=3.4)
    p.para(133,148,"Count intervals: run 3, rise 4. Each grid interval represents one coordinate unit.",width=p.w-151,size=3.4)
    for y,key,result in [(207,"1 ENTER 4 - x^2","X = 9"),(219,"2 ENTER 6 - x^2","X = 16, Y = 9"),(231,"+ sqrt","X = 5")]:
        p.text(18,y,key,4,bold=True); p.text(119,y,result,3.8)
    p.para(18,247,"Discuss: the differences are negative, but their squares are positive. The distance is 5 coordinate units, not 5 mm. Count spaces between pegs.",size=3.2)
    c.showPage()

    p=page(6,"Reproducible student record","Predict before you press.","Name: __________________________   Partner: __________________________")
    tasks=[("01 / STACK","Record T, Z, Y, X after 3 ENTER 8 ENTER 4 ENTER 1. Then predict +, -, *."),
           ("02 / FRACTIONS","Draw stacked blocks showing 1/2 + 1/4. Write the two-dot keystrokes and the result."),
           ("03 / TREE","Use (6 + 1) * (9 - 5). Label the tree, write postfix tokens, then calculator actions."),
           ("04 / DISTANCE","Find the distance from (2, 1) to (5, 5). Explain which two lengths you squared.")]
    for i,(title,prompt) in enumerate(tasks):
        y=82+i*43
        p.text(18,y,title,3.6,bold=True,color=TEAL)
        p.para(18,y+9,prompt,size=3.4)
        p.line(18,y+28,p.w-18,y+28,color="#a3bbb4")
        p.line(18,y+37,p.w-18,y+37,color="#a3bbb4")
    c.showPage()

    p=page(7,"Teacher key / discussion","Listen for the reasoning.","Accept equivalent notation. Ask learners to explain the representation, the operation and the result.")
    y=83
    answers=[("01 / Stack", "Before +: T=3, Z=8, Y=4, X=1. After +: T=3, Z=3, Y=8, X=5. After -: T=3, Z=3, Y=3, X=3. After *: T=3, Z=3, Y=3, X=9. The top register repeats on a binary stack drop."),
             ("02 / Fractions", "One half plus one quarter equals three quarters. Keys: .1.2 ENTER .1.4 +. A decimal result of 0.75 is equivalent. Ask why the denominators are not simply added."),
             ("03 / Tree", "Postfix: 6 1 + 9 5 - *. Calculator: 6 ENTER 1 + 9 ENTER 5 - *. Subtotals 7 and 4 give 28. A tree describes dependencies; it does not prescribe an ENTER for every token."),
             ("04 / Distance", "Run 3, rise 4, distance 5. Keys: 2 ENTER 5 - x^2 1 ENTER 5 - x^2 + sqrt. Square each difference before adding; take one square root at the end.")]
    for title,body in answers:
        p.text(18,y,title,4.2,bold=True,color=TEAL)
        y=p.para(18,y+10,body,size=3.5)+7
    p.note(225,"Two different examples","3 * 8 - 4 + 1 = 21; 3 * (8 - (4 + 1)) = 9. Grouping changes the tree and the value, not just the button rhythm.")
    c.showPage()

    p=page(8,"Preparation / production notes","Make a classroom set.","One of each board per pair. These are design prototypes for trial lessons, not production-approved retail products.")
    y=82
    for title,body in [
        ("Print the paper kit", "Choose Letter or A4. Print actual size and measure the 50 mm scale on the card sheet. Cards are single-sided. The booklet is in reading order; duplex long-edge works for a stapled handout. Saddle-stitch imposition and commercial bleed are not supplied."),
        ("Make the physical kit", "Start with the fit coupon and a peg. Fraction blocks share 24 x 24 mm bases; height is 96/n mm. Print flat contact faces and laser the labels afterward. Use separate focus-height jobs. Keep towers at or below one whole (96 mm); show mixed numbers in adjacent towers."),
        ("Prepare the lesson", "Use writable film on blank tiles or paper liners. Keep loose pieces inventoried; this set is for supervised middle-school use. Do not assume PLA is dry-erase or tension the prototype pegs with bands. Use four-register RPN mode."),
        ("Release gate", "Before selling printed kits: inspect edges, test repeated fitting and legibility, pilot the lessons with an educator, verify the target calculator's actions, and approve packaging and print proofs. Prices, licensing and shop listings remain undecided."),
    ]:
        p.text(18,y,title,4,bold=True,color=TEAL)
        y=p.para(18,y+9,body,size=3.25)+5
    p.text(18,244,"Reference and verification",3.5,bold=True)
    p.para(18,251,"HP 32SII Owner's Manual, chapters 1-2 and appendix B. Arithmetic examples are independently checked; this guide does not certify every StackCalc mode or key layout.",size=2.8)
    c.linkURL("https://h10032.www1.hp.com/ctg/Manual/bpia5305.pdf",(18*mm,(p.h-255)*mm,(p.w-18)*mm,(p.h-244)*mm),relative=0)
    c.showPage(); c.save()


if __name__ == "__main__":
    parser=argparse.ArgumentParser(); parser.add_argument("--out",type=Path,default=Path("output/pdf"))
    out=parser.parse_args().out; out.mkdir(parents=True,exist_ok=True)
    for name,size in [("letter",letter),("a4",A4)]:
        cards(out/f"reference-cards-{name}.pdf",size)
        booklet(out/f"teacher-booklet-{name}.pdf",size)
    print("Created Letter and A4 reference sheets and 8-page teacher booklets.")

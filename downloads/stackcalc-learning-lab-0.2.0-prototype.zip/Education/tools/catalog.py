"""Shared millimetre geometry and original lesson content. Y increases downwards."""
from dataclasses import dataclass, field, asdict

REVISION = "0.2.0"
INK = "#173d43"
TEAL = "#087f82"
GOLD = "#d79b36"
PAPER = "#f6f3ea"
DENOMINATORS = (1, 2, 3, 4, 6, 8)
UNIT_HEIGHT = 96.0
BLOCK_SIDE = 24.0


@dataclass
class Part:
    id: str
    title: str
    width: float
    height: float
    thickness: float = 4
    pocket_depth: float = 1.6
    bodies: list = field(default_factory=list)
    pockets: list = field(default_factory=list)
    labels: list = field(default_factory=list)
    lines: list = field(default_factory=list)
    bosses: list = field(default_factory=list)
    notes: str = ""

    def rect(self, x, y, w, h, r=2, pocket=False, height_divisor=1):
        (self.pockets if pocket else self.bodies).append(dict(kind="rect", x=x, y=y, w=w, h=h, r=r, height_divisor=height_divisor))

    def circle(self, x, y, radius, pocket=False):
        (self.pockets if pocket else self.bodies).append(dict(kind="circle", x=x, y=y, r=radius))

    def label(self, x, y, text, size=3, align="left", bold=False, surface_z=None):
        self.labels.append(dict(x=x, y=y, text=text, size=size, align=align, bold=bold, surface_z=self.thickness if surface_z is None else surface_z))

    def line(self, x1, y1, x2, y2, width=.35):
        self.lines.append(dict(x1=x1, y1=y1, x2=x2, y2=y2, width=width))

    def plate(self):
        self.rect(0, 0, self.width, self.height, 4 if self.width > 90 else 3.18)

    def heading(self, subtitle):
        self.label(8, 12, "STACKCALC / " + self.title.upper(), 3.6, bold=True)
        self.label(8, 20, subtitle, 2.5)


CARDS = [
    dict(id="card_stack", title="01 / THE STACK", tagline="Keep the order. See the result.", rows=[
        ("T   Z   Y   X", "Four registers; X is the screen."),
        ("ENTER", "Copies X up; next number replaces X."),
        ("Y - X     Y / X", "First value in Y, second value in X."),
        ("8  ENTER  3  -  = 5", "After an operation, entry lifts the stack."),
    ]),
    dict(id="card_fractions", title="02 / BUILD A FRACTION", tagline="Whole . numerator . denominator", rows=[
        ("3/4        . 3 . 4", "No whole part? Start with a dot."),
        ("2 1/2      2 . 1 . 2", "Two dots make the fraction entry."),
        (".3.4  ENTER  2.1.2  +", "Result: 3 1/4, or decimal 3.25."),
        ("BUILD / NAME / TYPE / CHECK", "Dots separate fields; they do not divide."),
    ]),
    dict(id="card_distance", title="03 / MEASURE DISTANCE", tagline="From (1, 2) to (4, 6)", rows=[
        ("1  ENTER  4  -  x^2", "Horizontal difference squared: 9."),
        ("2  ENTER  6  -  x^2", "Vertical difference squared: 16."),
        ("+  sqrt", "9 + 16 = 25; square root = 5."),
        ("SQUARE / ADD / ROOT", "Function names may need a shift key."),
    ]),
]


def catalog():
    parts = []
    p = Part("fraction_tray", "Fraction studio", 192, 151)
    p.plate(); p.heading("Build the amount. Name the parts. Type the two dots.")
    for x, name in [(10,"WHOLE"), (56,"NUMERATOR"), (102,"DENOMINATOR"), (148,"RESULT X")]:
        p.rect(x, 30, 34, 24, 2, pocket=True)
        p.label(x+17, 61, name, 2.45, "center", True)
    for x in [50, 96]:
        p.circle(x, 44, 1.3, pocket=True)
    p.label(10, 72, "WHOLE . NUM . DEN", 3, bold=True)
    for y in [78, 109]:
        for x in [32,83,134]:
            p.rect(x,y,BLOCK_SIDE+.6,BLOCK_SIDE+.6,1,pocket=True)
    p.label(96, 145, "Equal bases. Stack heights to compare one whole.", 2.6, "center")
    p.notes = "Six 24.6 x 24.6 mm tower sockets, all 1.6 mm deep. Equal footprints; block height is 96/n mm. Compare stacks on this common floor."
    parts.append(p)

    p = Part("fraction_blocks", "Fraction towers / 26 blocks", 166, 139, thickness=UNIT_HEIGHT)
    index = 0
    for n in (1,1,1,2,3,4,6,8):
        for i in range(n):
            x, y = 2+(index%6)*27, 2+(index//6)*27
            p.rect(x,y,BLOCK_SIDE,BLOCK_SIDE,1,height_divisor=n)
            p.label(x+12,y+14,"1" if n==1 else f"1/{n}",5,"center",True,surface_z=UNIT_HEIGHT/n)
            index += 1
    p.notes = "Common 24 x 24 mm footprint. Whole 96, half 48, third 32, quarter 24, sixth 16, eighth 12 mm tall. Flat contact faces preserve summed heights; laser labels only. Separate engraving jobs by top-surface height."
    parts.append(p)

    p = Part("fraction_digits", "Numeral tiles / 30 pieces", 208, 128, thickness=2.4)
    for i in range(30):
        x,y=2+(i%6)*34,2+(i//6)*25
        p.rect(x,y,31,21,2); p.label(x+15.5,y+14,str(i%10),8,"center",True)
    p.notes = "Three copies of digits 0-9; one digit per well. Use paper liners for multi-digit quantities."
    parts.append(p)

    p = Part("stack_board", "Stack stage", 158, 164)
    p.plate(); p.heading("Read from T to X. Move values after each action.")
    for i,(reg,role) in enumerate([("T","fourth"),("Z","third"),("Y","first operand"),("X","screen / result")]):
        y=31+i*27
        p.label(12,y+14,reg,8,bold=True)
        p.rect(52,y,94,22,2,pocket=True)
        p.label(30,y+13,role,2.0,"center")
    p.label(9,150,"ENTER copies X; next entry replaces X.",3,bold=True)
    p.label(9,158,"After arithmetic, a new number lifts the stack.",2.6)
    parts.append(p)
    p = Part("stack_tiles", "Stack value tiles / 4 blanks", 98, 104, thickness=2.4)
    for i in range(4): p.rect(2,2+i*25,92.8,20.8,2)
    p.notes = "Blank reusable value tiles. Apply a compatible writable film or use 92 x 20 mm paper inserts; ordinary PLA is not assumed dry-erase."
    parts.append(p)

    p = Part("tree_board", "Expression tree", 196, 164)
    p.plate(); p.heading("(a + b) * (c - d)  /  visit left, right, then operator")
    nodes=[(28,128,"1 / a"),(76,128,"2 / b"),(52,84,"3 / +"),(120,128,"4 / c"),(168,128,"5 / d"),(144,84,"6 / -"),(98,42,"7 / *")]
    for a,b in [(6,2),(6,5),(2,0),(2,1),(5,3),(5,4)]:
        p.line(*nodes[a][:2],*nodes[b][:2],.65)
    for x,y,label in nodes:
        p.circle(x,y,11.5,pocket=True)
        p.label(x,y+17,label,3,"center",True)
    p.label(98,158,"Read out:  a  b  +  c  d  -  *",3.5,"center",True)
    p.notes = "Engraved branches show structure, not a mechanically enforced traversal. Numbered wells teach postorder. Seven 22.4 mm tokens fit 23 mm wells."
    parts.append(p)
    p = Part("tree_tokens", "Tree tokens / 7 pieces", 108, 58, thickness=3)
    for i,token in enumerate(["a","b","+","c","d","-","*"]):
        x,y=14+(i%4)*26,14+(i//4)*26
        p.circle(x,y,11.2); p.label(x,y+2.6,token,8,"center",True)
    parts.append(p)

    p = Part("distance_board", "Coordinate lab", 176, 192, pocket_depth=2.2)
    p.plate(); p.heading("10 x 10 points / coordinates 0-9 / pitch 12 mm")
    for i in range(10):
        x=32+12*i; y=38+12*i
        p.line(x,38,x,146,.22); p.line(32,y,140,y,.22)
        p.label(x,155,str(i),2.5,"center")
        p.label(24,y+1,str(9-i),2.5,"center")
        for j in range(10): p.circle(x,38+12*j,2.2,pocket=True)
    p.label(148,150,"x",3,bold=True); p.label(24,30,"y",3,bold=True)
    p.label(10,168,"A(1,2) to B(4,6): run 3, rise 4, distance 5",3,bold=True)
    p.label(10,178,"1 ENTER 4 - x^2   2 ENTER 6 - x^2",2.8)
    p.label(10,187,"+ sqrt   /   function names, not literal key counts",2.6)
    p.notes = "100 blind sockets, 4.4 mm diameter x 2.2 mm deep. Flat-headed locator pegs; use loose yarn for the triangle, no tensioned bands in this revision."
    parts.append(p)
    p = Part("distance_pegs", "Locator pegs / 4 pieces", 56, 16, thickness=2)
    for x in [8,21,34,47]:
        p.circle(x,8,5)
        p.bosses.append(dict(x=x,y=8,r=1.9,height=2))
    p.notes = "Print heads flat on bed, stems upwards; invert to insert. Four 3.8 mm stems fit 4.4 mm sockets."
    parts.append(p)

    for card in CARDS:
        p = Part(card["id"],card["title"],85.60,53.98,thickness=1.4,pocket_depth=.4)
        p.plate()
        p.label(4,6,"STACKCALC / " + card["title"],2.5,bold=True)
        p.label(4,10,card["tagline"],2.1)
        p.line(4,12,81.6,12)
        for i,(a,b) in enumerate(card["rows"]):
            p.label(4,17+i*9,a,2.65,bold=True)
            p.label(4,21+i*9,b,2.05)
        p.label(4,51,"LEARNING LAB / 4-REGISTER RPN / PROTOTYPE 01",1.8)
        p.notes = "CR80 footprint, 1.4 mm overall print thickness. Flat faces for laser engraving; no printed text relief. Case fit is unverified."
        parts.append(p)

    p=Part("fit_coupon","Fit first",92,48,pocket_depth=2.2)
    p.plate(); p.label(5,9,"STACKCALC / FIT COUPON",3.5,bold=True)
    for x,d in [(16,4.0),(44,4.4),(72,4.8)]:
        p.circle(x,24,d/2,pocket=True); p.label(x,37,f"{d:.1f} mm",3,"center")
    p.label(46,44,"Use the 3.8 mm stem from distance_pegs.",2.4,"center")
    parts.append(p)
    return parts


def manifest():
    return dict(collection="StackCalc Learning Lab",version=REVISION,status="prototype - not production released",
                units="mm",finish="laser engraving; no printed text",parts=[dict(asdict(p),laser_setups=laser_setups(p)) for p in catalog()])


def laser_setups(p):
    heights=sorted({l["surface_z"] for l in p.labels} | ({p.thickness} if p.lines else set()))
    return [dict(surface_z_mm=z,file=f"svg/{p.id}-engrave"+(f"-z{z:g}" if len(heights)>1 else "")+".svg") for z in heights]

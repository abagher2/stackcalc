"""Checked teaching examples, not a replacement for the calculator engine."""
from fractions import Fraction
import math

EXAMPLES = [
    ("Subtract in order", "8 ENTER 3 -", Fraction(5)),
    ("Divide in order", "8 ENTER 2 /", Fraction(4)),
    ("Rolling expression", "3 ENTER 8 * 4 - 1 +", Fraction(21)),
    ("Nested expression", "3 ENTER 8 ENTER 4 ENTER 1 + - *", Fraction(9)),
    ("Multiply before adding", "3 ENTER 8 ENTER 4 * +", Fraction(35)),
    ("Fraction sum", ".3.4 ENTER 2.1.2 +", Fraction(13,4)),
    ("Tree example", "3 ENTER 2 + 8 ENTER 4 - *", Fraction(20)),
    ("Distance", "1 ENTER 4 - x^2 2 ENTER 6 - x^2 + sqrt", Fraction(5)),
]


def number(token):
    if token.count(".") == 2:
        whole,num,den=token.split(".")
        return Fraction(int(whole or 0))+Fraction(int(num),int(den))
    return Fraction(token)


def trace(sequence):
    """Teaching model: X,Y,Z,T order; ENTER/lift/T-repeat explicit.

    Tokens represent completed number entry, not individual physical keys.
    The executable's current input-buffer behavior is outside this model.
    """
    s=[Fraction(0)]*4
    lift=False
    snapshots=[]
    for token in sequence.split():
        if token == "ENTER":
            s=[s[0],s[0],s[1],s[2]]; lift=False
        elif token in ("+","-","*","/"):
            x,y,z,t=s
            result={"+":lambda:y+x,"-":lambda:y-x,"*":lambda:y*x,"/":lambda:y/x}[token]()
            s=[result,z,t,t]; lift=True
        elif token in ("x^2","sqrt"):
            s[0] = s[0]**2 if token=="x^2" else Fraction(math.sqrt(s[0]))
            lift=True
        else:
            if lift: s=[s[0],s[0],s[1],s[2]]
            s[0]=number(token); lift=True
        snapshots.append((token,tuple(s)))
    return snapshots

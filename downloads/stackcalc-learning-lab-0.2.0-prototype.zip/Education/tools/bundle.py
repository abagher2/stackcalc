"""Package the Education sources and canonical scratch/STL layout together."""
import argparse
from pathlib import Path
import hashlib
import json
import zipfile

from catalog import REVISION, catalog

parser=argparse.ArgumentParser()
parser.add_argument('--stl-dir',type=Path,default=Path('../scratch/stl/education'))
args=parser.parse_args()
paths=[Path('README.md'),Path('DESIGN_REVIEW.md'),Path('MANUFACTURING.md'),Path('Makefile'),Path('requirements.txt')]
paths+=sorted(Path('mk').glob('*.mk'))+sorted(Path('tools').glob('*.py'))
for folder in ['build/svg','build/scad','build/preview','build/logs','output/pdf']:
    paths+=sorted(p for p in Path(folder).glob('*') if p.is_file())
paths += [Path('build/manifest.json'),Path('build/validation.json')]
files=[(p, 'Education/'+p.as_posix()) for p in paths]
files += [(args.stl_dir/(p.id+'.stl'),'scratch/stl/education/'+p.id+'.stl') for p in catalog()]
out=Path('output/downloads'); out.mkdir(parents=True,exist_ok=True)
archive=out/f'stackcalc-learning-lab-{REVISION}-prototype.zip'
hashes={name:hashlib.sha256(p.read_bytes()).hexdigest() for p,name in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p,name in files:
        info=zipfile.ZipInfo(name,(2026,1,1,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,p.read_bytes())
    info=zipfile.ZipInfo('checksums.json',(2026,1,1,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
    z.writestr(info,json.dumps(hashes,indent=2)+'\n')
print(f'Created {archive} ({archive.stat().st_size:,} bytes)')

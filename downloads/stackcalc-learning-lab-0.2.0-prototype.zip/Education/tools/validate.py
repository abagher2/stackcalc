"""Fail the download build on missing files, broken meshes or output drift."""
import hashlib
import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np
import trimesh
from pypdf import PdfReader

from catalog import catalog, REVISION, laser_setups


def validate(stl_dir):
    checks=[]
    for p in catalog():
        operations=("cut","pocket-guide")+(("engrave",) if len(laser_setups(p))<=1 else ())
        for operation in operations:
            path=Path(f"build/svg/{p.id}-{operation}.svg")
            root=ET.parse(path).getroot()
            assert root.get("width")==f"{p.width}mm",path
            assert root.get("height")==f"{p.height}mm",path
            assert not root.findall(".//{http://www.w3.org/2000/svg}text"),f"Live font dependency: {path}"
        for setup in laser_setups(p):
            path=Path("build")/setup["file"]
            root=ET.parse(path).getroot()
            assert root.get("viewBox")==f"0 0 {p.width} {p.height}",path
            if len(laser_setups(p))>1:
                labels=root.findall('.//{http://www.w3.org/2000/svg}g[@aria-label]')
                expected_labels=[l["text"] for l in p.labels if l["surface_z"]==setup["surface_z_mm"]]
                assert [l.get("aria-label") for l in labels]==expected_labels,path
        log=Path(f"build/logs/{p.id}.log").read_text()
        assert not any(s in log for s in ["ERROR:","WARNING:"]),log
        path=stl_dir/f"{p.id}.stl"
        mesh=trimesh.load_mesh(path)
        assert mesh.is_watertight and mesh.is_winding_consistent and mesh.volume>0,p.id
        components=mesh.split(only_watertight=False)
        assert len(components)==len(p.bodies),(p.id,len(components),len(p.bodies))
        assert all(c.is_watertight and c.volume>0 for c in components),p.id
        bounds=mesh.bounds
        assert bounds[0,2]>=-0.001 and abs(bounds[0,2])<.001,p.id
        assert bounds[0,0]>=-.01 and bounds[0,1]>=-.01,p.id
        assert bounds[1,0]<=p.width+.01 and bounds[1,1]<=p.height+.01,p.id
        expected=p.thickness+(max(b["height"] for b in p.bosses) if p.bosses else 0)
        assert abs(bounds[1,2]-expected)<.01,(p.id,bounds[1,2],expected)
        # Verify every disconnected tile/peg is bed-supported with no text relief.
        for c in components:
            cx,cy=c.bounds[:,:2].mean(axis=0)
            matches=[s for s in p.bodies if s["kind"]=="rect" and s["x"]<cx<s["x"]+s["w"] and s["y"]<p.height-cy<s["y"]+s["h"]]
            part_height=p.thickness/matches[0].get("height_divisor",1) if matches else expected
            assert abs(c.bounds[0,2])<.001 and abs(c.bounds[1,2]-part_height)<.01,(p.id,part_height,c.bounds)
            # With laser finishing, plain rectangular blocks have only bottom/top Z.
            if p.id=="fraction_blocks":
                assert np.all(np.isclose(c.vertices[:,2],0,atol=.001)|np.isclose(c.vertices[:,2],part_height,atol=.001)),p.id
        checks.append(dict(part=p.id,watertight=True,components=len(components),triangles=len(mesh.faces),
                           bounds_mm=np.round(bounds,4).tolist(),volume_mm3=round(mesh.volume,2),
                           sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    pdf_checks=[]
    for paper,size in [("letter",(612,792)),("a4",(595.2756,841.8898))]:
        for kind,count in [("reference-cards",1),("teacher-booklet",8)]:
            path=Path(f"output/pdf/{kind}-{paper}.pdf"); pdf=PdfReader(path)
            assert len(pdf.pages)==count,path
            for page in pdf.pages:
                assert abs(float(page.mediabox.width)-size[0])<.01,path
                assert abs(float(page.mediabox.height)-size[1])<.01,path
                assert len(page.extract_text())>150,path
            pdf_checks.append(dict(file=str(path),pages=count))
    report=dict(version=REVISION,mesh_checks=checks,pdf_checks=pdf_checks,
                limits=["Not a physical fit test", "Not slicer or printer validation", "Not a runtime calculator parity test", "PDF visual review is a separate manual step"])
    Path("build/validation.json").write_text(json.dumps(report,indent=2)+"\n")
    print(f"PASS: {len(checks)} watertight STL plates, laser focus layouts, 4 PDFs / 18 pages.")


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--stl-dir",type=Path,default=Path("../scratch/stl/education"))
    validate(parser.parse_args().stl_dir)

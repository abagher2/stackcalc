import unittest
from fractions import Fraction

from catalog import catalog, UNIT_HEIGHT, BLOCK_SIDE, laser_setups
from lessons import EXAMPLES, trace, number
from generate import engrave_segments


class LessonTests(unittest.TestCase):
    def test_laser_strokes_stop_before_recess_edges(self):
        line=dict(x1=0,y1=0,x2=20,y2=0,width=.4)
        segments=engrave_segments(line,[dict(kind="circle",x=10,y=0,r=2)])
        self.assertEqual(len(segments),2)
        self.assertAlmostEqual(segments[0][2],7.65)
        self.assertAlmostEqual(segments[1][0],12.35)

    def test_published_answers(self):
        for title,sequence,answer in EXAMPLES:
            with self.subTest(title=title):
                self.assertEqual(trace(sequence)[-1][1][0],answer)
        for sequence,answer in [(".1.2 ENTER .1.4 +",Fraction(3,4)),
                                ("6 ENTER 1 + 9 ENTER 5 - *",28),
                                ("2 ENTER 5 - x^2 1 ENTER 5 - x^2 + sqrt",5)]:
            self.assertEqual(trace(sequence)[-1][1][0],answer)

    def test_four_register_states_and_t_repeat(self):
        states=trace("3 ENTER 8 ENTER 4 ENTER 1 + - *")
        self.assertEqual(states[6][1],(1,4,8,3))
        self.assertEqual(states[7][1],(5,8,3,3))
        self.assertEqual(states[8][1],(3,3,3,3))
        self.assertEqual(states[9][1],(9,3,3,3))

    def test_enter_and_automatic_lift_are_distinct(self):
        states=trace("8 ENTER 3 - 2 *")
        self.assertEqual(states[1][1],(8,8,0,0))
        self.assertEqual(states[2][1],(3,8,0,0))
        self.assertEqual(states[4][1],(2,5,0,0))
        self.assertEqual(states[-1][1][0],10)

    def test_fraction_blocks_preserve_proportional_heights_and_fit(self):
        parts={p.id:p for p in catalog()}
        blocks=parts["fraction_blocks"]
        self.assertEqual(len(blocks.bodies),26)
        families={}
        for b in blocks.bodies:
            self.assertEqual((b["w"],b["h"]),(BLOCK_SIDE,BLOCK_SIDE))
            n=b["height_divisor"]
            families.setdefault(n,[]).append(blocks.thickness/n)
        for n,heights in families.items():
            self.assertEqual(len(heights),3 if n==1 else n)
            self.assertAlmostEqual(sum(heights),3*UNIT_HEIGHT if n==1 else UNIT_HEIGHT)
        self.assertEqual([x["surface_z_mm"] for x in laser_setups(blocks)],[12,16,24,32,48,96])
        well=parts["fraction_tray"].pockets[-1]
        self.assertGreater(well["w"],BLOCK_SIDE)
        self.assertGreater(well["h"],BLOCK_SIDE)
        self.assertEqual(number(".3.4"),Fraction(3,4))
        with self.assertRaises(ZeroDivisionError): number(".3.0")

    def test_parts_stay_inside_nominal_print_bed(self):
        for p in catalog():
            self.assertLessEqual(max(p.width,p.height),210)
            for s in p.bodies+p.pockets:
                if s["kind"]=="circle": box=(s["x"]-s["r"],s["y"]-s["r"],s["x"]+s["r"],s["y"]+s["r"])
                else: box=(s["x"],s["y"],s["x"]+s["w"],s["y"]+s["h"])
                self.assertGreaterEqual(min(box[:2]),0,p.id)
                self.assertLessEqual(box[2],p.width,p.id)
                self.assertLessEqual(box[3],p.height,p.id)


if __name__ == "__main__": unittest.main()

# Manufacturing notes / prototype 0.2.0

STLs are generated in `scratch/stl/education` at the repository root; SVGs and SCAD remain under `Education/build`.

All dimensions are millimetres. Files are nominal geometry, not printer-specific toolpaths. No G-code, laser power/speed settings or production material certification is supplied.

## FDM

1. Print `fit_coupon.stl` and `distance_pegs.stl` first. Test the 3.8 mm stem in 4.0, 4.4 and 4.8 mm sockets. The coordinate board currently uses 4.4 mm sockets, giving 0.6 mm diametral clearance. Socket depth is 2.2 mm; the stem projects 2.0 mm. Adjust the shared catalog and regenerate if the fit is wrong.
2. Boards are exported base-down. Locator pegs print head-down, stem-up, then invert for use. Start prototypes at 0.20 mm layers, three perimeters and suitable top/bottom layers for the chosen material; inspect the slicer preview. These are starting values, not a validated print profile.
3. Most boards are 4.0 mm thick with 1.6 mm recesses. The distance board uses 2.2 mm recesses, leaving a 1.8 mm floor. Value/numeral tiles are 2.4 mm thick. Tree tokens are 3.0 mm thick and 22.4 mm diameter, in 23.0 mm wells. Cards are 1.4 mm thick overall. All printed text relief has been removed.
4. Fraction blocks share a 24 x 24 mm footprint with a constant corner profile. Their heights are 96/n mm: whole 96, half 48, third 32, quarter 24, sixth 16, eighth 12. Bottom and top contact planes are flat; no connector or raised label changes the stack height. Six tray sockets are 24.6 x 24.6 mm, all 1.6 mm deep. Compare towers on this common floor, not one in a socket and another on the tabletop. Tune socket clearance rather than fraction height.
5. Print fraction blocks upright on their 24 mm square bases. Allow at least 96 mm of printer Z travel and inspect adhesion and slicer travel around the taller pieces. The whole has a 4:1 height-to-width ratio. Trial-print one whole and two halves before making the plate. Keep demonstration towers at or below one whole high; represent mixed numbers using adjacent towers.
6. SCAD contains solid geometry only, with `base_height` and `pocket_depth` parameters. Each fraction body's height is `base_height / denominator`, so changing the unit height preserves all proportions. For coordinated laser focus metadata and matching documentation, change `UNIT_HEIGHT` in `tools/catalog.py` and regenerate the suite. Do not modify just one fraction's height.
7. Engrave after printing. There are no filament color-swap pauses or embossed/debossed text modes. Use a material-approved laser process and prove contrast on a scrap piece. The top labels of the fraction blocks are at different Z heights, so they require separate focus setups.

### Kit inventory per learner pair

| Item | Count |
| --- | ---: |
| Fraction tray / stack board / tree board / distance board | 1 each |
| Whole blocks | 3 |
| Half / third / quarter / sixth / eighth blocks | 2 / 3 / 4 / 6 / 8 |
| Numeral tiles | 30: three of each digit |
| Stack value tiles | 4 blank |
| Tree tokens | 7: a, b, +, c, d, -, * |
| Locator pegs | 4 |
| Pocket cards | 3 |
| Fit coupon | 1 per printer/material trial, not required per kit |

Total with coupon: 79 solids. The fit coupon is a fabrication aid, so the teaching kit itself has 78 pieces. Printed inventory should be confirmed against the generated validation report before packing.

Apply a tested writable film to blank tiles or use paper inserts. Do not assume untreated PLA erases cleanly. Suggested paper sizes: 33 x 23 mm fraction well liners and 92 x 20 mm stack liners. Digit tiles represent single digits; the result well needs a written liner for mixed numbers. The tree board uses symbols; learners assign their numeric values in the lesson.

## Laser / routing

Fraction blocks use six separate jobs: `fraction_blocks-engrave-z12.svg`, `-z16.svg`, `-z24.svg`, `-z32.svg`, `-z48.svg`, and `-z96.svg`. Their Z names are the nominal top-surface heights above the common block bottom, not machine commands. Each file contains only the labels at that focus height, with the original full plate frame preserved. Keep pieces registered to the cut-layout positions and set the appropriate focus for each job. A production positioning jig and focus calibration remain to be proved. No combined multi-height engraving job is supplied.

Other parts have a single nominal engraving plane recorded in `build/manifest.json`.

- `*-engrave.svg`: black artwork, all text converted to vector paths. Use fill engraving for letters. Grid and connector paths have defined stroke widths; set their intended line-marking behavior in the laser software.
- `*-cut.svg`: red outer perimeters at 1:1 scale. Assign a cutting operation explicitly. Nominal outlines have no kerf allowance.
- `*-pocket-guide.svg`: blue recess boundaries. These are **not** automatic through-cuts. A one-layer laser-cut board cannot reproduce blind wells. For wood/acrylic trays use a separately designed routed pocket or a verified layered construction. Those lamination files are not included in this revision.
- Preserve the full SVG page origin, size and millimetre units when aligning files. Import engraving and cut paths at the same position; do not auto-center each artwork selection by its own visible bounds. Engraving and CAD share the same page frame.
- Some token and peg SVGs contain only outer shapes or no engraving. The 2D drawings alone do not manufacture 3D stems. The SVG tree/grid strokes stop clear of pocket boundaries so laser artwork stays on the common top plane.
- Use a material-approved process and a scrap proof. Machine settings and kerf compensation belong to the specific material and device.

## PDFs

Letter and A4 versions contain the same content. Card sheets have six single-sided cards, crop guides, and a 50 mm scale check. Print actual size. The eight-page booklet is in reading order; use duplex long-edge for a regular stapled handout. It is not imposed for saddle stitching. A commercial print vendor's trim, bleed, stock and color requirements need a separate export/proof.

## Physical acceptance before retail

- Confirm real printed dimensions, flatness and repeated insert/removal fit; test the wells with the supplied pieces.
- Inspect all edges and thin stems; test breakage and the suitability of the final material for supervised classroom handling.
- Verify engraving contrast and every printed legend at normal viewing distance, including fraction blocks and the pocket cards.
- Confirm usable writing/erasing surfaces and complete kit inventory.
- Run the four lessons with an educator and the target StackCalc mode/key layout. Record actual student errors and revise wording.
- Verify case fit independently. A CR80 footprint does not establish compatibility with a particular calculator lid or pouch.

Software mesh and document checks are necessary preparation; none of them is evidence that these physical acceptance checks have passed.
